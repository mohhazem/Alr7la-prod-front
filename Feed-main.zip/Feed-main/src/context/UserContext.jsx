import React, { createContext, useState, useContext } from 'react';
import userAvatar from '../assets/images/hazem.jpg';
import postKhalid from '../assets/images/postKhalid.jpg';
import localStorageService from '../services/localStorageService';
const UserContext = createContext();

export const useUserContext = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUserContext must be used within a UserProvider');
  }
  return context;
};

export const UserProvider = ({ children }) => {
  const [profilePhoto, setProfilePhoto] = useState(localStorageService.getItem('profile_picture') || userAvatar);
  const [coverPhoto, setCoverPhoto] = useState(postKhalid);

  const updateProfilePhoto = (newPhoto) => {
    setProfilePhoto(newPhoto);
  };

  const updateCoverPhoto = (newPhoto) => {
    setCoverPhoto(newPhoto);
  };

  const value = {
    profilePhoto,
    coverPhoto,
    updateProfilePhoto,
    updateCoverPhoto
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};

export default UserProvider; 