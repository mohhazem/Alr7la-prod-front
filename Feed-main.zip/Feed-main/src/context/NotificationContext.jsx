import React, { createContext, useContext, useState } from "react";

// Sample notifications with a mix of read and unread
const sampleNotifications = [
  {
    id: 1,
    user: "Sarah Johnson",
    action: "liked your photo from Bali trip.",
    description: "Sunset at Tanah Lot Temple looks amazing!",
    type: "like",
    time: "2m ago",
    timeDetailed: "Today at 3:45 PM",
    read: false, // Unread
    avatar: "https://randomuser.me/api/portraits/women/44.jpg",
    actionColor: "#FF4458" // Example color for like
  },
  {
    id: 2,
    user: "John Martinez",
    action: "commented on your trip to Paris.",
    description: "The Eiffel Tower view is spectacular! Did you visit the Louvre too?",
    type: "comment",
    time: "15m ago",
    timeDetailed: "Today at 3:32 PM",
    read: false, // Unread
    avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    actionColor: "#147DFF" // Example color for comment
  },
  {
    id: 3,
    user: "Emily Wong",
    action: "started following you.",
    description: null,
    type: "follow",
    time: "1h ago",
    timeDetailed: "Today at 2:47 PM",
    read: false, // Unread
    avatar: "https://randomuser.me/api/portraits/women/22.jpg",
    actionColor: "#26C281" // Example color for follow
  },
  {
    id: 4,
    user: "Travel Buddies Group",
    action: "added a new trip to Japan in Spring 2024.",
    description: "Cherry blossom season in Tokyo and Kyoto!",
    type: "trip",
    time: "3h ago",
    timeDetailed: "Today at 12:15 PM",
    read: true, // Read
    avatar: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e", // Example group avatar
    actionColor: "#8E44AD" // Example color for trip
  },
  {
    id: 5,
    user: "Michael Reeves",
    action: "liked your comment on Tokyo food guide.",
    description: "Your ramen recommendations were spot on!",
    type: "like",
    time: "5h ago",
    timeDetailed: "Today at 10:22 AM",
    read: true, // Read
    avatar: "https://randomuser.me/api/portraits/men/41.jpg",
    actionColor: "#FF4458"
  },
  {
    id: 6,
    user: "Anna Petrova",
    action: "invited you to collaborate on a trip plan.",
    description: "Weekend getaway to Santorini in August",
    type: "trip",
    time: "6h ago",
    timeDetailed: "Today at 9:05 AM",
    read: false, // Unread
    avatar: "https://randomuser.me/api/portraits/women/68.jpg",
    actionColor: "#8E44AD"
  },
  {
    id: 7,
    user: "Carlos Rodriguez",
    action: "commented on your photo from New York.",
    description: "The skyline view from Brooklyn Bridge is unmatched!",
    type: "comment",
    time: "Yesterday",
    timeDetailed: "Yesterday at 8:36 PM",
    read: true, // Read
    avatar: "https://randomuser.me/api/portraits/men/70.jpg",
    actionColor: "#147DFF"
  },
  {
    id: 8,
    user: "TravelMagazine",
    action: "featured your Machu Picchu photo in their collection.",
    description: "Your photo was selected for 'Best Mountain Views 2023'",
    type: "like",
    time: "Yesterday",
    timeDetailed: "Yesterday at 3:12 PM",
    read: false, // Unread
    avatar: "https://images.unsplash.com/photo-1512100356356-de1b84283e18", // Example magazine avatar
    actionColor: "#FF4458"
  },
  {
    id: 9,
    user: "Priya Sharma",
    action: "started following you.",
    description: null,
    type: "follow",
    time: "2 days ago",
    timeDetailed: "Monday at 5:47 PM",
    read: true, // Read
    avatar: "https://randomuser.me/api/portraits/women/91.jpg",
    actionColor: "#26C281"
  },
  {
    id: 10,
    user: "David Wilson",
    action: "shared your Iceland trip itinerary.",
    description: "This is perfect for my upcoming trip. Thanks for sharing!",
    type: "trip",
    time: "3 days ago",
    timeDetailed: "Sunday at 11:30 AM",
    read: true, // Read
    avatar: "https://randomuser.me/api/portraits/men/81.jpg",
    actionColor: "#8E44AD"
  },
  {
    id: 11,
    user: "Lisa Chen",
    action: "commented on your Vietnam travel tips.",
    description: "Your street food recommendations in Hanoi were amazing!",
    type: "comment",
    time: "5 days ago",
    timeDetailed: "Last Friday at 2:18 PM",
    read: true, // Read
    avatar: "https://randomuser.me/api/portraits/women/79.jpg",
    actionColor: "#147DFF"
  },
  {
    id: 12,
    user: "Travel & Photography Group",
    action: "invited you to join their upcoming workshop.",
    description: "Advanced travel photography workshop in Barcelona, Spain",
    type: "trip",
    time: "1 week ago",
    timeDetailed: "June 10 at 9:00 AM",
    read: false, // Unread
    avatar: "https://images.unsplash.com/photo-1542038784456-1ea8e935640e", // Example group avatar
    actionColor: "#8E44AD"
  }
];


const NotificationContext = createContext();

export function NotificationProvider({ children }) {
  const [notifications, setNotifications] = useState(sampleNotifications);
  const [modalOpen, setModalOpen] = useState(false); // State for the full notification modal

  const markAsRead = id => {
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Delete a specific notification
  const deleteNotification = id => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Clear all notifications
  const clearAllNotifications = () => {
    setNotifications([]);
  };

  // Functions to control the modal state
  const openNotificationModal = () => setModalOpen(true);
  const closeNotificationModal = () => setModalOpen(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        markAsRead,
        markAllAsRead,
        deleteNotification, // Add delete function
        clearAllNotifications, // Add clear all function
        unreadCount,
        modalOpen, // Provide modal state
        openNotificationModal, // Provide function to open modal
        closeNotificationModal, // Provide function to close modal
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotification() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
}