import React from 'react';
import { Card, CardContent, Typography, Avatar, Box, Divider, Link, IconButton, useTheme } from '@mui/material';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import avatarHazem from '../assets/images/hazem.jpg';
import avatarHany from '../assets/images/hany.jpg';

const suggestions = [
  { name: 'Omar Ahmed', avatar: avatarHazem },
  { name: 'Ahmed Abdelmoneim', avatar: avatarHazem },
  { name: 'Mohamed Ramdan', avatar: avatarHazem },
  { name: 'Ahmed Moghazy', avatar: avatarHazem },
];

const friends = [
  { name: 'Mostafa Islam', avatar: avatarHany },
  { name: 'Mohamed Yousry', avatar: avatarHany },
  { name: 'Khalid Osama', avatar: avatarHany },
  { name: 'Mohamed Medhat', avatar: avatarHany },
];

export default function People(props) {
  const theme = useTheme();
  const isDarkMode = theme.palette.mode === 'dark';
  
  return (
    <Card sx={{ borderRadius: 3, minWidth: 250, margin: 'auto'}}>
      <Box display="flex" justifyContent="space-between" alignItems="center" px={2} py={1}>
        <Typography variant="subtitle1" fontWeight="bold">{props.type === "suggestions" ? "Suggestions +" : "Friends"}</Typography>
        <IconButton size="small"><MoreHorizIcon fontSize="small" /></IconButton>
      </Box>
      <Divider />
      <CardContent sx={{ py: 1 }}>
        {props.type === "suggestions" ? suggestions.map((s, i) => (
          <Box key={i} display="flex" alignItems="center" mb={1.5}>
            <Avatar src={s.avatar} sx={{ width: 35, height: 35, mr: 1.5 }} />
            <Typography variant="body2">{s.name}</Typography>
          </Box>
        )) : friends.map((s, i) => (
          <Box key={i} display="flex" alignItems="center" mb={1.5}>
            <Avatar src={s.avatar} sx={{ width: 35, height: 35, mr: 1.5 }} />
            <Typography variant="body2">{s.name}</Typography>
          </Box>
        ))
        }
      </CardContent>
      <Box 
        textAlign="center" 
        py={1} 
        sx={isDarkMode ? {
          // Dark mode styles
          backgroundColor: '#3a3b3c', 
          borderTop: '1px solid #4a4b4c',
          transition: 'background-color 0.3s ease',
          '&:hover': { backgroundColor: '#4a4b4c' }
        } : {
          // Light mode styles - exactly as original
          backgroundColor: '#f6f9ff', 
          borderTop: '1px solid #eee'
        }}
      >
        <Link 
          href="#" 
          underline="hover" 
          fontSize={14}
          sx={isDarkMode ? {
            // Dark mode link styles
            color: theme.palette.primary.main,
            fontWeight: 500,
            transition: 'color 0.2s ease',
            '&:hover': { color: '#90caf9' }
          } : {
            // Light mode link - no custom styling as per original
          }}
        >
          See More
        </Link>
      </Box>
    </Card>
  );
}