import React, { useState, useEffect, useRef } from 'react';
import {
  IconButton, 
  Badge, 
  Menu, 
  Typography, 
  Box, 
  Avatar, 
  Button, 
  Modal,
  Fade,
  Slide,
  styled,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  alpha,
  useTheme,
  InputAdornment,
  TextField
} from '@mui/material';
import NotificationsIcon from '@mui/icons-material/Notifications';
import FavoriteIcon from '@mui/icons-material/Favorite';
import ChatBubbleIcon from '@mui/icons-material/ChatBubble';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import MapIcon from '@mui/icons-material/Map';
import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import DeleteSweepIcon from '@mui/icons-material/DeleteSweep';
import CheckIcon from '@mui/icons-material/Check';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import { useNotification } from '../context/NotificationContext';

// Custom styled notification button matching the search design
const NotificationButton = styled(IconButton)(({ theme }) => ({
  width: 48,
  height: 48,
  backgroundColor: theme.palette.mode === 'dark' 
    ? alpha(theme.palette.common.white, 0.08)
    : alpha(theme.palette.common.black, 0.04),
  borderRadius: '50%',
  border: `1px solid ${theme.palette.divider}`,
  marginRight: 12,
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  '&:hover': {
    backgroundColor: theme.palette.mode === 'dark' 
      ? alpha(theme.palette.common.white, 0.12)
      : alpha(theme.palette.common.black, 0.06),
    transform: 'translateY(-2px)',
    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.15)',
  },
  '&:active': {
    transform: 'translateY(0px)',
  },
}));

// Custom styled dialog matching search modal exactly
const NotificationDialog = styled(Modal)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  '& .MuiPaper-root': {
    width: '680px', // Increased from 580px
    maxWidth: '95%', // Increased from 90%
    height: '85vh', // Increased from 75vh
    maxHeight: '950px', // Increased from 850px
    borderRadius: '16px',
    overflow: 'hidden',
    boxShadow: '0 12px 28px rgba(0, 0, 0, 0.2)',
    margin: '40px auto',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    backgroundColor: theme.palette.background.paper,
  },
  '& .MuiBackdrop-root': {
    backgroundColor: theme.palette.mode === 'dark' 
      ? 'rgba(0, 0, 0, 0.7)' 
      : 'rgba(255, 255, 255, 0.5)',
    backdropFilter: 'blur(8px)'
  }
}));

// Styled search input matching exactly
const SearchInput = styled(TextField)(({ theme }) => ({
  '& .MuiInputBase-root': {
    borderRadius: 50,
    backgroundColor: theme.palette.mode === 'dark' 
      ? alpha(theme.palette.common.white, 0.08)
      : alpha(theme.palette.common.black, 0.04),
    transition: theme.transitions.create([
      'background-color',
      'box-shadow',
    ]),
    '&:hover': {
      backgroundColor: theme.palette.mode === 'dark' 
        ? alpha(theme.palette.common.white, 0.12)
        : alpha(theme.palette.common.black, 0.06),
    },
    '&.Mui-focused': {
      backgroundColor: theme.palette.mode === 'dark' 
        ? alpha(theme.palette.common.white, 0.12)
        : alpha(theme.palette.common.black, 0.06),
      boxShadow: `0 0 0 1px ${theme.palette.primary.main}`,
    },
  },
  '& .MuiOutlinedInput-notchedOutline': {
    border: 'none',
  },
}));

// Transition effect matching search modal
const SlideTransition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="down" ref={ref} {...props} />;
});

// Menu styled to match search design
const StyledMenu = styled(Menu)(({ theme }) => ({
  '& .MuiPaper-root': {
    width: '420px',
    maxWidth: '90%',
    maxHeight: '70vh', // Increased from default to allow more scrolling
    borderRadius: '16px',
    overflow: 'hidden',
    boxShadow: '0 12px 28px rgba(0, 0, 0, 0.2)',
    marginTop: 8,
  },
}));

export default function NotificationIcon({ mode = "menu" }) {
  const theme = useTheme();
  const { 
    notifications, 
    markAsRead, 
    markAllAsRead, 
    deleteNotification, 
    clearAllNotifications, 
    unreadCount, 
    modalOpen, 
    openNotificationModal, 
    closeNotificationModal 
  } = useNotification();
  
  const [anchorEl, setAnchorEl] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredNotifications, setFilteredNotifications] = useState(notifications);
  const searchInputRef = useRef(null);

  const limitedNotifications = filteredNotifications.slice(0, 10);

  // Filter notifications based on search query
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredNotifications(notifications);
    } else {
      const filtered = notifications.filter(notification =>
        notification.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
        notification.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (notification.description && notification.description.toLowerCase().includes(searchQuery.toLowerCase()))
      );
      setFilteredNotifications(filtered);
    }
  }, [searchQuery, notifications]);

  const handleBellClick = (event) => {
    if (mode === "modal") {
      openNotificationModal();
    } else {
      setAnchorEl(event.currentTarget);
    }
  };
  
  const closeMenu = () => {
    setAnchorEl(null);
    setSearchQuery('');
  };

  const handleNotificationClick = (notificationId) => {
    markAsRead(notificationId);
  };

  const handleDeleteNotification = (notificationId, event) => {
    event.stopPropagation();
    deleteNotification(notificationId);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    searchInputRef.current?.focus();
  };

  const openAllNotificationsModal = () => {
    closeMenu();
    openNotificationModal();
  };

  const getNotificationIcon = (type) => {
    const iconProps = { fontSize: 'small' };
    switch (type) {
      case 'like':
        return <FavoriteIcon sx={{ ...iconProps, color: '#ff4458' }} />;
      case 'comment':
        return <ChatBubbleIcon sx={{ ...iconProps, color: '#2196f3' }} />;
      case 'follow':
        return <PersonAddIcon sx={{ ...iconProps, color: '#4caf50' }} />;
      case 'trip':
        return <MapIcon sx={{ ...iconProps, color: '#ff9800' }} />;
      default:
        return <NotificationsIcon sx={{ ...iconProps, color: 'primary.main' }} />;
    }
  };

  const NotificationItem = ({ notification, isLast = false, showDetailedTime = false }) => (
    <ListItem 
      component="div"
      onClick={() => handleNotificationClick(notification.id)}
      alignItems="flex-start"
      sx={{ 
        py: 2,
        px: 1.5,
        borderRadius: 1,
        mb: 0.5,
        backgroundColor: !notification.read ? 
          alpha(theme.palette.primary.main, 0.05) : 'transparent',
        '&:hover': {
          backgroundColor: alpha(theme.palette.primary.main, 0.08)
        },
        position: 'relative',
        cursor: 'pointer'
      }}
    >
      <ListItemAvatar>
        <Box sx={{ position: 'relative' }}>
          <Avatar 
            src={notification.avatar} 
            alt={notification.user} 
            sx={{ 
              width: 48, 
              height: 48,
              border: !notification.read ? `2px solid ${theme.palette.primary.main}` : '2px solid transparent',
            }}
          />
          <Box sx={{
            position: 'absolute',
            bottom: -4,
            right: -4,
            width: 24,
            height: 24,
            borderRadius: '50%',
            backgroundColor: 'background.paper',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
            border: '2px solid',
            borderColor: 'background.paper'
          }}>
            {getNotificationIcon(notification.type)}
          </Box>
        </Box>
      </ListItemAvatar>
      <ListItemText 
        primary={
          <Box component="div">
            <Typography 
              variant="subtitle2" 
              component="span"
              sx={{ 
                fontWeight: !notification.read ? 700 : 500,
                display: 'inline'
              }}
            >
              {notification.user}
            </Typography>
            <Typography 
              variant="body2" 
              component="span"
              sx={{ 
                ml: 0.5,
                color: 'text.secondary',
                fontWeight: !notification.read ? 500 : 400
              }}
            >
              {notification.action}
            </Typography>
          </Box>
        }
        secondary={
          <Box component="div" sx={{ mt: 0.5 }}>
            {notification.description && (
              <Typography
                variant="body2"
                component="span"
                sx={{
                  color: 'text.secondary',
                  fontStyle: 'italic',
                  fontSize: '0.875rem',
                  mb: 0.5,
                  display: 'block'
                }}
              >
                {notification.description}
              </Typography>
            )}
            <Box component="div" sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'space-between',
              mt: 0.5
            }}>
              <Typography variant="caption" component="span" color="text.secondary">
                {showDetailedTime ? notification.timeDetailed : notification.time}
              </Typography>
              <IconButton 
                size="small" 
                onClick={(e) => handleDeleteNotification(notification.id, e)}
                sx={{
                  opacity: 0.6,
                  '&:hover': {
                    opacity: 1,
                    color: 'error.main',
                    backgroundColor: alpha(theme.palette.error.main, 0.1)
                  }
                }}
              >
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Box>
          </Box>
        }
      />
      {!notification.read && (
        <Box sx={{
          position: 'absolute',
          right: 16,
          top: '50%',
          transform: 'translateY(-50%)',
          width: 8,
          height: 8,
          borderRadius: '50%',
          backgroundColor: 'primary.main',
          boxShadow: `0 0 10px ${alpha(theme.palette.primary.main, 0.5)}`
        }} />
      )}
    </ListItem>
  );

  const EmptyState = ({ message, subtitle, icon }) => (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      p: 4,
      height: '60%',
      minHeight: 200
    }}>
      {icon}
      <Typography variant="h6" gutterBottom>
        {message}
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', maxWidth: 300 }}>
        {subtitle}
      </Typography>
    </Box>
  );

  return (
    <>
      {/* Notification Bell */}
      <NotificationButton 
        onClick={handleBellClick}
        data-notification-icon="true"
      >
        <Badge
          badgeContent={unreadCount}
          sx={{
            '& .MuiBadge-badge': {
              backgroundColor: '#ff4458',
              color: 'white',
              fontSize: '11px',
              fontWeight: 700,
              minWidth: '20px',
              height: '20px',
              borderRadius: '10px',
              border: '2px solid',
              borderColor: 'background.paper',
              boxShadow: '0 2px 8px rgba(255, 68, 88, 0.4)',
              animation: unreadCount > 0 ? 'pulse 2s infinite' : 'none',
              '@keyframes pulse': {
                '0%': { transform: 'scale(1)' },
                '50%': { transform: 'scale(1.1)' },
                '100%': { transform: 'scale(1)' }
              }
            }
          }}
        >
          <NotificationsIcon sx={{ fontSize: 24 }} />
        </Badge>
      </NotificationButton>

      {/* Preview Menu */}
      <StyledMenu
        anchorEl={anchorEl}
        open={Boolean(anchorEl) && mode === "menu"}
        onClose={closeMenu}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        TransitionComponent={Fade}
        sx={{
          '& .MuiPaper-root': {
            maxHeight: 'calc(100vh - 80px)',
            position: 'fixed',
            right: 16,
            top: '72px !important',
            left: 'auto !important',
            transform: 'none !important',
            display: 'flex',
            flexDirection: 'column',
          },
        }}
      >
        <Box sx={{ 
          position: 'sticky', 
          top: 0, 
          zIndex: 2,
          bgcolor: 'background.paper',
          borderBottom: 1, 
          borderColor: 'divider',
          px: 2,
          py: 1.5
        }}>
          <Box display="flex" alignItems="center" justifyContent="space-between" mb={1}>
            <Box display="flex" alignItems="center">
              <NotificationsIcon sx={{ mr: 1, color: 'primary.main' }} />
              <Typography variant="h6">Notifications</Typography>
              {unreadCount > 0 && (
                <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                  ({unreadCount} new)
                </Typography>
              )}
            </Box>
            <IconButton size="small" onClick={closeMenu}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
          
          <SearchInput
            fullWidth
            size="small"
            placeholder="Search notifications..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoComplete="off"
            inputRef={searchInputRef}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
              endAdornment: searchQuery && (
                <InputAdornment position="end">
                  <IconButton onClick={handleClearSearch} edge="end" size="small">
                    <ClearIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              )
            }}
          />

          {/* Action buttons */}
          {(unreadCount > 0 || notifications.length > 0) && (
            <Box sx={{ display: 'flex', gap: 1, mt: 1.5 }}>
              {unreadCount > 0 && (
                <Button
                  size="small"
                  startIcon={<CheckIcon />}
                  onClick={markAllAsRead}
                  sx={{ 
                    textTransform: 'none',
                    borderRadius: 6,
                    bgcolor: alpha(theme.palette.primary.main, 0.1),
                    color: 'primary.main',
                    '&:hover': {
                      bgcolor: alpha(theme.palette.primary.main, 0.15)
                    }
                  }}
                >
                  Mark all read
                </Button>
              )}
              {notifications.length > 0 && (
                <Button
                  size="small"
                  startIcon={<DeleteSweepIcon />}
                  onClick={clearAllNotifications}
                  sx={{ 
                    textTransform: 'none',
                    borderRadius: 6,
                    bgcolor: alpha(theme.palette.error.main, 0.1),
                    color: 'error.main',
                    '&:hover': {
                      bgcolor: alpha(theme.palette.error.main, 0.15)
                    }
                  }}
                >
                  Clear all
                </Button>
              )}
            </Box>
          )}
        </Box>
        
        <Box sx={{ 
          flex: 1, // Make this box take remaining space
          overflowY: 'auto', // Enable scrolling
          height: 'auto', // Let it grow based on content
          maxHeight: '50vh', // Limit maximum height for scrolling
        }}>
          {limitedNotifications.length === 0 ? (
            searchQuery ? (
              <EmptyState
                message="No matching notifications"
                subtitle={`No notifications found for "${searchQuery}"`}
                icon={<SearchIcon sx={{ fontSize: 48, color: 'text.secondary', opacity: 0.4, mb: 1 }} />}
              />
            ) : (
              <EmptyState
                message="All caught up!"
                subtitle="You're all set. We'll notify you when something new happens."
                icon={<NotificationsIcon sx={{ fontSize: 48, color: 'text.secondary', opacity: 0.4, mb: 1 }} />}
              />
            )
          ) : (
            <List disablePadding sx={{ p: 1 }}>
              {limitedNotifications.map((notification, index) => (
                <NotificationItem
                  key={notification.id}
                  notification={notification}
                  isLast={index === limitedNotifications.length - 1}
                />
              ))}
            </List>
          )}
        </Box>

        <Box sx={{
          p: 2,
          borderTop: 1,
          borderColor: 'divider',
          bgcolor: alpha(theme.palette.background.default, 0.3)
        }}>
          <Button
            fullWidth
            variant="outlined"
            onClick={openAllNotificationsModal}
            sx={{
              borderRadius: 6,
              textTransform: 'none',
              fontWeight: 600
            }}
          >
            View all notifications
          </Button>
        </Box>
      </StyledMenu>

      {/* Full Page Modal */}
      <NotificationDialog
        open={modalOpen}
        onClose={closeNotificationModal}
        transitionComponent={SlideTransition}
        keepMounted
      >
        <Box sx={{ 
          width: '680px',
          maxWidth: '95%',
          height: '85vh',
          maxHeight: '950px',
          borderRadius: '16px',
          overflow: 'hidden',
          bgcolor: 'background.paper',
          display: 'flex',
          flexDirection: 'column'
        }}>
          {/* Header */}
          <Box sx={{ 
            position: 'sticky', 
            top: 0, 
            zIndex: 2,
            bgcolor: 'background.paper',
            borderBottom: 1, 
            borderColor: 'divider',
            px: 2,
            py: 1.5
          }}>
            <Box display="flex" alignItems="center" justifyContent="space-between" mb={1}>
              <Box display="flex" alignItems="center">
                <NotificationsIcon sx={{ mr: 1, color: 'primary.main' }} />
                <Typography variant="h6">All Notifications</Typography>
                <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                  ({notifications.length} total)
                </Typography>
              </Box>
              <IconButton size="small" onClick={closeNotificationModal}>
                <CloseIcon fontSize="small" />
              </IconButton>
            </Box>
            
            <SearchInput
              fullWidth
              size="small"
              placeholder="Search all notifications..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoComplete="off"
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon fontSize="small" />
                  </InputAdornment>
                ),
                endAdornment: searchQuery && (
                  <InputAdornment position="end">
                    <IconButton onClick={handleClearSearch} edge="end" size="small">
                      <ClearIcon fontSize="small" />
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />

            {/* Action buttons */}
            {(unreadCount > 0 || notifications.length > 0) && (
              <Box sx={{ display: 'flex', gap: 1, mt: 1.5 }}>
                {unreadCount > 0 && (
                  <Button
                    size="small"
                    startIcon={<CheckIcon />}
                    onClick={markAllAsRead}
                    sx={{ 
                      textTransform: 'none',
                      borderRadius: 6,
                      bgcolor: alpha(theme.palette.primary.main, 0.1),
                      color: 'primary.main',
                      '&:hover': {
                        bgcolor: alpha(theme.palette.primary.main, 0.15)
                      }
                    }}
                  >
                    Mark all read ({unreadCount})
                  </Button>
                )}
                {notifications.length > 0 && (
                  <Button
                    size="small"
                    startIcon={<DeleteSweepIcon />}
                    onClick={clearAllNotifications}
                    sx={{ 
                      textTransform: 'none',
                      borderRadius: 6,
                      bgcolor: alpha(theme.palette.error.main, 0.1),
                      color: 'error.main',
                      '&:hover': {
                        bgcolor: alpha(theme.palette.error.main, 0.15)
                      }
                    }}
                  >
                    Clear all
                  </Button>
                )}
              </Box>
            )}
          </Box>
          
          {/* Content */}
          <Box sx={{ 
            flex: 1,
            overflowY: 'auto',
            maxHeight: 'calc(85vh - 150px)', // Ensure content is scrollable
          }}>
            {filteredNotifications.length === 0 ? (
              searchQuery ? (
                <EmptyState
                  message="No matching notifications"
                  subtitle={`No notifications found for "${searchQuery}". Try different keywords.`}
                  icon={<SearchIcon sx={{ fontSize: 60, color: 'text.secondary', opacity: 0.4, mb: 2 }} />}
                />
              ) : (
                <EmptyState
                  message="All caught up!"
                  subtitle="You're all set. We'll notify you when something new happens."
                  icon={<NotificationsIcon sx={{ fontSize: 60, color: 'text.secondary', opacity: 0.4, mb: 2 }} />}
                />
              )
            ) : (
              <List disablePadding sx={{ p: 1 }}>
                {filteredNotifications.map((notification, index) => (
                  <NotificationItem
                    key={notification.id}
                    notification={notification}
                    isLast={index === filteredNotifications.length - 1}
                    showDetailedTime={true}
                  />
                ))}
              </List>
            )}
          </Box>

          {/* Footer */}
          <Box sx={{
            p: 2,
            borderTop: 1,
            borderColor: 'divider',
            bgcolor: alpha(theme.palette.background.default, 0.3)
          }}>
            <Button
              fullWidth
              variant="outlined"
              onClick={closeNotificationModal}
              sx={{
                borderRadius: 6,
                textTransform: 'none',
                fontWeight: 600
              }}
            >
              Close
            </Button>
          </Box>
        </Box>
      </NotificationDialog>
    </>
  );
}