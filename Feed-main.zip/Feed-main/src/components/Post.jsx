/** @jsxImportSource @emotion/react */
import React, { useState, useEffect, useRef } from 'react';
import {
  Avatar,
  Box,
  Card,
  CardMedia,
  CardContent,
  CardActions,
  IconButton,
  Typography,
  Dialog,
  DialogContent,
  Chip,
  Tooltip,
  TextField,
  Button,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  CircularProgress,
  Paper,
  InputBase,
  Divider,
  Popover,
  ListItemAvatar,
} from '@mui/material';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import FavoriteIcon from '@mui/icons-material/Favorite';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import ShareIcon from '@mui/icons-material/Share';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import OpenInFullIcon from '@mui/icons-material/OpenInFull';
import CloseIcon from '@mui/icons-material/Close';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import MapIcon from '@mui/icons-material/Map';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import PublicIcon from '@mui/icons-material/Public';
import PeopleIcon from '@mui/icons-material/People';
import LockIcon from '@mui/icons-material/Lock';
import EditIcon from '@mui/icons-material/Edit';
import PhotoIcon from '@mui/icons-material/Image';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import EmojiEmotionsIcon from '@mui/icons-material/EmojiEmotions';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import SearchIcon from '@mui/icons-material/Search';
import MyLocationIcon from '@mui/icons-material/MyLocation';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import DeleteIcon from '@mui/icons-material/Delete';
import SaveIcon from '@mui/icons-material/Save';
import NotificationsOffIcon from '@mui/icons-material/NotificationsOff';
import { css, keyframes } from '@emotion/react';
import CommentSection from './Comment';
import { motion, AnimatePresence } from 'framer-motion';
import EmojiPicker from 'emoji-picker-react';
import { useTheme } from '@mui/material/styles';
import { Fade } from '@mui/material';
import { usePostContext } from '../context/PostContext';
import { useSavedPostContext } from '../context/SavedPostContext';
import { commentService } from '../services/networkService';

// Import for map
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icons in Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const fadeInOut = keyframes`
  0% { opacity: 0; transform: scale(0.6); }
  30% { opacity: 1; transform: scale(1.4); }
  100% { opacity: 0; transform: scale(1); }
`;

const MAX_TEXT_LENGTH = 150;

// Default center coordinates (Egypt)
const defaultCenter = [30.0444, 31.2357];

// Map view controller component
function MapController({ center, zoom }) {
  const map = useMap();
  map.setView(center, zoom);
  return null;
}

// Map click handler component
function LocationMarker({ onLocationSelect, position, setPosition }) {
  useMapEvents({
    click: async (e) => {
      const { lat, lng } = e.latlng;
      setPosition([lat, lng]);
      
      try {
        // Reverse geocoding using OpenStreetMap's Nominatim
        const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
          { headers: { 'Accept-Language': 'en' } }
        );
        const data = await response.json();
        
        if (data && data.display_name) {
          onLocationSelect({
            lat,
            lng,
            name: data.display_name,
            placeId: data.place_id
          });
        } else {
          // Fallback if geocoding fails
          onLocationSelect({
            lat,
            lng,
            name: `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
          });
        }
      } catch (error) {
        console.error("Error during reverse geocoding:", error);
        onLocationSelect({
          lat,
          lng,
          name: `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
        });
      }
    },
  });

  return position ? <Marker position={position} /> : null;
}

// Create a styled slider component
const PhotoSlider = ({ total, active, onSliderChange }) => {
  return (
    <Box 
      sx={{ 
        position: 'absolute', 
        bottom: 16, 
        left: '50%',
        transform: 'translateX(-50%)',
        width: '80%',
        maxWidth: '300px',
        height: 4,
        bgcolor: 'rgba(255,255,255,0.3)',
        borderRadius: 2,
        zIndex: 1,
        cursor: 'pointer',
        overflow: 'hidden'
      }}
      onClick={(e) => {
        // Calculate click position relative to slider width
        const rect = e.currentTarget.getBoundingClientRect();
        const clickPos = (e.clientX - rect.left) / rect.width;
        const newIndex = Math.floor(clickPos * total);
        onSliderChange(Math.min(Math.max(newIndex, 0), total - 1));
      }}
    >
      {/* Animated active section */}
      <motion.div
        initial={false}
        animate={{
          width: `${(1/total) * 100}%`,
          x: `${active * (100/total) * (total/(total-1 || 1))}%`
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        style={{
          height: '100%',
          backgroundColor: '#fff',
          borderRadius: 4,
          position: 'absolute',
          top: 0,
          left: 0
        }}
      />
      
      {/* Segment markers */}
      {Array.from({ length: total }).map((_, i) => (
        <Box
          key={i}
          sx={{
            position: 'absolute',
            height: '100%',
            width: 1,
            bgcolor: 'rgba(255,255,255,0.5)',
            left: `${(i / total) * 100}%`,
            display: i === 0 || i === total ? 'none' : 'block'
          }}
        />
      ))}
    </Box>
  );
};

function PostCard({ post, onPostUpdated }) {
  const theme = useTheme();
  const isDarkMode = theme.palette.mode === 'dark';
  const { user, time, contentType, contentSrc, isFirstPost } = post;
  const { updatePost } = usePostContext();
  
  // Debug log for onPostUpdated prop
  console.log('onPostUpdated prop:', onPostUpdated);
  
  // Get context for saved posts
  const { savedPosts, addSavedPost, removeSavedPost } = useSavedPostContext();
  
  // Create state variables for editable properties
  const [text, setText] = useState(post.text || '');
  const [privacy, setPrivacy] = useState(post.privacy || 'public');
  const [location, setLocation] = useState(post.location);
  
  // Other states
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes || 0);
  const [showComments, setShowComments] = useState(false);
  const [showHeart, setShowHeart] = useState(false);
  const [expandedView, setExpandedView] = useState(false);
  const [expandedText, setExpandedText] = useState(false);
  const [showLocationMap, setShowLocationMap] = useState(false);
  // For multiple photos navigation
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [slideDirection, setSlideDirection] = useState('next');
  const carouselRef = useRef(null);
  // Comments state
  const [comments, setComments] = useState([]);
  const [commentsLoading, setCommentsLoading] = useState(false);
  const [commentsError, setCommentsError] = useState(null);
  const [commentsPage, setCommentsPage] = useState(1);
  const [hasMoreComments, setHasMoreComments] = useState(true);
  const COMMENTS_PER_PAGE = 10;
  
  // Add missing isSaved state
  const [isSaved, setIsSaved] = useState(false);
  
  // Edit post states
  const [editMode, setEditMode] = useState(false);
  const [editedText, setEditedText] = useState(text);
  const [editedPrivacy, setEditedPrivacy] = useState(privacy);
  const [editedLocation, setEditedLocation] = useState(location);
  const [isUpdating, setIsUpdating] = useState(false);
  const [privacyMenuAnchor, setPrivacyMenuAnchor] = useState(null);
  const [optionsAnchorEl, setOptionsAnchorEl] = useState(null);
  
  // Add delete confirmation dialog state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Edit location states
  const [locationAnchorEl, setLocationAnchorEl] = useState(null);
  const [mapCenter, setMapCenter] = useState(location ? [location.lat, location.lng] : defaultCenter);
  const [mapZoom, setMapZoom] = useState(13);
  const [markerPosition, setMarkerPosition] = useState(location ? [location.lat, location.lng] : null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMapLoading, setIsMapLoading] = useState(false);
  
  // Emoji picker state
  const [emojiAnchorEl, setEmojiAnchorEl] = useState(null);
  const textFieldRef = useRef(null);

  // Check if post has media and if it's an array of multiple media items
  const hasMedia = contentType === 'image' || contentType === 'video';
  const hasMultipleMedia = hasMedia && Array.isArray(contentSrc) && contentSrc.length > 1;
  
  // Get current media source
  const getCurrentMedia = () => {
    if (!hasMedia) return null;
    
    if (Array.isArray(contentSrc)) {
      return contentSrc[currentImageIndex];
    }
    
    return contentSrc;
  };
  
  // Ensure post has a consistent ID and reflects latest changes
  const postWithId = React.useMemo(() => ({
    ...post,
    id: post.id || `post-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
    text: text,
    privacy: privacy,
    location: location
  }), [post, text, privacy, location]);

  // Debug log for postWithId
  console.log('PostCard postWithId:', postWithId);

  // Sync state with post props when they change
  useEffect(() => {
    console.log("Post updated from parent:", post);
    setText(post.text || '');
    setPrivacy(post.privacy || 'public');
    setLocation(post.location);
  }, [post]);
  
  // Update edited values when entering edit mode or when state changes
  useEffect(() => {
    if (editMode) {
      setEditedText(text);
      setEditedPrivacy(privacy);
      setEditedLocation(location);
    }
  }, [editMode, text, privacy, location]);
  
  // Check if post is saved
  useEffect(() => {
    if (savedPosts) {
      const isPostSaved = savedPosts.some(savedPost => 
        savedPost.id === postWithId.id || 
        (savedPost.contentSrc === postWithId.contentSrc && savedPost.time === postWithId.time)
      );
      setIsSaved(isPostSaved);
    }
  }, [savedPosts, postWithId.id, postWithId.contentSrc, postWithId.time]);

  // Debug rendering
  useEffect(() => {
    console.log("PostCard rendering with:", {
      post,
      localText: text,
      localPrivacy: privacy,
      localLocation: location,
      editedText,
      editedPrivacy,
      editedLocation,
      isSaved
    });
  }, [post, text, privacy, location, editedText, editedPrivacy, editedLocation, isSaved]);

  // Initialize edited location when opening edit mode
  useEffect(() => {
    if (editMode && location) {
      setEditedLocation(location);
      setMapCenter([location.lat, location.lng]);
      setMarkerPosition([location.lat, location.lng]);
    }
  }, [editMode, location]);

  // Check if text is long enough to need truncation
  const isTextLong = text.length > MAX_TEXT_LENGTH;

  // Check if the post belongs to the current user (for edit functionality)
  const isCurrentUserPost = () => {
    return user.name === 'Mohamed Hazem' || user.name === 'You';
  };

  // Get privacy icon based on post privacy
  const getPrivacyIcon = (privacyLevel = privacy) => {
    switch (privacyLevel) {
      case 'public':
        return <PublicIcon fontSize="small" sx={{ color: 'text.secondary' }} />;
      case 'friends':
        return <PeopleIcon fontSize="small" sx={{ color: 'text.secondary' }} />;
      case 'only_me':
        return <LockIcon fontSize="small" sx={{ color: 'text.secondary' }} />;
      default:
        return <PublicIcon fontSize="small" sx={{ color: 'text.secondary' }} />;
    }
  };

  // Get privacy label text
  const getPrivacyText = (privacyLevel = privacy) => {
    switch (privacyLevel) {
      case 'public':
        return 'Public';
      case 'friends':
        return 'Friends';
      case 'only_me':
        return 'Only me';
      default:
        return 'Public';
    }
  };

  const getTotalCommentCount = () => {
    let total = comments.length;
    comments.forEach(comment => {
      if (comment.replies && Array.isArray(comment.replies)) {
        total += comment.replies.length;
      }
    });
    return total;
  };

  // Helper function to navigate images
  const handleImageNavigation = (direction) => {
    if (!hasMultipleMedia) return;
    
    // Set direction first
    setSlideDirection(direction);
    
    // Then update the index after a small delay
    setTimeout(() => {
      if (direction === 'next') {
        setCurrentImageIndex(prev => 
          prev === contentSrc.length - 1 ? 0 : prev + 1
        );
      } else {
        setCurrentImageIndex(prev => 
          prev === 0 ? contentSrc.length - 1 : prev - 1
        );
      }
    }, 10);
  };

  // Helper to process media src
  const processMediaSrc = (src) => {
    if (!src) return '';
    
    try {
      return src.startsWith('/') ? require(`${src}`) : src;
    } catch {
      return src;
    }
  };

  function timeAgo(date) {
    const now = new Date();
    const past = date;
    const seconds = Math.floor((now - past) / 1000);
    const intervals = [
      { label: 'year', seconds: 31536000 },
      { label: 'month', seconds: 2592000 },
      { label: 'week', seconds: 604800 },
      { label: 'day', seconds: 86400 },
      { label: 'hour', seconds: 3600 },
      { label: 'minute', seconds: 60 },
      { label: 'second', seconds: 1 },
    ];
    for (const interval of intervals) {
      const count = Math.floor(seconds / interval.seconds);
      if (count > 0) {
        return `${count} ${interval.label}${count !== 1 ? 's' : ''} ago`;
      }
    }
    return 'just now';
  }

  const handleLike = () => {
    const newLiked = !liked;
    setLiked(newLiked);
    setLikeCount(prevCount => newLiked ? prevCount + 1 : Math.max(0, prevCount - 1));
  };

  const handleDoubleClick = () => {
    if (!liked) {
      setLiked(true);
      setLikeCount(prevCount => prevCount + 1);
    }
    setShowHeart(true);
    setTimeout(() => setShowHeart(false), 800);
  };

  const handleExpandClick = () => {
    setExpandedView(true);
  };

  const handleSeeMore = (e) => {
    e.preventDefault();
    setExpandedText(true); // Only set to true, no toggling back
  };

  // Handle opening location map dialog
  const handleOpenLocationMap = () => {
    setShowLocationMap(true);
      };

  // Toggle save/unsave functionality
  const handleSavePost = () => {
    console.log("Save button clicked, current state:", isSaved);
    console.log("Post to save/unsave:", postWithId);
    
    if (isSaved) {
      // If already saved, remove it
      console.log("Removing post from saved:", postWithId.id);
      removeSavedPost(postWithId);
    } else {
      // If not saved, add it
      console.log("Adding post to saved:", postWithId);
      addSavedPost(postWithId);
    }
  };

  // Handle edit button click
  const handleEditClick = (e) => {
    if (e) {
      e.stopPropagation();
    }
    setEditedText(text);
    setEditedPrivacy(privacy);
    setEditedLocation(location);
    setEditMode(true);
    console.log("Edit mode activated:", { text, privacy, location });
  };

  // Handle save edit - IMPROVED VERSION
  const handleSaveEdit = () => {
    setIsUpdating(true);
    console.log("Starting edit save process");
    
    // Create an object with the updated post data
    const updatedPost = {
      ...postWithId,
      text: editedText,
      privacy: editedPrivacy,
      location: editedLocation,
      likes: likeCount // Preserve the like count
    };
    
    console.log("Saving edits:", {
      before: postWithId,
      after: updatedPost
    });
    
    // Update local state to reflect changes immediately
    setText(editedText);
    setPrivacy(editedPrivacy);
    setLocation(editedLocation);
    
    // Update the post in the context to persist changes
    updatePost(updatedPost);
    
    // If the post is saved, update it in saved posts as well
    if (isSaved) {
      console.log("Post is saved, updating in saved posts");
      removeSavedPost(postWithId);
      addSavedPost(updatedPost);
    }
    
    // If onPostUpdated is provided, call it with the updated post
    if (onPostUpdated) {
      console.log("Calling parent onPostUpdated with:", updatedPost);
      onPostUpdated(updatedPost);
    } else {
      console.warn("No onPostUpdated function provided");
    }
    
    // For demo purposes, we'll close the dialog and update local state
    setTimeout(() => {
      console.log("Edit completed");
      setIsUpdating(false);
      setEditMode(false);
    }, 500);
  };

  // Handle emoji picker toggle
  const handleEmojiClick = (event) => {
    setEmojiAnchorEl(event.currentTarget);
  };

  const handleEmojiClose = () => {
    setEmojiAnchorEl(null);
  };

  // Handle emoji selection
  const onEmojiClick = (emojiObject) => {
    // Insert emoji at current cursor position or at end
    const emoji = emojiObject.emoji;
    const textField = textFieldRef.current;
    
    if (textField) {
      const start = textField.selectionStart || editedText.length;
      const end = textField.selectionEnd || editedText.length;
      const newText = editedText.substring(0, start) + emoji + editedText.substring(end);
      setEditedText(newText);
      
      // Set cursor position after the inserted emoji
      setTimeout(() => {
        textField.selectionStart = textField.selectionEnd = start + emoji.length;
        textField.focus();
      }, 0);
    } else {
      // Fallback if direct insertion isn't possible
      setEditedText(prevText => prevText + emoji);
    }
  };

  // Handle location picker open/close
  const handleLocationClick = (event) => {
    setLocationAnchorEl(event.currentTarget);
  };

  const handleLocationClose = () => {
    setLocationAnchorEl(null);
  };

  // Handle privacy button click
  const handlePrivacyClick = (event) => {
    setPrivacyMenuAnchor(event.currentTarget);
  };
  
  // Handle privacy level selection
  const handlePrivacySelect = (level) => {
    setEditedPrivacy(level);
    setPrivacyMenuAnchor(null);
  };

  // Location handling methods
  const handleLocationSelect = (location) => {
    setEditedLocation(location);
  };

  // Handle location search
  const handleLocationSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsMapLoading(true);
    try {
      // Forward geocoding using Nominatim
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=1`,
        { headers: { 'Accept-Language': 'en' } }
      );
      const data = await response.json();
      
      if (data && data.length > 0) {
        const location = data[0];
        const lat = parseFloat(location.lat);
        const lng = parseFloat(location.lon);
        
        setMapCenter([lat, lng]);
        setMapZoom(15);
        setMarkerPosition([lat, lng]);
        
        setEditedLocation({
          lat,
          lng,
          name: location.display_name,
          placeId: location.place_id
        });
      }
    } catch (error) {
      console.error("Error during geocoding search:", error);
    } finally {
      setIsMapLoading(false);
    }
  };

  // Handle current location
  const handleCurrentLocation = () => {
    if (navigator.geolocation) {
      setIsMapLoading(true);
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          
          setMapCenter([lat, lng]);
          setMapZoom(15);
          setMarkerPosition([lat, lng]);
          
          try {
            // Reverse geocode to get current location name
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
              { headers: { 'Accept-Language': 'en' } }
            );
            const data = await response.json();
            
            if (data && data.display_name) {
              setEditedLocation({
                lat,
                lng,
                name: data.display_name,
                placeId: data.place_id
              });
            } else {
              setEditedLocation({
                lat,
                lng,
                name: `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
              });
            }
          } catch (error) {
            console.error("Error during reverse geocoding:", error);
            setEditedLocation({
              lat,
              lng,
              name: `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
            });
          } finally {
            setIsMapLoading(false);
          }
        },
        (error) => {
          console.error("Error getting current location: ", error);
          setIsMapLoading(false);
        }
      );
    }
  };

  // Handle remove selected location
  const handleRemoveLocation = () => {
    setEditedLocation(null);
    setMarkerPosition(null);
  };

  // Function to render text with "See more" if needed
  const renderText = (fullText, inExpandedView = false) => {
    if (!isTextLong || expandedText || inExpandedView) {
      return (
        <Typography variant="body1" color="#333">
          {fullText}
        </Typography>
      );
    } else {
      return (
        <Typography variant="body1" color="#333">
          {fullText.substring(0, MAX_TEXT_LENGTH)}
          {fullText.length > MAX_TEXT_LENGTH && '... '}
          <Box
            component="span"
            onClick={handleSeeMore}
            sx={{
              color: 'inherit', 
              cursor: 'pointer',
              fontWeight: 500,
              '&:hover': {
                textDecoration: 'underline',
              },
            }}
          >
            See more
          </Box>
        </Typography>
      );
    }
  };

  // Render location as text (for media posts)
  const renderLocationText = () => {
    if (!location) return null;
    
    return (
      <Box 
        sx={{
          display: 'flex',
          alignItems: 'center',
          mt: 1.5
        }}
      >
        <Chip
          icon={<LocationOnIcon sx={{ color: '#e57373 !important' }}/>}
          label={location.name || `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`}
          size="small"
          sx={{
            maxWidth: '100%', 
            height: 'auto', 
            py: 0.5, 
            borderRadius: '4px',
            '& .MuiChip-label': { 
              whiteSpace: 'normal',
              display: 'block',
              fontSize: '0.75rem',
            }
          }}
        />
        <Tooltip title="View on map">
          <IconButton 
            size="small" 
            color="primary"
            onClick={handleOpenLocationMap}
            sx={{ ml: 1 }}
          >
            <MapIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>
    );
  };

  // Render location map
  const renderLocationMap = (size = 'small') => {
    if (!location || !location.lat || !location.lng) return null;
    
    const position = [location.lat, location.lng];
    const mapHeight = size === 'small' ? 200 : 400; // Taller map for text-only posts
    const zoom = size === 'small' ? 13 : 14;
    
    return (
      <Box 
        sx={{ 
          mt: 2, 
          borderRadius: '8px', 
          overflow: 'hidden',
          border: '1px solid #ddd',
          height: mapHeight,
        }}
      >
        <Box sx={{ position: 'relative', height: '100%', width: '100%' }}>
          <MapContainer
            center={position}
            zoom={zoom}
            style={{ height: '100%', width: '100%' }}
            zoomControl={size !== 'small'}
            attributionControl={true}
            dragging={size !== 'small'}
            scrollWheelZoom={size !== 'small'}
            doubleClickZoom={size !== 'small'}
            touchZoom={size !== 'small'}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Marker position={position} />
          </MapContainer>
          
          {/* Location name overlay */}
          <Box
            sx={{
              position: 'absolute',
              bottom: 0,
              left: 0,
              right: 0,
              bgcolor: 'rgba(255, 255, 255, 0.8)',
              p: 1,
              zIndex: 1000, // Above map
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <LocationOnIcon sx={{ color: '#e57373', mr: 1, fontSize: '1rem' }} />
            <Typography variant="caption" sx={{ fontSize: '0.75rem', fontWeight: 500 }}>
              {location.name || `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`}
            </Typography>
          </Box>
        </Box>
      </Box>
    );
  };

  // Render the image carousel with animation
  const renderMediaCarousel = (inExpandedView = false) => {
    const currentSrc = processMediaSrc(getCurrentMedia());
    
    return (
      <Box
        position="relative"
        onDoubleClick={handleDoubleClick}
        onClick={() => !inExpandedView && handleExpandClick()}
        ref={carouselRef}
        sx={{ 
          overflow: 'hidden',
          width: '100%', 
          height: inExpandedView ? 'calc(90vh - 64px)' : '450px',
          backgroundColor: inExpandedView ? '#000' : 'inherit',
          cursor: !inExpandedView ? 'pointer' : 'default',
          '&:hover': {
            '& .expand-icon': {
              opacity: 1
            }
          }
        }}
      >
        {contentType === 'image' ? (
          <AnimatePresence mode="wait" custom={slideDirection}>
            <motion.div
              key={currentImageIndex}
              custom={slideDirection}
              initial={(direction) => {
                return {
                  x: direction === 'next' ? '100%' : '-100%',
                  opacity: 0
                };
              }}
              animate={{ 
                x: 0,
                opacity: 1
              }}
              exit={(direction) => {
                return {
                  x: direction === 'next' ? '-100%' : '100%',
                  opacity: 0
                };
              }}
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 }
              }}
              style={{
                width: '100%',
                height: '100%', 
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <Box
                component="img"
                src={currentSrc}
                alt={`post content ${currentImageIndex + 1}`}
                sx={{ 
                  width: '100%', 
                  height: '100%',
                  objectFit: 'cover',
                  backgroundColor: inExpandedView ? '#000' : 'inherit'
                }}
              />
            </motion.div>
          </AnimatePresence>
        ) : (
          <CardMedia
            component="video"
            controls
            src={currentSrc}
            alt="post video"
            sx={{ 
              width: '100%',
              height: '100%',
              objectFit: 'contain'
            }}
          />
        )}
        
        {showHeart && (
          <Box
            position="absolute"
            top="calc(48% - 30px)"
            left="calc(48% - 30px)"
            sx={{ 
              transform: 'translate(-50%, -50%)',
              pointerEvents: 'none', 
              zIndex: 3,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
            css={css`animation: ${fadeInOut} 0.8s ease-in-out;`}
          >
            <FavoriteIcon sx={{ 
              fontSize: 80, 
              color: '#e41e3f', 
              opacity: 0.7
            }} />
          </Box>
        )}
      </Box>
    );
  };

  const handleOptionsClick = (event) => {
    setOptionsAnchorEl(event.currentTarget);
  };

  const handleOptionsClose = () => {
    setOptionsAnchorEl(null);
  };

  const handleDeletePost = () => {
    setShowDeleteConfirm(true);
    handleOptionsClose();
  };

  const handleConfirmDelete = async () => {
    console.log('PostCard: Starting deletion process for post:', postWithId);
    setIsDeleting(true);
    
    try {
      // Remove from saved posts if it's saved
      if (isSaved) {
        console.log('PostCard: Removing from saved posts');
        removeSavedPost(postWithId);
      }
      
      // Ensure we have a valid post ID
      if (!postWithId.id) {
        console.error('PostCard: No post ID available for deletion');
        return;
      }
      
      // Notify parent component about deletion
      console.log('PostCard: Calling onPostUpdated with post:', postWithId);
      if (onPostUpdated) {
        // Pass the post ID directly
        onPostUpdated({ id: postWithId.id }, 'delete');
      } else {
        console.warn('PostCard: No onPostUpdated handler provided');
      }
      
      // Close all dialogs
      setShowDeleteConfirm(false);
      setOptionsAnchorEl(null);
    } catch (error) {
      console.error('PostCard: Error during deletion:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCancelDelete = () => {
    setShowDeleteConfirm(false);
  };

  // Fetch comments when showComments changes
  useEffect(() => {
    if (showComments && post.id) {
      console.log('Opening comments dialog for post:', post.id);
      setCommentsPage(1); // Reset to first page when opening comments
      fetchComments();
    }
  }, [showComments, post.id]);

  const fetchComments = async () => {
    try {
      setCommentsLoading(true);
      setCommentsError(null);
      console.log('Fetching comments for post:', post.id);

      const postId = String(post.id);
      const response = await commentService.getComments(postId, commentsPage, COMMENTS_PER_PAGE);
      console.log('Comments API response:', response);

      // Correctly access the comments array and total count
      const commentsData = response.data?.data?.comments || [];
      const totalComments = response.data?.data?.totalComments || 0;

      // Map API fields to UI fields
      const mappedComments = commentsData.map(comment => ({
        id: comment.id,
        user: comment.User?.name || 'Unknown',
        avatar: comment.User?.profile_picture || '',
        text: comment.description,
        time: comment.created_at || comment.createdAt,
        replies: [],
        likeCount: comment.likeCount || 0
      }));

      if (Array.isArray(mappedComments)) {
        if (commentsPage === 1) {
          setComments(mappedComments);
        } else {
          setComments(prev => [...prev, ...mappedComments]);
        }
        setHasMoreComments(comments.length + mappedComments.length < totalComments);
      } else {
        console.error('Invalid response format:', response);
        setCommentsError('Invalid response format');
      }
    } catch (error) {
      console.error('Error fetching comments:', error);
      const errorMessage = error.response?.data?.message || error.message || 'Failed to load comments';
      setCommentsError(errorMessage);
    } finally {
      setCommentsLoading(false);
    }
  };

  const loadMoreComments = () => {
    if (!commentsLoading && hasMoreComments) {
      setCommentsPage(prev => prev + 1);
      fetchComments();
    }
  };

  const handleAddComment = async (commentText) => {
    try {
      const response = await commentService.createComment(post.id, commentText);
      const newComment = response.data;
      setComments(prev => [newComment, ...prev]);
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  const handleDeleteComment = async (commentId) => {
    try {
      await commentService.deleteComment(commentId);
      setComments(prev => prev.filter(comment => comment.id !== commentId));
    } catch (error) {
      console.error('Error deleting comment:', error);
    }
  };

  const handleUpdateComment = async (commentId, newText) => {
    try {
      await commentService.updateComment(commentId, newText);
      setComments(prev => prev.map(comment => 
        comment.id === commentId ? { ...comment, description: newText } : comment
      ));
    } catch (error) {
      console.error('Error updating comment:', error);
    }
  };

  return (
    <>
      <Card sx={{ 
        maxWidth: 600, 
        margin: 'auto', 
        mt: isFirstPost ? 8 : 2, 
        mb: 4, 
        bgcolor: isDarkMode ? '#242526' : '#fff',
        color: isDarkMode ? '#fff' : '#1c1e21',
        '& .MuiTypography-root': {
          color: isDarkMode ? '#fff' : '#1c1e21'
        },
        '& .MuiIconButton-root': {
          color: isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b',
          '&:hover': {
            bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.04)'
          }
        }
      }}>
        <Box display="flex" alignItems="center" justifyContent="space-between" px={2} pt={2}>
          <Box display="flex" alignItems="center">
            <ListItemAvatar>
              <Avatar
                src={user.avatar}
                alt={user.name}
                sx={{ width: 40, height: 40 }}
              />
            </ListItemAvatar>
            <Typography fontWeight="bold" variant="subtitle1" ml={2} color={isDarkMode ? '#fff' : '#1c1e21'}>
              {user.name}
            </Typography>
          </Box>
          <Box display="flex" alignItems="center">
            {getPrivacyIcon(privacy)}
            <Typography variant="caption" color={isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b'} ml={1}>
              {timeAgo(time)}
            </Typography>
            {isCurrentUserPost() && (
              <IconButton
                size="small"
                onClick={handleOptionsClick}
                sx={{ ml: 1, color: isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b' }}
              >
                <MoreVertIcon />
              </IconButton>
            )}
          </Box>
        </Box>

        {/* Post Options Menu */}
        <Menu
          anchorEl={optionsAnchorEl}
          open={Boolean(optionsAnchorEl)}
          onClose={handleOptionsClose}
          PaperProps={{
            elevation: 0,
            sx: {
              overflow: 'visible',
              filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
              mt: 1.5,
              bgcolor: theme.palette.mode === 'dark' ? '#242526' : '#fff',
              '& .MuiMenuItem-root': {
                color: theme.palette.mode === 'dark' ? '#fff' : '#1c1e21',
                '&:hover': {
                  bgcolor: theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.04)'
                }
              },
              '& .MuiListItemIcon-root': {
                color: theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.7)' : '#65676b'
              }
            },
          }}
          transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
        >
        <MenuItem onClick={handleEditClick}>
  <ListItemIcon>
    <EditIcon
      fontSize="small"
      sx={{
        color: theme.palette.mode === 'dark'
          ? 'rgba(255, 255, 255, 0.7)'
          : '#65676b',   // or theme.palette.primary.main if you want blue
      }}
    />
  </ListItemIcon>
  <ListItemText>Edit post</ListItemText>
      </MenuItem>
          <MenuItem onClick={handleDeletePost} sx={{ color: 'error.main' }}>
            <ListItemIcon>
              <DeleteIcon fontSize="small" sx={{ color: 'error.main' }} />
            </ListItemIcon>
            <ListItemText>Delete post</ListItemText>
          </MenuItem>
        </Menu>

        {/* Content for image or video post */}
        {(contentType === 'image' || contentType === 'video') && (
          <>
            <CardContent sx={{ textAlign: 'left', color: isDarkMode ? '#fff' : '#1c1e21' }}>
              {renderText(text)}
              {location && renderLocationText()}
            </CardContent>
            {renderMediaCarousel()}
          </>
        )}

        {/* Content for text-only post */}
        {contentType === 'text' && (
          <CardContent sx={{ textAlign: 'left', color: isDarkMode ? '#fff' : '#1c1e21' }}>
            {renderText(text)}
            {location && renderLocationMap('small')}
          </CardContent>
        )}

        <CardActions disableSpacing>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton onClick={handleLike} sx={{ 
              color: liked ? '#e41e3f' : (isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b'),
              '&:hover': {
                color: '#e41e3f'
              }
            }}>
              {liked ? <FavoriteIcon sx={{ color: '#e41e3f' }} /> : <FavoriteBorderIcon />}
            </IconButton>
            <Typography 
              variant="body2" 
              sx={{ 
                fontSize: 14, 
                mr: 1,
                color: liked ? '#e41e3f' : (isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b')
              }}
            >
              {likeCount}
            </Typography>
          </Box>
          
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton onClick={() => setShowComments(true)} sx={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b' }}>
              <ChatBubbleOutlineIcon />
            </IconButton>
            <Typography variant="body2" color={isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b'} sx={{ fontSize: 14, mr: 1 }}>
              {getTotalCommentCount()}
            </Typography>
          </Box>
          
          <IconButton sx={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b' }}>
            <ShareIcon />
          </IconButton>
          
          <IconButton 
            sx={{ marginLeft: 'auto', color: isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b' }} 
            onClick={handleSavePost}
          >
            {isSaved ? <BookmarkIcon /> : <BookmarkBorderIcon />}
          </IconButton>
          
          {contentType !== 'text' && (
            <IconButton onClick={handleExpandClick} sx={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b' }}>
              <OpenInFullIcon />
            </IconButton>
          )}
        </CardActions>
      </Card>

      {/* Edit Post Dialog - Like CreatePost */}
      <Dialog
        open={editMode}
        onClose={() => !isUpdating && setEditMode(false)}
        maxWidth={false}
        PaperProps={{
          sx: {
            borderRadius: '40px',
            width: '550px',
            height: '650px',
            backgroundColor: isDarkMode ? '#242526' : '#fff',
            color: isDarkMode ? '#fff' : '#1c1e21',
            margin: '60px auto',
            boxShadow: '0px 8px 30px rgba(0, 0, 0, 0.12)',
            overflow: 'hidden',
            position: 'relative'
          },
        }}
        BackdropProps={{
          sx: {
            backdropFilter: 'blur(8px)',
            backgroundColor: 'rgba(0,0,0,0.5)',
          },
        }}
      >
        <Box sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between',
          p: 3,
          borderBottom: '1px solid #eee',
        }}>
          <Typography variant="h6" fontWeight="bold" sx={{ mx: 'auto' }}>
            Edit post
          </Typography>
          <IconButton
            onClick={() => setEditMode(false)}
            disabled={isUpdating}
            edge="end"
            sx={{
              position: 'absolute',
              right: 16,
              top: 16,
              color: (theme) => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>
        </Box>
        <DialogContent sx={{ p: 3, height: '100%', display: 'flex', flexDirection: 'column' }}>
          {/* User info */}
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
            <ListItemAvatar>
              <Avatar
                src={user.avatar}
                alt={user.name}
                sx={{ width: 48, height: 48 }}
              />
            </ListItemAvatar>
            <Box>
              <Typography variant="subtitle1" fontWeight="bold">
                {user.name}
              </Typography>
              <Button
                size="small"
                startIcon={getPrivacyIcon(editedPrivacy)}
                endIcon={<KeyboardArrowDownIcon fontSize="small" />}
                onClick={handlePrivacyClick}
                sx={{
                  textTransform: 'none',
                  fontWeight: 'medium',
                  backgroundColor: '#f0f2f5',
                  fontSize: '12px',
                  color: '#000',
                  borderRadius: '4px',
                  py: 0.5,
                  '&:hover': {
                    backgroundColor: '#e4e6eb',
                  }
                }}
              >
                {getPrivacyText(editedPrivacy)}
              </Button>
              
              {/* Privacy menu */}
              <Menu
                anchorEl={privacyMenuAnchor}
                open={Boolean(privacyMenuAnchor)}
                onClose={() => setPrivacyMenuAnchor(null)}
                PaperProps={{
                  sx: { width: 200, maxWidth: '100%', borderRadius: '8px' }
                }}
              >
                <MenuItem 
                  selected={editedPrivacy === 'public'} 
                  onClick={() => handlePrivacySelect('public')}
                >
                  <ListItemIcon>
                    <PublicIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText>Public</ListItemText>
                </MenuItem>
                <MenuItem 
                  selected={editedPrivacy === 'friends'} 
                  onClick={() => handlePrivacySelect('friends')}
                >
                  <ListItemIcon>
                    <PeopleIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText>Friends</ListItemText>
                </MenuItem>
                <MenuItem 
                  selected={editedPrivacy === 'only_me'} 
                  onClick={() => handlePrivacySelect('only_me')}
                >
                  <ListItemIcon>
                    <LockIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText>Only me</ListItemText>
                </MenuItem>
              </Menu>
            </Box>
          </Box>

          {/* Post text input */}
          <Box sx={{ flex: 1, overflowY: 'auto', mb: 3 }}>
            <TextField
              multiline
              fullWidth
              placeholder="What's on your mind?"
              value={editedText}
              onChange={(e) => setEditedText(e.target.value)}
              minRows={4}
              maxRows={12}
              variant="standard"
              inputRef={textFieldRef}
              InputProps={{
                disableUnderline: true,
                sx: {
                  fontSize: '1.25rem',
                  '&::placeholder': {
                    color: '#65676b',
                  },
                },
              }}
              disabled={isUpdating}
              sx={{ mb: 2 }}
            />

            {/* Location display in edit mode */}
            {editedLocation && (
              <Box 
                sx={{ 
                  display: 'flex',
                  alignItems: 'center',
                  mb: 2,
                  p: 1.5,
                  borderRadius: '8px',
                  bgcolor: '#f0f2f5'
                }}
              >
                <LocationOnIcon color="error" sx={{ mr: 1 }} />
                <Box sx={{ flex: 1 }}>
                  <Typography variant="body2" fontWeight="medium">
                    {editedLocation.name}
                  </Typography>
                </Box>
                <IconButton 
                  size="small" 
                  onClick={handleRemoveLocation}
                  disabled={isUpdating}
                >
                  <CloseIcon fontSize="small" />
                </IconButton>
              </Box>
            )}
          </Box>

          {/* Action buttons */}
          <Box sx={{ mt: 'auto' }}>
            <Box 
              sx={{
                border: '1px solid #ddd',
                borderRadius: '16px',
                p: 1.5,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                mb: 3
              }}
            >
              <Typography variant="body2" fontWeight="medium">
                Add to your post
              </Typography>
              <Box sx={{ display: 'flex' }}>
                <IconButton color="success" disabled={isUpdating}>
                  <PhotoIcon />
                </IconButton>
                <IconButton color="primary" disabled={isUpdating}>
                  <PersonAddIcon />
                </IconButton>
                <Tooltip title="Emoji">
                  <IconButton 
                    color="warning" 
                    onClick={handleEmojiClick}
                    disabled={isUpdating}
                  >
                    <EmojiEmotionsIcon />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Location">
                  <IconButton 
                    color="error" 
                    onClick={handleLocationClick}
                    disabled={isUpdating}
                  >
                    <LocationOnIcon />
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>

            {/* Emoji Picker Popover */}
            <Popover
              open={Boolean(emojiAnchorEl)}
              anchorEl={emojiAnchorEl}
              onClose={handleEmojiClose}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'center',
              }}
              transformOrigin={{
                vertical: 'bottom',
                horizontal: 'center',
              }}
            >
              <EmojiPicker 
                onEmojiClick={onEmojiClick} 
                searchDisabled={false}
                skinTonesDisabled={true}
                width={320}
                height={400}
              />
            </Popover>

            {/* Location Picker Popover */}
            <Popover
              open={Boolean(locationAnchorEl)}
              anchorEl={locationAnchorEl}
              onClose={handleLocationClose}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'center',
              }}
              transformOrigin={{
                vertical: 'bottom',
                horizontal: 'center',
              }}
              PaperProps={{
                sx: { width: '400px', p: 2, borderRadius: '8px' }
              }}
            >
              <Typography variant="h6" fontWeight="bold" sx={{ mb: 2 }}>
                Select Location
              </Typography>
              
              {/* Location search */}
              <Paper
                component="form"
                sx={{ display: 'flex', alignItems: 'center', mb: 2, p: '2px 4px' }}
                onSubmit={(e) => {
                  e.preventDefault();
                  handleLocationSearch();
                }}
              >
                <InputBase
                  sx={{ ml: 1, flex: 1 }}
                  placeholder="Search for a location"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <IconButton type="submit" sx={{ p: '10px' }} aria-label="search">
                  <SearchIcon />
                </IconButton>
                <Divider sx={{ height: 28, m: 0.5 }} orientation="vertical" />
                <Tooltip title="Use current location">
                  <IconButton 
                    onClick={handleCurrentLocation} 
                    color="primary" 
                    sx={{ p: '10px' }}
                  >
                    <MyLocationIcon />
                  </IconButton>
                </Tooltip>
              </Paper>
              
              {/* Map */}
              <Box sx={{ height: '300px', borderRadius: '8px', overflow: 'hidden', mb: 2, border: '1px solid #ddd' }}>
                {isMapLoading ? (
                  <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <CircularProgress />
                  </Box>
                ) : (
                  <MapContainer
                    center={mapCenter}
                    zoom={mapZoom}
                    style={{ height: '100%', width: '100%' }}
                    zoomControl={true}
                    attributionControl={true}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    
                    <LocationMarker 
                      onLocationSelect={handleLocationSelect} 
                      position={markerPosition}
                      setPosition={setMarkerPosition}
                    />
                    
                    <MapController center={mapCenter} zoom={mapZoom} />
                  </MapContainer>
                )}
              </Box>
              
              {/* Selected location display */}
              <Box sx={{ mt: 1 }}>
                {editedLocation && (
                  <Chip 
                    icon={<LocationOnIcon />} 
                    label={editedLocation.name}
                    onDelete={handleRemoveLocation}
                    sx={{ mb: 2, maxWidth: '100%', height: 'auto', py: 1,
                                            '& .MuiChip-label': { whiteSpace: 'normal' } }}
                  />
                )}
                
                <Button
                  fullWidth
                  variant="contained"
                  disableElevation
                  onClick={handleLocationClose}
                  disabled={!editedLocation}
                  sx={{
                    textTransform: 'none',
                    fontWeight: 'bold',
                    borderRadius: '8px',
                    py: 1,
                    bgcolor: '#1976d2',
                    '&:hover': {
                      bgcolor: '#1565c0',
                    },
                    '&.Mui-disabled': {
                      bgcolor: '#e4e6eb',
                      color: '#bcc0c4',
                    }
                  }}
                >
                  Confirm Location
                </Button>
              </Box>
            </Popover>

            {/* Save button */}
            <Button
              fullWidth
              variant="contained"
              disableElevation
              disabled={!editedText.trim() || isUpdating}
              onClick={handleSaveEdit}
              sx={{
                textTransform: 'none',
                fontWeight: 'bold',
                borderRadius: '8px',
                py: 1.5,
                bgcolor: '#1877f2',
                '&:hover': {
                  bgcolor: '#166fe5',
                },
                '&.Mui-disabled': {
                  bgcolor: '#e4e6eb',
                  color: '#bcc0c4',
                }
              }}
            >
              {isUpdating ? (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <CircularProgress size={24} sx={{ mr: 1 }} color="inherit" />
                  Saving...
                </Box>
              ) : 'Save'}
            </Button>
          </Box>
        </DialogContent>
      </Dialog>

      <Dialog
        open={showComments}
        onClose={() => setShowComments(false)}
        maxWidth={false}
        PaperProps={{
          sx: {
            borderRadius: '40px',
            width: '550px',
            height: '650px',
            backgroundColor: isDarkMode ? '#242526' : '#fff',
            color: isDarkMode ? '#fff' : '#1c1e21',
            margin: '60px auto',
            boxShadow: '0px 8px 30px rgba(0, 0, 0, 0.12)',
            overflow: 'hidden',
            position: 'relative'
          },
        }}
        BackdropProps={{
          sx: {
            backdropFilter: 'blur(8px)',
            backgroundColor: 'rgba(0,0,0,0.5)',
          },
        }}
      >
        <DialogContent
          sx={{
            p: 3,
            height: '100%',
            bgcolor: isDarkMode ? '#242526' : '#fff',
            borderRadius: '16px',
            position: 'relative',
            boxSizing: 'border-box',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}
        >
          <IconButton
            onClick={() => setShowComments(false)}
            sx={{
              color: theme.palette.mode === 'dark' ? '#fff' : '#000',
              position: 'absolute',
              top: 16,
              right: 16,
              zIndex: 2,
            }}
          >
            <CloseIcon />
          </IconButton>

          <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', pt: 2 }}>
            <Typography variant="h6" align="center" sx={{ mb: 2, fontWeight: 700, color: theme.palette.mode === 'dark' ? '#fff' : '#000' }}>
              {user.name}'s Post
            </Typography>
            
            <Box sx={{ 
              flex: 1, 
              display: 'flex', 
              flexDirection: 'column',
              overflowY: 'auto'
            }}>
              <CommentSection 
                comments={comments} 
                setComments={setComments}
                postId={post.id}
                onAddComment={handleAddComment}
                onDeleteComment={handleDeleteComment}
                onUpdateComment={handleUpdateComment}
                loading={commentsLoading}
                error={commentsError}
                hasMore={hasMoreComments}
                onLoadMore={loadMoreComments}
              />
            </Box>
          </Box>
        </DialogContent>
      </Dialog>

      {/* Location Map Dialog */}
      <Dialog
        open={showLocationMap}
        onClose={() => setShowLocationMap(false)}
        maxWidth="md"
        PaperProps={{
          sx: {
            borderRadius: '16px',
            width: '90vw',
            maxWidth: '600px',
            height: 'auto',
            maxHeight: '80vh',
            backgroundColor: isDarkMode ? '#242526' : '#fff',
            color: isDarkMode ? '#fff' : '#1c1e21',
            margin: '60px auto',
            boxShadow: '0px 8px 30px rgba(0, 0, 0, 0.12)',
            overflow: 'hidden',
          },
        }}
        BackdropProps={{
          sx: {
            backdropFilter: 'blur(8px)',
            backgroundColor: 'rgba(0,0,0,0.5)',
          },
        }}
      >
        <Box sx={{ position: 'relative', height: '500px' }}>
          <IconButton
            onClick={() => setShowLocationMap(false)}
            sx={{
              position: 'absolute',
              top: 8,
              right: 8,
              zIndex: 2000,
              backgroundColor: 'rgba(255, 255, 255, 0.8)',
              '&:hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.9)',
              }
            }}
          >
            <CloseIcon />
          </IconButton>
          
          {/* Full interactive map */}
          {location && (
            <Box sx={{ height: '100%', width: '100%' }}>
              <MapContainer
                center={[location.lat, location.lng]}
                zoom={14}
                style={{ height: '100%', width: '100%' }}
                zoomControl={true}
                attributionControl={true}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                <Marker position={[location.lat, location.lng]} />
              </MapContainer>
              
              {/* Location title at the bottom */}
              <Box
                sx={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  bgcolor: 'rgba(255, 255, 255, 0.9)',
                  p: 2,
                  zIndex: 1000,
                  display: 'flex',
                  alignItems: 'center',
                  borderTop: '1px solid rgba(0,0,0,0.1)'
                }}
              >
                <LocationOnIcon sx={{ color: '#e57373', mr: 2, fontSize: '1.25rem' }} />
                <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                  {location.name || `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`}
                </Typography>
              </Box>
            </Box>
          )}
        </Box>
      </Dialog>

      <Dialog
        open={expandedView}
        onClose={() => setExpandedView(false)}
        maxWidth={false}
        PaperProps={{
          sx: {
            width: '90vw',
            height: '90vh',
            margin: '20px auto',
            borderRadius: '8px',
            overflow: 'hidden',
            display: 'flex',
            backgroundColor: isDarkMode ? '#000' : '#fff',
          },
        }}
        BackdropProps={{
          sx: {
            backdropFilter: 'blur(8px)',
            backgroundColor: 'rgba(0,0,0,0.9)',
          },
        }}
      >
        <Box sx={{ 
          display: 'flex', 
          width: '100%', 
          height: '100%',
        }}>
          {/* Left side - Image/Video Carousel with animation */}
          <Box sx={{ 
            flex: contentType === 'text' ? '0 0 0%' : '1 1 65%', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            backgroundColor: '#000',
            position: 'relative'
          }}>
            {/* Use same carousel rendering function with expanded view flag */}
            {contentType !== 'text' && renderMediaCarousel(true)}
          </Box>

          <Box sx={{ 
            flex: contentType === 'text' ? '1 1 100%' : '1 1 35%',  
            display: 'flex', 
            flexDirection: 'column',
            bgcolor: isDarkMode ? '#242526' : '#fff',
            borderLeft: contentType !== 'text' ? `1px solid ${isDarkMode ? '#333' : '#ddd'}` : 'none',
          }}>
            <Box sx={{ 
              p: 2, 
              borderBottom: `1px solid ${isDarkMode ? '#333' : '#ddd'}`, 
              display: 'flex', 
              alignItems: 'center' 
            }}>
              <ListItemAvatar>
                <Avatar
                  src={user.avatar}
                  alt={user.name}
                  sx={{ width: 40, height: 40 }}
                />
              </ListItemAvatar>
              <Box sx={{ ml: 2 }}>
                <Typography variant="subtitle1" fontWeight="bold" color={isDarkMode ? '#fff' : '#1c1e21'}>
                  {user.name}
                </Typography>
                <Typography variant="caption" color={isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b'}>
                  {timeAgo(time)}
                </Typography>
              </Box>
              <Box sx={{ ml: 'auto', display: 'flex', alignItems: 'center' }}>
                {getPrivacyIcon(privacy)} {/* Display privacy icon in expanded view */}
                <IconButton 
                  sx={{ ml: 1, color: isDarkMode ? '#fff' : '#65676b' }}
                  onClick={() => setExpandedView(false)}
                >
                  <CloseIcon />
                </IconButton>
              </Box>
            </Box>

            {/* Caption - always show full text in expanded view */}
            <Box sx={{ p: 2, borderBottom: `1px solid ${isDarkMode ? '#333' : '#ddd'}` }}>
              <Typography variant="body1" color={isDarkMode ? '#fff' : '#1c1e21'}>
                {text}
              </Typography>
              
              {/* Media info for multiple photos */}
              {hasMultipleMedia && (
                <Box sx={{ mt: 1, display: 'flex', alignItems: 'center' }}>
                  <Typography variant="caption" color={isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b'} fontWeight="medium">
                    {currentImageIndex + 1} of {contentSrc.length} photos
                  </Typography>
                </Box>
              )}
              
              {/* Location display in expanded view */}
              {location && (
                <Box sx={{ mt: 2 }}>
                  {hasMedia ? (
                    // For media posts, show text with map button
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Chip
                        icon={<LocationOnIcon sx={{ color: '#e57373 !important' }}/>}
                        label={location.name || `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`}
                        size="small"
                        sx={{
                          maxWidth: '90%', 
                          height: 'auto', 
                          py: 0.5, 
                          borderRadius: '4px',
                          '& .MuiChip-label': { 
                            whiteSpace: 'normal',
                            display: 'block',
                            fontSize: '0.75rem',
                          }
                        }}
                      />
                      <Tooltip title="View on map">
                        <IconButton 
                          size="small" 
                          color="primary"
                          onClick={handleOpenLocationMap}
                          sx={{ ml: 1 }}
                        >
                          <MapIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  ) : (
                    // For text-only posts, show the map directly
                    renderLocationMap('large')
                  )}
                </Box>
              )}
            </Box>

            <Box sx={{ 
              display: 'flex', 
              p: 1, 
              borderBottom: `1px solid ${isDarkMode ? '#333' : '#ddd'}` 
            }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <IconButton onClick={handleLike} sx={{ color: liked ? '#1877f2' : (isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b') }}>
                  {liked ? <FavoriteIcon /> : <FavoriteBorderIcon />}
                </IconButton>
                <Typography variant="body2" color={isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b'}>
                  {likeCount}
                </Typography>
              </Box>
              <IconButton sx={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b' }}><ShareIcon /></IconButton>
              {/* Show edit button in expanded view if it's the user's post */}
              {isCurrentUserPost() && (
                <IconButton onClick={handleEditClick} sx={{ color: isDarkMode ? '#fff' : '#65676b' }}>
                  <EditIcon />
                </IconButton>
              )}
              <IconButton 
                sx={{ marginLeft: 'auto', color: isDarkMode ? 'rgba(255, 255, 255, 0.7)' : '#65676b' }} 
                onClick={handleSavePost}
              >
                {isSaved ? <BookmarkIcon /> : <BookmarkBorderIcon />}
              </IconButton>
            </Box>

            <Box sx={{ 
              flex: 1, 
              display: 'flex', 
              flexDirection: 'column',
              overflowY: 'auto',
            }}>
              <Box sx={{ flex: 1, p: 1 }}>
                <CommentSection 
                  comments={comments} 
                  setComments={setComments}
                  postId={post.id}
                  onAddComment={handleAddComment}
                  onDeleteComment={handleDeleteComment}
                  onUpdateComment={handleUpdateComment}
                  loading={commentsLoading}
                  error={commentsError}
                  hasMore={hasMoreComments}
                  onLoadMore={loadMoreComments}
                />
              </Box>
            </Box>
          </Box>
        </Box>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={showDeleteConfirm}
        onClose={handleCancelDelete}
        maxWidth="xs"
        PaperProps={{
          sx: {
            borderRadius: '16px',
            width: '400px',
            backgroundColor: isDarkMode ? '#242526' : '#fff',
            color: isDarkMode ? '#fff' : '#1c1e21',
            margin: '60px auto',
            boxShadow: '0px 8px 30px rgba(0, 0, 0, 0.12)',
          },
        }}
        BackdropProps={{
          sx: {
            backdropFilter: 'blur(8px)',
            backgroundColor: 'rgba(0,0,0,0.5)',
          },
        }}
      >
        <DialogContent sx={{ p: 3 }}>
          <Typography variant="h6" fontWeight="bold" sx={{ mb: 2 }}>
            Delete Post
          </Typography>
          <Typography variant="body1" sx={{ mb: 3 }}>
            Are you sure you want to delete this post? This action cannot be undone.
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
            <Button
              variant="outlined"
              onClick={handleCancelDelete}
              disabled={isDeleting}
              sx={{
                textTransform: 'none',
                borderRadius: '8px',
                px: 3,
              }}
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              color="error"
              onClick={handleConfirmDelete}
              disabled={isDeleting}
              sx={{
                textTransform: 'none',
                borderRadius: '8px',
                px: 3,
                bgcolor: '#dc3545',
                '&:hover': {
                  bgcolor: '#bb2d3b',
                },
              }}
            >
              {isDeleting ? (
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <CircularProgress size={20} sx={{ mr: 1 }} color="inherit" />
                  Deleting...
                </Box>
              ) : 'Delete'}
            </Button>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default PostCard;