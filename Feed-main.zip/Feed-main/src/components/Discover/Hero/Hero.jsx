import React, { useState } from 'react';
import {
  Box,
  Typography,
  InputBase,
  Paper,
  Card,
  CardContent,
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  CircularProgress
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { alpha } from '@mui/material/styles';
import { api } from "../../../services/api";

const Hero = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  
  const handleSearchChange = async (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    
    if (query.length > 2) {
      setIsSearching(true);
      try {
        const results = await api.searchDestinations(query);
        setSearchResults(results);
      } catch (error) {
        console.error('Search failed', error);
      } finally {
        setIsSearching(false);
      }
    } else {
      setSearchResults([]);
    }
  };

  return (
    <Box
      sx={{
        position: 'relative',
        height: { xs: 400, md: 500 },
        backgroundImage: 'url(https://img.freepik.com/free-photo/traveling-with-off-road-car_23-2151473062.jpg?ga=GA1.1.551707588.1747933504&semt=ais_hybrid&w=740)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'white',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.3)',
        }
      }}
    >
      <Box 
        sx={{ 
          position: 'relative',
          zIndex: 1,
          width: '100%',
          maxWidth: 800,
          px: 2,
          textAlign: 'center'
        }}
      >
        <Typography 
          variant="h2" 
          component="h1" 
          sx={{ 
            fontWeight: 'bold', 
            mb: 4,
            fontSize: { xs: '2rem', md: '3rem' }
          }}
        >
          Book traveler-backed things to do
        </Typography>
        
        <Box sx={{ position: 'relative', mb: 4 }}>
          <Paper
            elevation={3}
            sx={{
              p: '2px 4px',
              display: 'flex',
              alignItems: 'center',
              width: '100%',
              maxWidth: 600,
              mx: 'auto',
              borderRadius: 50,
              height: { xs: 50, md: 60 }
            }}
          >
            <SearchIcon sx={{ mx: 2, color: 'text.secondary' }} />
            <InputBase
              placeholder="Search by destination"
              fullWidth
              value={searchQuery}
              onChange={handleSearchChange}
              sx={{ ml: 1, flex: 1 }}
            />
          </Paper>
          
          {isSearching && (
            <Paper 
              sx={{ 
                position: 'absolute', 
                top: '100%', 
                left: 0, 
                right: 0, 
                maxWidth: 600, 
                mx: 'auto',
                mt: 1,
                p: 2,
                textAlign: 'center',
                color: 'text.secondary',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center'
              }}
            >
              <CircularProgress size={20} sx={{ mr: 1 }} />
              Searching...
            </Paper>
          )}
          
          {searchResults.length > 0 && (
            <Card 
              sx={{ 
                position: 'absolute', 
                top: '100%', 
                left: 0, 
                right: 0, 
                maxWidth: 600, 
                mx: 'auto',
                mt: 1,
                maxHeight: 300,
                overflow: 'auto'
              }}
            >
              <List>
                {searchResults.map(result => (
                  <ListItem key={result.id} button>
                    <ListItemAvatar>
                      <Avatar src={result.image} variant="rounded" />
                    </ListItemAvatar>
                    <ListItemText 
                      primary={result.name} 
                      secondary={`${result.activities.length} activities`}
                    />
                  </ListItem>
                ))}
              </List>
            </Card>
          )}
        </Box>
        
        <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1 }}>
          {[0, 1, 2].map((index) => (
            <Box
              key={index}
              sx={{
                width: 10,
                height: 10,
                borderRadius: '50%',
                bgcolor: index === 0 ? 'white' : alpha('#fff', 0.5),
              }}
            />
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default Hero;