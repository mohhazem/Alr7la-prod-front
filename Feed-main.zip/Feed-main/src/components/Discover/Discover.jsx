import React, { useState, useEffect } from 'react';
import { 
  Box, 
  CssBaseline, 
  ThemeProvider, 
  createTheme, 
  Typography, 
  Container,
  Divider,
  Button,
  useMediaQuery,
  Fab,
  Backdrop,
  CircularProgress
} from '@mui/material';
import Hero from './Hero/Hero';
import TrendingPlaces from './TrendingPlaces/TrendingPlaces';
import RecommendedSection from "./Reccomended/ReccomendedSection";
import Collage from "./Collage/Collage";
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import TravelingBanner from './banner/banner';
// Enhanced theme with more personality
const theme = createTheme({
  palette: {
    primary: {
      main: '#ff5a5f',
      light: '#ff8a8f',
      dark: '#e0292e',
      contrastText: '#fff',
    },
    secondary: {
      main: '#00a680',
      light: '#33b899',
      dark: '#00735a',
    },
    background: {
      default: '#f8f9fa',
      paper: '#ffffff',
    },
    text: {
      primary: '#2c3e50',
      secondary: '#6c757d',
    },
    divider: 'rgba(0, 0, 0, 0.06)',
  },
  typography: {
    fontFamily: '"Poppins", "Roboto", "Arial", sans-serif',
    h1: {
      fontWeight: 700,
    },
    h2: {
      fontWeight: 700,
    },
    h3: {
      fontWeight: 600,
    },
    h4: {
      fontWeight: 600,
    },
    h5: {
      fontWeight: 500,
    },
    h6: {
      fontWeight: 500,
    },
    button: {
      fontWeight: 500,
    },
  },
  shape: {
    borderRadius: 12,
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0 6px 16px rgba(0,0,0,0.08)',
          transition: 'transform 0.3s ease, box-shadow 0.3s ease',
          '&:hover': {
            transform: 'translateY(-8px)',
            boxShadow: '0 12px 20px rgba(0,0,0,0.12)',
          },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          borderRadius: 8,
          padding: '10px 20px',
          fontWeight: 500,
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 6,
          fontWeight: 500,
        },
      },
    },
  },
});

function Discover() {
  const [loading, setLoading] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  // Show/hide scroll to top button based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      
      {/* Main Content */}
      <Box sx={{ bgcolor: 'background.default', minHeight: '100vh', pb: 10 }}>
        {/* Hero Section with Parallax Effect */}
        <Box 
          sx={{ 
            position: 'relative',
            overflow: 'hidden',
            '&::after': {
              content: '""',
              position: 'absolute',
              bottom: -1,
              left: 0,
              right: 0,
              height: '100px',
              background: 'linear-gradient(to top, rgba(248,249,250,1), rgba(248,249,250,0))',
              zIndex: 2,
            }
          }}
        >
          <Hero />
        </Box>
        
        {/* Content Sections */}
        <Container 
          maxWidth="xl" 
          sx={{ 
            mt: -5, 
            position: 'relative', 
            zIndex: 3,
          }}
        >
          {/* Welcome Message */}
          <Box
            sx={{
              bgcolor: 'background.paper',
              borderRadius: 4,
              p: { xs: 3, md: 5 },
              mb: 6,
              boxShadow: '0 8px 24px rgba(0,0,0,0.05)',
              border: '1px solid',
              borderColor: 'divider',
            }}
          >
            <Typography 
              variant="h4" 
              component="h1" 
              gutterBottom
              sx={{
                fontWeight: 700,
                color: 'text.primary',
                mb: 2,
              }}
            >
              Welcome to your travel discovery hub
            </Typography>
            <Typography 
              variant="body1" 
              color="text.secondary"
              sx={{ mb: 3, maxWidth: '800px' }}
            >
              Explore personalized recommendations, trending destinations, and unique experiences 
              curated just for you. Start your journey to extraordinary places loved by travelers worldwide.
            </Typography>
            <Button 
              variant="contained" 
              color="primary" 
              endIcon={<ArrowForwardIcon />}
              sx={{ 
                px: 4, 
                py: 1.5,
                fontWeight: 600,
              }}
            >
              Start exploring
            </Button>
          </Box>
          
          {/* Trending Places Section */}
          <Box 
            sx={{ 
              py: 4, 
              mb: 6,
              position: 'relative',
            }}
          >
            <Box 
              sx={{ 
                position: 'absolute', 
                left: -32, 
                top: '50%', 
                width: 64, 
                height: 64, 
                borderRadius: '50%', 
                bgcolor: 'primary.light', 
                opacity: 0.1,
                transform: 'translateY(-50%)',
                display: { xs: 'none', lg: 'block' }
              }} 
            />
            <TrendingPlaces />
          </Box>
          
          {/* Visual Divider */}
          <Box sx={{ textAlign: 'center', my: 8, opacity: 0.7 }}>
            <Divider>
              <Typography 
                variant="overline" 
                sx={{ 
                  px: 2, 
                  color: 'text.secondary',
                  letterSpacing: 2,
                }}
              >
                CURATED FOR YOU
              </Typography>
            </Divider>
          </Box>
          
          {/* Recommended Section with Visual Enhancement */}
          <Box 
            sx={{ 
              position: 'relative',
              py: 3,
              '&::before': {
                content: '""',
                position: 'absolute',
                top: 0,
                left: -16,
                bottom: 0,
                width: 6,
                bgcolor: 'primary.main',
                borderRadius: 8,
              }
            }}
          >
            <RecommendedSection
              title="Recommended for you"
              subtitle="Browsing Greece? We think you'll love these handpicked experiences."
              filter="Crete"
            />
          </Box>
            
          {/* Collage Section */}
          <Box 
           >
            <Collage
              title="Recommended for you"
              subtitle="Browsing Greece? We think you'll love these handpicked experiences."
              filter="Crete"
            />
          </Box>
          {/* Banner Section */}
          <TravelingBanner />
          {/* Featured Section with Card Styles */}
          <Box 
            sx={{ 
              mt: 8, 
              p: 4, 
              bgcolor: 'background.paper', 
              borderRadius: 4,
              boxShadow: '0 10px 30px rgba(0,0,0,0.08)',
              background: 'linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%)',
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
              <Box>
                <Typography variant="h4" component="h2" fontWeight="bold">
                  Popular Experiences
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  Top-rated activities loved by travelers worldwide
                </Typography>
              </Box>
              <Button 
                variant="outlined" 
                endIcon={<ArrowForwardIcon />}
                sx={{ display: { xs: 'none', sm: 'flex' } }}
              >
                View all
              </Button>
            </Box>
            
            <RecommendedSection
              isPopular={true}
            />
            
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
              <Button 
                variant="outlined" 
                endIcon={<ArrowForwardIcon />}
                sx={{ display: { xs: 'flex', sm: 'none' } }}
              >
                View all
              </Button>
            </Box>
          </Box>
          
          {/* Newsletter Section */}
          <Box 
            sx={{ 
              mt: 8, 
              p: { xs: 3, md: 6 },
              bgcolor: 'primary.main',
              color: 'white',
              borderRadius: 4,
              backgroundImage: 'linear-gradient(135deg, rgba(255,90,95,1) 0%, rgba(224,41,46,1) 100%)',
              boxShadow: '0 15px 35px rgba(255,90,95,0.2)',
              textAlign: 'center',
            }}
          >
            <Typography 
              variant="h3" 
              component="h2"
              sx={{ 
                mb: 2,
                fontWeight: 700,
                textShadow: '0 2px 4px rgba(0,0,0,0.1)'
              }}
            >
              Get travel inspiration delivered to your inbox
            </Typography>
            <Typography 
              variant="subtitle1"
              sx={{ 
                mb: 4,
                maxWidth: 700,
                mx: 'auto',
                opacity: 0.9,
              }}
            >
              Join our newsletter for exclusive deals, travel tips, and personalized recommendations.
            </Typography>
            <Button 
              variant="contained" 
              size="large"
              sx={{ 
                bgcolor: 'white',
                color: 'primary.dark',
                px: 4,
                py: 1.5,
                fontWeight: 600,
                '&:hover': {
                  bgcolor: 'rgba(255,255,255,0.9)',
                }
              }}
            >
              Subscribe now
            </Button>
          </Box>
        </Container>
      </Box>
      
      {/* Scroll to Top Button */}
      <Fab 
        color="primary" 
        size="medium" 
        aria-label="scroll to top"
        onClick={scrollToTop}
        sx={{
          position: 'fixed',
          bottom: 20,
          right: 20,
          opacity: showScrollTop ? 1 : 0,
          transition: 'opacity 0.3s',
          pointerEvents: showScrollTop ? 'all' : 'none',
          zIndex: 1000,
        }}
      >
        <KeyboardArrowUpIcon />
      </Fab>
      
      {/* Loading Overlay */}
      <Backdrop
        sx={{ color: '#fff', zIndex: 9999 }}
        open={loading}
      >
        <CircularProgress color="inherit" />
      </Backdrop>

      {/* Global Animations */}
      <style jsx global>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(50px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        @keyframes pulse {
          0% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
          100% {
            transform: scale(1);
          }
        }
      `}</style>
    </ThemeProvider>
  );
}

export default Discover;