import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  CardMedia, 
  Tabs, 
  Tab, 
  Divider, 
  Chip,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  useTheme,
  useMediaQuery,
  Avatar,
  IconButton,
  LinearProgress,
  CircularProgress,
  Link
} from '@mui/material';
import {
  Public as PublicIcon,
  Language as LanguageIcon,
  AccessTime as AccessTimeIcon,
  LocalAtm as LocalAtmIcon,
  Flight as FlightIcon,
  DirectionsCar as DirectionsCarIcon,
  AttachMoney as AttachMoneyIcon,
  Bolt as BoltIcon,
  WbSunny as WbSunnyIcon,
  Hotel as HotelIcon,
  Restaurant as RestaurantIcon,
  LocalPhone as LocalPhoneIcon,
  BookmarkBorder as BookmarkBorderIcon,
  Share as ShareIcon,
  KeyboardArrowDown as KeyboardArrowDownIcon,
  KeyboardArrowRight as KeyboardArrowRightIcon,
  Explore as ExploreIcon
} from '@mui/icons-material';
import Hero from './Hero/Hero';
import Weather from './Weather/Weather';
import MajorCities from './MajorCities/MajorCities';
import Photos from './Photos/Photos';
import MightAlsoLike from './MightAlsoLike/MightAlsoLike';
import CurrencyExchange from '../Currency';
import ParallaxBanner from './Banner/Banner';
import Activities from './Activities/Activities';
// This would be a real API call in production
const fetchCountryData = (countryCode) => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        name: "Japan",
        officialName: "Japan",
        flagUrl: "https://flagcdn.com/jp.svg",
        capital: "Tokyo",
        region: "Asia",
        subregion: "Eastern Asia",
        population: 125836021,
        languages: ["Japanese"],
        currencies: [{ name: "Japanese Yen", code: "JPY", symbol: "¥" }],
        timezones: ["UTC+09:00"],
        drivingSide: "left",
        callingCode: "+81",
        description: "Japan is an island country in East Asia. It is situated in the northwest Pacific Ocean and is bordered on the west by the Sea of Japan, extending from the Sea of Okhotsk in the north toward the East China Sea, Philippine Sea, and Taiwan in the south. Japan is a part of the Ring of Fire, and spans an archipelago of 6852 islands covering 377,975 square kilometers; the five main islands are Hokkaido, Honshu, Shikoku, Kyushu, and Okinawa. Tokyo is the nation's capital and largest city, followed by Yokohama, Osaka, Nagoya, Sapporo, Fukuoka, Kobe, and Kyoto.",
        travelTips: [
          "Carry cash as many places don't accept credit cards",
          "Get a Japan Rail Pass if you plan on using the bullet trains",
          "Learn basic Japanese phrases",
          "Be mindful of Japanese etiquette in public spaces",
          "Try to remove shoes when entering homes and some restaurants"
        ],
        majorCities: [
          {
            name: "Tokyo",
            description: "Japan's busy capital that mixes ultramodern and traditional architecture",
            image: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26",
            attractions: ["Tokyo Skytree", "Meiji Shrine", "Imperial Palace"]
          },
          {
            name: "Kyoto",
            description: "Famous for its temples, shrines, traditional wooden houses, and beautiful gardens",
            image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e",
            attractions: ["Kinkaku-ji", "Fushimi Inari Shrine", "Arashiyama Bamboo Grove"]
          },
          {
            name: "Osaka",
            description: "Known for its modern architecture, nightlife and street food",
            image: "https://images.unsplash.com/photo-1590559899731-a382839e5549",
            attractions: ["Osaka Castle", "Dotonbori", "Universal Studios Japan"]
          },
          {
            name: "Hiroshima",
            description: "A modern city with a tragic past, known for its resilience",
            image: "https://images.unsplash.com/photo-1579508542697-bb18e7d9aeaa",
            attractions: ["Peace Memorial Park", "Hiroshima Castle", "Miyajima Island"]
          }
        ],
        weather: [
          { month: "January", avg_temp: 6, precipitation: 60, description: "Cold and mostly clear" },
          { month: "February", avg_temp: 7, precipitation: 70, description: "Cold and occasionally snowy" },
          { month: "March", avg_temp: 10, precipitation: 100, description: "Cool with cherry blossoms beginning" },
          { month: "April", avg_temp: 14, precipitation: 130, description: "Mild and perfect for cherry blossoms" },
          { month: "May", avg_temp: 19, precipitation: 140, description: "Warm and pleasant" },
          { month: "June", avg_temp: 22, precipitation: 180, description: "Rainy season begins" },
          { month: "July", avg_temp: 26, precipitation: 200, description: "Hot and humid" },
          { month: "August", avg_temp: 28, precipitation: 160, description: "Peak summer heat" },
          { month: "September", avg_temp: 24, precipitation: 210, description: "Typhoon season" },
          { month: "October", avg_temp: 19, precipitation: 160, description: "Cool and autumn colors begin" },
          { month: "November", avg_temp: 14, precipitation: 90, description: "Cool with beautiful autumn foliage" },
          { month: "December", avg_temp: 9, precipitation: 60, description: "Cold and occasionally snowy" }
        ],
        bestTimeToVisit: "March to May and October to November",
        visaRequirements: "Visa-free for many countries for stays up to 90 days",
        healthAndSafety: {
          safety: "Very safe with low crime rates",
          healthCare: "Excellent healthcare system",
          vaccinations: "No specific vaccinations required for most travelers"
        },
        budget: {
          budget: "¥8,000-12,000 per day",
          midRange: "¥12,000-25,000 per day",
          luxury: "¥25,000+ per day"
        },
        coordinates: {
          lat: 36.204824,
          lng: 138.252924
        }
      });
    }, 500);
  });
};

// Components

const CityCard = ({ city }) => (
  <Card 
    sx={{ 
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      borderRadius: 2,
      boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
      transition: 'transform 0.3s ease',
      '&:hover': {
        transform: 'translateY(-8px)',
      }
    }}
  >
    <CardMedia
      component="img"
      height="200"
      image={city.image}
      alt={city.name}
      sx={{
        position: 'relative',
        '&::after': {
          content: '""',
          position: 'absolute',
          bottom: 0,
          left: 0,
          width: '100%',
          height: '30%',
          background: 'linear-gradient(to top, rgba(0,0,0,0.7), transparent)',
        }
      }}
    />
    <CardContent sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h5" component="h2" gutterBottom fontWeight="bold">
        {city.name}
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        {city.description}
      </Typography>
      <Typography variant="subtitle2" color="text.primary" fontWeight="medium">
        Top attractions:
      </Typography>
      <Box component="ul" sx={{ pl: 2, mt: 1 }}>
        {city.attractions.map((attraction, idx) => (
          <Typography component="li" key={idx} variant="body2">
            {attraction}
          </Typography>
        ))}
      </Box>
    </CardContent>
    <Box sx={{ p: 2, pt: 0 }}>
      <Button 
        endIcon={<KeyboardArrowRightIcon />}
        variant="outlined" 
        fullWidth
      >
        Explore {city.name}
      </Button>
    </Box>
  </Card>
);

const CountryMap = ({ coordinates }) => {
  return (
    <Paper sx={{ p: 3, borderRadius: 2 }}>
      <Typography variant="h5" gutterBottom fontWeight="bold">
        Location & Map
      </Typography>
      
      <Box 
        sx={{ 
          mt: 2, 
          height: 400, 
          borderRadius: 1, 
          overflow: 'hidden',
          border: '1px solid',
          borderColor: 'divider',
          position: 'relative'
        }}
      >
        {/* This would be replaced with your actual OpenStreetMap implementation */}
        <iframe 
          width="100%" 
          height="100%" 
          frameBorder="0" 
          scrolling="no" 
          marginHeight="0" 
          marginWidth="0" 
          src={`https://www.openstreetmap.org/export/embed.html?bbox=${coordinates.lng-20}%2C${coordinates.lat-10}%2C${coordinates.lng+20}%2C${coordinates.lat+10}&amp;layer=mapnik&amp;marker=${coordinates.lat}%2C${coordinates.lng}`}
          style={{ border: 'none' }}
        />
      </Box>
      
      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="body2" fontWeight="medium">
            Capital: Tokyo
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Coordinates: {coordinates.lat.toFixed(2)}°N, {coordinates.lng.toFixed(2)}°E
          </Typography>
        </Box>
        <Button 
          variant="outlined" 
          href={`https://www.openstreetmap.org/?mlat=${coordinates.lat}&mlon=${coordinates.lng}#map=5/${coordinates.lat}/${coordinates.lng}`}
          target="_blank"
          endIcon={<KeyboardArrowRightIcon />}
        >
          View larger map
        </Button>
      </Box>
    </Paper>
  );
};

const TravelTips = ({ tips, visaRequirements, healthAndSafety, budget }) => {
  const theme = useTheme();
  
  return (
    <Paper sx={{ p: 3, borderRadius: 2 }}>
      <Typography variant="h5" gutterBottom fontWeight="bold">
        Essential Travel Information
      </Typography>
      
      <Grid container spacing={3} sx={{ mt: 1 }}>
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%', boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Avatar sx={{ bgcolor: theme.palette.primary.light, mr: 2 }}>
                  <BoltIcon />
                </Avatar>
                <Typography variant="h6" fontWeight="bold">
                  Travel Tips
                </Typography>
              </Box>
              <Box component="ul" sx={{ pl: 2 }}>
                {tips.map((tip, index) => (
                  <Typography component="li" key={index} paragraph sx={{ mb: 1 }}>
                    {tip}
                  </Typography>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%', boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Avatar sx={{ bgcolor: theme.palette.success.light, mr: 2 }}>
                  <FlightIcon />
                </Avatar>
                <Typography variant="h6" fontWeight="bold">
                  Visa & Entry Requirements
                </Typography>
              </Box>
              <Typography paragraph>
                {visaRequirements}
              </Typography>
              
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, mt: 3 }}>
                <Avatar sx={{ bgcolor: theme.palette.warning.light, mr: 2 }}>
                  <WbSunnyIcon />
                </Avatar>
                <Typography variant="h6" fontWeight="bold">
                  Health & Safety
                </Typography>
              </Box>
              <Typography variant="body2" paragraph>
                <strong>Safety Level:</strong> {healthAndSafety.safety}
              </Typography>
              <Typography variant="body2" paragraph>
                <strong>Healthcare:</strong> {healthAndSafety.healthCare}
              </Typography>
              <Typography variant="body2">
                <strong>Vaccinations:</strong> {healthAndSafety.vaccinations}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12}>
          <Card sx={{ boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                <Avatar sx={{ bgcolor: theme.palette.info.light, mr: 2 }}>
                  <AttachMoneyIcon />
                </Avatar>
                <Typography variant="h6" fontWeight="bold">
                  Budget Planning
                </Typography>
              </Box>
              
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <Paper
                    elevation={0}
                    sx={{ 
                      p: 2, 
                      textAlign: 'center',
                      bgcolor: 'rgba(0,0,0,0.02)',
                      border: '1px solid',
                      borderColor: 'divider',
                      borderRadius: 2
                    }}
                  >
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Budget Traveler
                    </Typography>
                    <Typography variant="h5" fontWeight="bold" color="text.primary">
                      {budget.budget}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      per day
                    </Typography>
                  </Paper>
                </Grid>
                
                <Grid item xs={12} sm={4}>
                  <Paper
                    elevation={0}
                    sx={{ 
                      p: 2, 
                      textAlign: 'center',
                      bgcolor: 'rgba(0,0,0,0.02)',
                      border: '1px solid',
                      borderColor: 'divider',
                      borderRadius: 2
                    }}
                  >
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Mid-Range
                    </Typography>
                    <Typography variant="h5" fontWeight="bold" color="text.primary">
                      {budget.midRange}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      per day
                    </Typography>
                  </Paper>
                </Grid>
                
                <Grid item xs={12} sm={4}>
                  <Paper
                    elevation={0}
                    sx={{ 
                      p: 2, 
                      textAlign: 'center',
                      bgcolor: 'rgba(0,0,0,0.02)',
                      border: '1px solid',
                      borderColor: 'divider',
                      borderRadius: 2
                    }}
                  >
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Luxury
                    </Typography>
                    <Typography variant="h5" fontWeight="bold" color="text.primary">
                      {budget.luxury}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      per day
                    </Typography>
                  </Paper>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Paper>
  );
};
// Main Country Profile Component
const CountryProfile = () => {
  const [country, setCountry] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);
  
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  useEffect(() => {
    // Fetch country data when component mounts
    const loadCountryData = async () => {
      try {
        const data = await fetchCountryData('jp');
        setCountry(data);
        setLoading(false);
      } catch (error) {
        console.error('Error loading country data:', error);
        setLoading(false);
      }
    };
    
    loadCountryData();
  }, []);
  
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }
  
  if (!country) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <Typography variant="h5" color="error">
          Failed to load country data. Please try again.
        </Typography>
      </Box>
    );
  }
  
  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh' }}>
      {/* Country Hero Banner */}
      <Box>
        <Hero></Hero>
      </Box>
      {/* Main Content */}
      <Container maxWidth="xl">
        {/* Navigation Tabs */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 4 }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange}
            variant="scrollable"
            scrollButtons="auto"
            allowScrollButtonsMobile
            sx={{ 
              '& .MuiTab-root': { 
                fontWeight: 'bold',
                fontSize: '1rem',
                py: 2,
                px: { xs: 2, md: 3 }
              }
            }}
          >
            <Tab label="Overview" />
            <Tab label="Cities" />
            <Tab label="Travel Info" />
            <Tab label="Experiences" />
            <Tab label="Map" />
            <Tab label="Photos" />
          </Tabs>
        </Box>
        
        {/* Overview Tab Content */}
        {tabValue === 0 && (
          <Grid container spacing={4}>
            <Grid item xs={12}>
              <Typography 
                variant="h4" 
                component="h2" 
                gutterBottom
                sx={{ fontWeight: 'bold', mb: 3 }}
              >
                About {country.name}
              </Typography>
              <Typography variant="body1" paragraph>
                {country.description}
              </Typography>
              <Divider sx={{ my: 4 }} />
            </Grid>
            
            <Grid item xs={12}>
              <MajorCities></MajorCities>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Weather></Weather>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <CurrencyExchange></CurrencyExchange>
            </Grid>
            
            <Grid item xs={12}>
              <CountryMap coordinates={country.coordinates} />
            </Grid>
          </Grid>
        )}
        
        {/* Cities Tab Content */}
        {tabValue === 1 && (
         <MajorCities></MajorCities>
        )}
        
        {/* Travel Info Tab Content */}
        {tabValue === 2 && (
          <Box>
            <Typography 
              variant="h4" 
              component="h2" 
              gutterBottom
              sx={{ fontWeight: 'bold', mb: 3 }}
            >
              Travel Information
            </Typography>
            
            <Grid container spacing={4}>
              <Grid item xs={12}>
                <TravelTips 
                  tips={country.travelTips} 
                  visaRequirements={country.visaRequirements}
                  healthAndSafety={country.healthAndSafety}
                  budget={country.budget}
                />
              </Grid>
              
              <Grid item xs={12}>
                <SeasonalEvents />
              </Grid>
              
              <Grid item xs={12}>
                <Paper sx={{ p: 3, borderRadius: 2 }}>
                  <Typography variant="h5" gutterBottom fontWeight="bold">
                    Transportation
                  </Typography>
                  
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                      <Card sx={{ height: '100%', boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}>
                        <CardContent>
                          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                            <DirectionsCarIcon sx={{ mr: 1, color: 'text.secondary' }} />
                            <Typography variant="h6" fontWeight="medium">
                              Getting Around
                            </Typography>
                          </Box>
                          <Typography variant="body2" paragraph>
                            Japan has one of the world's best public transportation systems. The rail network is extensive, efficient, and punctual.
                          </Typography>
                          <Typography variant="body2" paragraph>
                            <strong>Shinkansen (Bullet Train):</strong> High-speed trains connecting major cities. A Japan Rail Pass can be economical for tourists.
                          </Typography>
                          <Typography variant="body2" paragraph>
                            <strong>Subway/Metro:</strong> Extensive networks in Tokyo, Osaka, and other major cities.
                          </Typography>
                          <Typography variant="body2">
                            <strong>Taxis:</strong> Clean and reliable but expensive. Uber has limited availability.
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} md={6}>
                      <Card sx={{ height: '100%', boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}>
                        <CardContent>
                          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                            <LocalPhoneIcon sx={{ mr: 1, color: 'text.secondary' }} />
                            <Typography variant="h6" fontWeight="medium">
                              Practical Information
                            </Typography>
                          </Box>
                          <Typography variant="body2" paragraph>
                            <strong>Internet & Connectivity:</strong> High-speed WiFi is widely available. Portable WiFi rentals or SIM cards are recommended.
                          </Typography>
                          <Typography variant="body2" paragraph>
                            <strong>Electricity:</strong> 100V, 50/60Hz. Type A and B plugs. Adapters may be needed.
                          </Typography>
                          <Typography variant="body2" paragraph>
                            <strong>Tipping:</strong> Not customary in Japan. Service charge is usually included.
                          </Typography>
                          <Typography variant="body2">
                            <strong>Business Hours:</strong> Most shops open 10am-8pm. Banks typically 9am-3pm weekdays.
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
            </Grid>
          </Box>
        )}
        
        {/* Experiences Tab Content */}
        {tabValue === 3 && (
          <Activities> </Activities>
        )}
        
        {/* Map Tab Content */}
        {tabValue === 4 && (
          <Box>
            <Typography 
              variant="h4" 
              component="h2" 
              gutterBottom
              sx={{ fontWeight: 'bold', mb: 3 }}
            >
              Interactive Map
            </Typography>
            
            <Paper sx={{ p: 3, borderRadius: 2 }}>
              <Box 
                sx={{ 
                  height: '70vh', 
                  width: '100%', 
                  border: '1px solid',
                  borderColor: 'divider',
                  borderRadius: 1,
                  overflow: 'hidden'
                }}
              >
                {/* This would be replaced with your full interactive map implementation */}
                <iframe 
                  width="100%" 
                  height="100%" 
                  frameBorder="0" 
                  scrolling="no" 
                  marginHeight="0" 
                  marginWidth="0" 
                  src={`https://www.openstreetmap.org/export/embed.html?bbox=${country.coordinates.lng-20}%2C${country.coordinates.lat-10}%2C${country.coordinates.lng+20}%2C${country.coordinates.lat+10}&amp;layer=mapnik&amp;marker=${country.coordinates.lat}%2C${country.coordinates.lng}`}
                  style={{ border: 'none' }}
                />
              </Box>
              
              <Box sx={{ mt: 3 }}>
                <Typography variant="h6" gutterBottom fontWeight="bold">
                  Regions of {country.name}
                </Typography>
                
                <Grid container spacing={2}>
                  {[
                    "Hokkaido", "Tohoku", "Kanto", "Chubu", 
                    "Kansai", "Chugoku", "Shikoku", "Kyushu & Okinawa"
                  ].map((region) => (
                    <Grid item xs={6} sm={4} md={3} key={region}>
                      <Button 
                        variant="outlined" 
                        fullWidth
                        sx={{ 
                          justifyContent: 'flex-start',
                          py: 1
                        }}
                      >
                        {region}
                      </Button>
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </Paper>
          </Box>
        )}
        
        {/* Photos Tab Content */}
        <Photos></Photos>
        
        {/* Common Footer for all tabs - Related Countries */}
        <MightAlsoLike></MightAlsoLike>
        {/* <ParallaxBanner></ParallaxBanner> */}

        
        {/* Travel Planning Tools */}
        <Box sx={{ mt: 4, mb: 8 }}>
          <Typography 
            variant="h5" 
            component="h2" 
            gutterBottom
            sx={{ fontWeight: 'bold', mb: 3 }}
          >
            Plan Your Trip to {country.name}
          </Typography>
          
          <Grid container spacing={3}>
            {[
              { 
                title: "Find Flights", 
                description: "Compare prices from hundreds of airlines", 
                icon: <FlightIcon fontSize="large" />,
                color: "#2196f3"
              },
              { 
                title: "Book Accommodations", 
                description: "Hotels, ryokans, and vacation rentals", 
                icon: <HotelIcon fontSize="large" />,
                color: "#ff9800"
              },
              { 
                title: "Discover Experiences", 
                description: "Tours, activities, and unique local experiences", 
                icon: <ExploreIcon fontSize="large" />,
                color: "#4caf50"
              },
              { 
                title: "Transportation", 
                description: "Rail passes, car rentals, and airport transfers", 
                icon: <DirectionsCarIcon fontSize="large" />,
                color: "#f44336"
              },
            ].map((tool, index) => (
              <Grid item xs={12} sm={6} md={3} key={index}>
                <Paper
                  sx={{
                    p: 3,
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    textAlign: 'center',
                    transition: 'transform 0.3s, box-shadow 0.3s',
                    cursor: 'pointer',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                    },
                  }}
                >
                  <Avatar
                    sx={{
                      bgcolor: tool.color,
                      width: 56,
                      height: 56,
                      mb: 2,
                    }}
                  >
                    {tool.icon}
                  </Avatar>
                  <Typography variant="h6" fontWeight="bold" gutterBottom>
                    {tool.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {tool.description}
                  </Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Box>
      </Container>
    </Box>
  );
};

export default CountryProfile; 