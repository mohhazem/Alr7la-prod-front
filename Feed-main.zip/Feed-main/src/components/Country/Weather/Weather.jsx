// Weather/Weather.jsx
import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Paper, 
  Typography, 
  Grid, 
  Divider,
  CircularProgress
} from '@mui/material';
import { 
  WbSunny, 
  Cloud, 
  Opacity, 
  AcUnit, 
  Thunderstorm,
  Air
} from '@mui/icons-material';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

// Weather animations components remain the same...
// ... (All animation components code is unchanged) ...

// Temperature Chart Component
const TemperatureChart = ({ weatherData }) => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  const data = {
    labels: months,
    datasets: [
      {
        label: 'Average High (°C)',
        data: weatherData.highTemps,
        borderColor: '#ff7043',
        backgroundColor: 'rgba(255, 112, 67, 0.2)',
        tension: 0.3,
        fill: true
      },
      {
        label: 'Average Low (°C)',
        data: weatherData.lowTemps,
        borderColor: '#42a5f5',
        backgroundColor: 'rgba(66, 165, 245, 0.2)',
        tension: 0.3,
        fill: true
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: false,
        title: {
          display: true,
          text: 'Temperature (°C)'
        }
      }
    },
    plugins: {
      legend: {
        position: 'top',
      },
      tooltip: {
        callbacks: {
          title: (items) => {
            return items[0].label;
          },
          label: (item) => {
            return `${item.dataset.label}: ${item.raw}°C`;
          }
        }
      }
    }
  };

  return (
    <Box sx={{ height: 250, p: 1, mt: 2 }}>
      <Line data={data} options={options} />
    </Box>
  );
};

// Main Weather Component
const Weather = ({ country = {} }) => {  // Add default empty object
  const countryName = country?.name || "This Country";  // Add fallback value
  
  const [currentWeather, setCurrentWeather] = useState({
    condition: 'sunny', // Default value
    temperature: 22,
    humidity: 65,
    windSpeed: 12
  });
  
  const [loading, setLoading] = useState(true);

  // Sample weather data (this would normally come from API)
  const weatherData = {
    highTemps: [10, 11, 15, 19, 23, 26, 29, 31, 27, 22, 17, 12],
    lowTemps: [2, 3, 6, 10, 14, 18, 22, 24, 20, 15, 9, 4],
    seasons: [
      { name: 'Spring', months: 'March to May', description: 'Cherry blossoms, mild temperatures' },
      { name: 'Summer', months: 'June to August', description: 'Hot and humid, occasional typhoons' },
      { name: 'Fall', months: 'September to November', description: 'Colorful leaves, comfortable weather' },
      { name: 'Winter', months: 'December to February', description: 'Cold in north, mild in south' }
    ]
  };
  
  // Simulate fetching weather data
  useEffect(() => {
    const fetchWeather = async () => {
      // In a real app, fetch from weather API based on country/city
      // Simulating API call with timeout
      setTimeout(() => {
        // Generate random weather for demo purposes
        const conditions = ['sunny', 'cloudy', 'rainy', 'snowy', 'thunderstorm', 'windy'];
        const randomCondition = conditions[Math.floor(Math.random() * conditions.length)];
        
        setCurrentWeather({
          condition: randomCondition,
          temperature: Math.floor(Math.random() * 30),
          humidity: 40 + Math.floor(Math.random() * 50),
          windSpeed: 5 + Math.floor(Math.random() * 20)
        });
        setLoading(false);
      }, 1000);
    };
    
    fetchWeather();
  }, [country]);
  
  return (
    <Paper elevation={3} sx={{ p: 3, height: '100%' }}>
      <Typography variant="h5" component="h2" gutterBottom>
        Weather in {countryName}
      </Typography>
      
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          {/* Current Weather with Animation */}
          <Box sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom>Current Weather</Typography>
            <WeatherAnimation condition={currentWeather.condition} />
            
            <Grid container spacing={2} sx={{ mt: 2 }}>
              <Grid item xs={4}>
                <Typography variant="body2" color="text.secondary">Temperature</Typography>
                <Typography variant="h6">{currentWeather.temperature}°C</Typography>
              </Grid>
              <Grid item xs={4}>
                <Typography variant="body2" color="text.secondary">Humidity</Typography>
                <Typography variant="h6">{currentWeather.humidity}%</Typography>
              </Grid>
              <Grid item xs={4}>
                <Typography variant="body2" color="text.secondary">Wind</Typography>
                <Typography variant="h6">{currentWeather.windSpeed} km/h</Typography>
              </Grid>
            </Grid>
          </Box>
          
          <Divider sx={{ my: 2 }} />
          
          {/* Temperature Throughout the Year Chart */}
          <Box>
            <Typography variant="h6" gutterBottom>Temperature Throughout the Year</Typography>
            <TemperatureChart weatherData={weatherData} />
          </Box>
          
          <Divider sx={{ my: 2 }} />
          
          {/* Seasons Information */}
          <Box>
            <Typography variant="h6" gutterBottom>Seasons in {countryName}</Typography>
            <Grid container spacing={1}>
              {weatherData.seasons.map((season, index) => (
                <Grid item xs={6} key={index}>
                  <Box sx={{ p: 1, bgcolor: 'background.paper', borderRadius: 1, height: '100%' }}>
                    <Typography variant="subtitle1" fontWeight="bold">{season.name}</Typography>
                    <Typography variant="caption" display="block" color="text.secondary">
                      {season.months}
                    </Typography>
                    <Typography variant="body2">{season.description}</Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Box>
        </>
      )}
    </Paper>
  );
};
// Weather Animation Component
const WeatherAnimation = ({ condition }) => {
  const animationStyle = {
    position: 'relative',
    height: '120px',
    width: '100%',
    overflow: 'hidden',
    backgroundColor: condition === 'night' ? '#1a237e' : '#bbdefb',
    borderRadius: '8px'
  };

  return (
    <Box sx={animationStyle}>
      {condition === 'sunny' && <SunnyAnimation />}
      {condition === 'cloudy' && <CloudyAnimation />}
      {condition === 'rainy' && <RainyAnimation />}
      {condition === 'snowy' && <SnowyAnimation />}
      {condition === 'thunderstorm' && <ThunderstormAnimation />}
      {condition === 'windy' && <WindyAnimation />}
      {condition === 'night' && <NightAnimation />}
    </Box>
  );
};

// Individual Weather Animations
const SunnyAnimation = () => {
  return (
    <Box sx={{ 
      position: 'relative',
      height: '100%',
      animation: 'pulse 3s infinite' 
    }}>
      <Box
        component={WbSunny}
        sx={{
          position: 'absolute',
          color: '#FF9800',
          fontSize: '60px',
          top: '30px',
          left: '50%',
          transform: 'translateX(-50%)',
          animation: 'float 5s infinite ease-in-out'
        }}
      />
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateX(-50%) translateY(0px); }
          50% { transform: translateX(-50%) translateY(-10px); }
        }
        @keyframes pulse {
          0%, 100% { background-color: #bbdefb; }
          50% { background-color: #90caf9; }
        }
      `}</style>
    </Box>
  );
};

const CloudyAnimation = () => {
  return (
    <Box sx={{ position: 'relative', height: '100%' }}>
      <Box
        component={Cloud}
        sx={{
          position: 'absolute',
          color: '#E0E0E0',
          fontSize: '40px',
          top: '20px',
          left: '30%',
          animation: 'moveCloud 15s infinite linear'
        }}
      />
      <Box
        component={Cloud}
        sx={{
          position: 'absolute',
          color: '#BDBDBD',
          fontSize: '60px',
          top: '40px',
          left: '50%',
          animation: 'moveCloud 20s infinite linear'
        }}
      />
      <Box
        component={Cloud}
        sx={{
          position: 'absolute',
          color: '#9E9E9E',
          fontSize: '50px',
          top: '30px',
          left: '20%',
          animation: 'moveCloud 18s infinite linear'
        }}
      />
      <style jsx>{`
        @keyframes moveCloud {
          0% { transform: translateX(0); }
          100% { transform: translateX(calc(100vw - 60px)); }
        }
      `}</style>
    </Box>
  );
};

const RainyAnimation = () => {
  return (
    <Box sx={{ position: 'relative', height: '100%', backgroundColor: '#78909c' }}>
      <Box
        component={Cloud}
        sx={{
          position: 'absolute',
          color: '#616161',
          fontSize: '60px',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)'
        }}
      />
      {[...Array(20)].map((_, i) => (
        <Box
          key={i}
          component={Opacity}
          sx={{
            position: 'absolute',
            color: '#42a5f5',
            fontSize: '16px',
            top: `${Math.random() * 10}px`,
            left: `${Math.random() * 100}%`,
            animation: `raindrop ${1 + Math.random() * 2}s infinite linear`,
            animationDelay: `${Math.random() * 2}s`
          }}
        />
      ))}
      <style jsx>{`
        @keyframes raindrop {
          0% { transform: translateY(0); opacity: 0; }
          50% { opacity: 1; }
          100% { transform: translateY(100px); opacity: 0; }
        }
      `}</style>
    </Box>
  );
};

const SnowyAnimation = () => {
  return (
    <Box sx={{ position: 'relative', height: '100%', backgroundColor: '#cfd8dc' }}>
      <Box
        component={Cloud}
        sx={{
          position: 'absolute',
          color: '#9e9e9e',
          fontSize: '60px',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)'
        }}
      />
      {[...Array(15)].map((_, i) => (
        <Box
          key={i}
          component={AcUnit}
          sx={{
            position: 'absolute',
            color: 'white',
            fontSize: '14px',
            top: `${Math.random() * 10}px`,
            left: `${Math.random() * 100}%`,
            animation: `snowfall ${3 + Math.random() * 4}s infinite linear`,
            animationDelay: `${Math.random() * 3}s`
          }}
        />
      ))}
      <style jsx>{`
        @keyframes snowfall {
          0% { transform: translateY(0) rotate(0deg); opacity: 0; }
          20% { opacity: 1; }
          100% { transform: translateY(100px) rotate(360deg); opacity: 0; }
        }
      `}</style>
    </Box>
  );
};

const ThunderstormAnimation = () => {
  return (
    <Box sx={{ position: 'relative', height: '100%', backgroundColor: '#455a64' }}>
      <Box
        component={Cloud}
        sx={{
          position: 'absolute',
          color: '#212121',
          fontSize: '60px',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)'
        }}
      />
      {[...Array(8)].map((_, i) => (
        <Box
          key={i}
          component={Opacity}
          sx={{
            position: 'absolute',
            color: '#42a5f5',
            fontSize: '16px',
            top: `${Math.random() * 10}px`,
            left: `${Math.random() * 100}%`,
            animation: `raindrop ${1 + Math.random() * 2}s infinite linear`,
            animationDelay: `${Math.random() * 2}s`
          }}
        />
      ))}
      <Box
        component={Thunderstorm}
        sx={{
          position: 'absolute',
          color: '#ffeb3b',
          fontSize: '30px',
          top: '50px',
          left: '45%',
          animation: 'lightning 4s infinite',
          opacity: 0
        }}
      />
      <style jsx>{`
        @keyframes raindrop {
          0% { transform: translateY(0); opacity: 0; }
          50% { opacity: 1; }
          100% { transform: translateY(100px); opacity: 0; }
        }
        @keyframes lightning {
          0%, 90%, 100% { opacity: 0; }
          92%, 94%, 96% { opacity: 1; transform: scale(1); }
          93%, 95%, 97% { opacity: 1; transform: scale(1.2); }
        }
      `}</style>
    </Box>
  );
};

const WindyAnimation = () => {
  return (
    <Box sx={{ position: 'relative', height: '100%' }}>
      {[...Array(8)].map((_, i) => (
        <Box
          key={i}
          component={Air}
          sx={{
            position: 'absolute',
            color: '#9e9e9e',
            fontSize: `${20 + Math.random() * 20}px`,
            top: `${20 + Math.random() * 60}px`,
            left: `-50px`,
            animation: `wind ${5 + Math.random() * 5}s infinite linear`,
            animationDelay: `${Math.random() * 5}s`
          }}
        />
      ))}
      <style jsx>{`
        @keyframes wind {
          0% { transform: translateX(0) scale(0.5); opacity: 0; }
          20% { opacity: 1; }
          100% { transform: translateX(calc(100vw + 50px)) scale(1); opacity: 0; }
        }
      `}</style>
    </Box>
  );
};

const NightAnimation = () => {
  return (
    <Box sx={{ position: 'relative', height: '100%' }}>
      <Box
        sx={{
          position: 'absolute',
          height: '40px',
          width: '40px',
          borderRadius: '50%',
          backgroundColor: '#f5f5f5',
          boxShadow: '0 0 20px 5px rgba(255, 255, 255, 0.3)',
          top: '30px',
          right: '30px'
        }}
      />
      {[...Array(20)].map((_, i) => (
        <Box
          key={i}
          sx={{
            position: 'absolute',
            height: `${1 + Math.random() * 3}px`,
            width: `${1 + Math.random() * 3}px`,
            borderRadius: '50%',
            backgroundColor: 'white',
            top: `${Math.random() * 100}px`,
            left: `${Math.random() * 100}%`,
            animation: `twinkle ${1 + Math.random() * 5}s infinite ease-in-out`,
            animationDelay: `${Math.random() * 5}s`
          }}
        />
      ))}
      <style jsx>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
      `}</style>
    </Box>
  );
};
export default Weather;