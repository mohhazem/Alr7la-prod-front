// Hero/Hero.jsx
import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Button, 
  IconButton, 
  Chip, 
  Avatar,
  useTheme,
  useMediaQuery,
  Fade,
  Slide,
  Paper,
  Rating
} from '@mui/material';
import { 
  Flight as FlightIcon, 
  Public as PublicIcon, 
  Language as LanguageIcon, 
  AccessTime as AccessTimeIcon, 
  LocalAtm as LocalAtmIcon,
  Bookmark as BookmarkIcon,
  BookmarkBorder as BookmarkBorderIcon,
  Share as ShareIcon,
  ArrowDownward as ArrowDownwardIcon,
  ArrowForward as ArrowForwardIcon,
  Hotel as HotelIcon,
  DirectionsCar as DirectionsCarIcon,
  Restaurant as RestaurantIcon
} from '@mui/icons-material';

const Hero = ({ country = {} }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isMedium = useMediaQuery(theme.breakpoints.down('md'));
  const [saved, setSaved] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [scrollIndicator, setScrollIndicator] = useState(true);
  
  // Default values if country object is incomplete
  const countryName = country.name || "Japan";
  const description = country.description || "A fascinating island nation with a unique blend of ancient traditions and cutting-edge technology, offering visitors an unforgettable cultural experience.";
  const region = country.region || "Asia";
  const languages = country.languages || ["Japanese"];
  const timezones = country.timezones || ["UTC+9"];
  const currencies = country.currencies || [{ name: "Japanese Yen", code: "JPY" }];
  const flagUrl = country.flagUrl || "https://upload.wikimedia.org/wikipedia/en/thumb/9/9e/Flag_of_Japan.svg/1200px-Flag_of_Japan.svg.png";
  const imageUrl = country.imageUrl || "https://images.unsplash.com/photo-1492571350019-22de08371fd3";
  const rating = country.rating || 4.8;

  // Load animation effect
  useEffect(() => {
    setLoaded(true);
    
    // Hide scroll indicator after 5 seconds
    const timer = setTimeout(() => {
      setScrollIndicator(false);
    }, 5000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Handle bookmark toggle
  const toggleSaved = () => {
    setSaved(!saved);
  };
  
  // Format description
  const formattedDescription = description.split('.')[0] + '.';
  
  // Get additional images for slideshow effect
  const additionalImages = country.additionalImages || [
    "https://images.unsplash.com/photo-1528164344705-47542687000d",
    "https://images.unsplash.com/photo-1536098561742-ca998e48cbcc",
    "https://images.unsplash.com/photo-1545569341-9eb8b30979d9"
  ];
  
  // Image slideshow effect
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const images = [imageUrl, ...additionalImages];
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 8000);
    
    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <Box
      sx={{
        position: 'relative',
        height: { xs: '70vh', md: '80vh' },
        overflow: 'hidden',
        mb: 6,
      }}
    >
      {/* Background images with crossfade effect */}
      {images.map((img, index) => (
        <Box
          key={index}
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundImage: `url(${img})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            transition: 'opacity 1.5s ease-in-out',
            opacity: index === currentImageIndex ? 1 : 0,
            zIndex: 0,
          }}
        />
      ))}
      
      {/* Gradient overlay */}
      <Box
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'linear-gradient(to bottom, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.6) 100%)',
          zIndex: 1
        }}
      />
      
      {/* Travel badge */}
      <Fade in={loaded} timeout={1000}>
        <Box
          sx={{
            position: 'absolute',
            top: 24,
            right: 24,
            zIndex: 3,
            display: { xs: 'none', md: 'block' }
          }}
        >
          <Paper
            elevation={4}
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              p: 1.5,
              borderRadius: '12px',
              bgcolor: 'rgba(255,255,255,0.85)',
              backdropFilter: 'blur(5px)',
            }}
          >
            <Rating value={rating} precision={0.1} readOnly size="small" />
            <Typography variant="caption" fontWeight="bold" color="text.secondary" mt={0.5}>
              TRAVELER'S CHOICE
            </Typography>
            <Typography variant="body2" fontWeight="bold" color="primary">
              {rating}/5
            </Typography>
          </Paper>
        </Box>
      </Fade>
      
      {/* Main content */}
      <Container 
        maxWidth="xl"
        sx={{ 
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-end',
          position: 'relative',
          zIndex: 2,
          pb: 6
        }}
      >
        <Slide direction="up" in={loaded} timeout={800}>
          <Box>
            {/* Country name with flag */}
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Avatar 
                src={flagUrl} 
                alt={`${countryName} flag`}
                sx={{ 
                  width: { xs: 60, md: 90 }, 
                  height: { xs: 60, md: 90 },
                  border: '3px solid white',
                  mr: 3,
                  boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
                }}
              />
              <Typography 
                variant={isMobile ? "h3" : "h1"} 
                component="h1"
                sx={{ 
                  fontWeight: 800,
                  textShadow: '2px 2px 8px rgba(0,0,0,0.7)',
                  color: 'white',
                  letterSpacing: '-0.5px'
                }}
              >
                {countryName}
              </Typography>
            </Box>
            
            {/* Description */}
            <Fade in={loaded} timeout={1200}>
              <Typography 
                variant={isMobile ? "h6" : "h5"} 
                sx={{ 
                  maxWidth: '800px',
                  mb: 3,
                  textShadow: '1px 1px 3px rgba(0,0,0,0.8)',
                  color: 'white',
                  fontWeight: isMobile ? 400 : 500,
                  lineHeight: 1.4
                }}
              >
                {formattedDescription}
              </Typography>
            </Fade>
            
            {/* Info chips */}
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 4 }}>
              <Fade in={loaded} timeout={1400}>
                <Chip 
                  icon={<PublicIcon />} 
                  label={`Region: ${region}`}
                  sx={{ 
                    bgcolor: 'rgba(255,255,255,0.9)', 
                    color: 'text.primary',
                    fontWeight: 500,
                    '&:hover': {
                      bgcolor: 'rgba(255,255,255,1)',
                    }
                  }}
                />
              </Fade>
              <Fade in={loaded} timeout={1600}>
                <Chip 
                  icon={<LanguageIcon />} 
                  label={`Language: ${languages.join(', ')}`}
                  sx={{ 
                    bgcolor: 'rgba(255,255,255,0.9)', 
                    color: 'text.primary',
                    fontWeight: 500,
                    '&:hover': {
                      bgcolor: 'rgba(255,255,255,1)',
                    }
                  }}
                />
              </Fade>
              <Fade in={loaded} timeout={1800}>
                <Chip 
                  icon={<AccessTimeIcon />} 
                  label={`Timezone: ${timezones[0]}`}
                  sx={{ 
                    bgcolor: 'rgba(255,255,255,0.9)', 
                    color: 'text.primary',
                    fontWeight: 500,
                    '&:hover': {
                      bgcolor: 'rgba(255,255,255,1)',
                    }
                  }}
                />
              </Fade>
              <Fade in={loaded} timeout={2000}>
                <Chip 
                  icon={<LocalAtmIcon />} 
                  label={`Currency: ${currencies[0].name}`}
                  sx={{ 
                    bgcolor: 'rgba(255,255,255,0.9)', 
                    color: 'text.primary',
                    fontWeight: 500,
                    '&:hover': {
                      bgcolor: 'rgba(255,255,255,1)',
                    }
                  }}
                />
              </Fade>
            </Box>
            
            {/* Action buttons */}
            <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
              <Fade in={loaded} timeout={2200}>
                <Button 
                  variant="contained" 
                  size="large"
                  startIcon={<FlightIcon />}
                  endIcon={<ArrowForwardIcon />}
                  sx={{ 
                    bgcolor: theme.palette.primary.main,
                    px: 3,
                    py: 1.5,
                    borderRadius: '28px',
                    boxShadow: '0 4px 14px rgba(0,0,0,0.4)',
                    '&:hover': {
                      bgcolor: theme.palette.primary.dark,
                      transform: 'translateY(-2px)',
                      boxShadow: '0 6px 20px rgba(0,0,0,0.4)',
                    },
                    transition: 'all 0.2s ease-in-out'
                  }}
                >
                  Plan Your Trip
                </Button>
              </Fade>
              
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Fade in={loaded} timeout={2400}>
                  <Button
                    variant="outlined"
                    startIcon={<HotelIcon />}
                    sx={{
                      color: 'white',
                      borderColor: 'rgba(255,255,255,0.6)',
                      bgcolor: 'rgba(255,255,255,0.1)',
                      backdropFilter: 'blur(5px)',
                      '&:hover': {
                        borderColor: 'white',
                        bgcolor: 'rgba(255,255,255,0.2)',
                      }
                    }}
                  >
                    {isMedium ? '' : 'Find Hotels'}
                  </Button>
                </Fade>
                
                <Fade in={loaded} timeout={2600}>
                  <Button
                    variant="outlined"
                    startIcon={<RestaurantIcon />}
                    sx={{
                      color: 'white',
                      borderColor: 'rgba(255,255,255,0.6)',
                      bgcolor: 'rgba(255,255,255,0.1)',
                      backdropFilter: 'blur(5px)',
                      '&:hover': {
                        borderColor: 'white',
                        bgcolor: 'rgba(255,255,255,0.2)',
                      }
                    }}
                  >
                    {isMedium ? '' : 'Restaurants'}
                  </Button>
                </Fade>
                
                <Fade in={loaded} timeout={2800}>
                  <Button
                    variant="outlined"
                    startIcon={<DirectionsCarIcon />}
                    sx={{
                      color: 'white',
                      borderColor: 'rgba(255,255,255,0.6)',
                      bgcolor: 'rgba(255,255,255,0.1)',
                      backdropFilter: 'blur(5px)',
                      '&:hover': {
                        borderColor: 'white',
                        bgcolor: 'rgba(255,255,255,0.2)',
                      },
                      display: { xs: 'none', sm: 'flex' }
                    }}
                  >
                    {isMedium ? '' : 'Car Rental'}
                  </Button>
                </Fade>
              </Box>
              
              <Box sx={{ ml: 'auto', display: 'flex', gap: 1 }}>
                <Fade in={loaded} timeout={3000}>
                  <IconButton 
                    aria-label={saved ? 'remove from favorites' : 'save destination'} 
                    onClick={toggleSaved}
                    sx={{ 
                      bgcolor: 'rgba(255,255,255,0.15)',
                      backdropFilter: 'blur(5px)',
                      color: saved ? '#f44336' : 'white',
                      '&:hover': {
                        bgcolor: 'rgba(255,255,255,0.25)',
                      },
                      transition: 'all 0.2s ease'
                    }}
                  >
                    {saved ? <BookmarkIcon /> : <BookmarkBorderIcon />}
                  </IconButton>
                </Fade>
                
                <Fade in={loaded} timeout={3200}>
                  <IconButton 
                    aria-label="share destination" 
                    sx={{ 
                      bgcolor: 'rgba(255,255,255,0.15)',
                      backdropFilter: 'blur(5px)',
                      color: 'white',
                      '&:hover': {
                        bgcolor: 'rgba(255,255,255,0.25)',
                      }
                    }}
                  >
                    <ShareIcon />
                  </IconButton>
                </Fade>
              </Box>
            </Box>
          </Box>
        </Slide>
      </Container>
      
      {/* Scroll indicator */}
      <Fade in={scrollIndicator} timeout={2000}>
        <Box
          sx={{
            position: 'absolute',
            bottom: 20,
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 2,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            color: 'white',
            opacity: 0.8
          }}
        >
          <Typography variant="caption" sx={{ mb: 1, textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}>
            Scroll to explore
          </Typography>
          <ArrowDownwardIcon 
            sx={{ 
              animation: 'bounce 2s infinite',
              '@keyframes bounce': {
                '0%, 20%, 50%, 80%, 100%': { transform: 'translateY(0)' },
                '40%': { transform: 'translateY(-10px)' },
                '60%': { transform: 'translateY(-5px)' }
              }
            }} 
          />
        </Box>
      </Fade>
    </Box>
  );
};

export default Hero;