// Photos/Activities.jsx
import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Grid, 
  Card, 
  CardMedia, 
  IconButton, 
  Modal, 
  Fade, 
  Backdrop, 
  Skeleton,
  Paper,
  Button,
  Chip,
  useMediaQuery,
  useTheme,
  Divider
} from '@mui/material';
import { 
  Close as CloseIcon,
  ZoomIn as ZoomInIcon,
  PhotoLibrary as PhotoLibraryIcon,
  NavigateBefore as NavigateBeforeIcon,
  NavigateNext as NavigateNextIcon,
  Favorite as FavoriteIcon,
  FavoriteBorder as FavoriteBorderIcon,
  Share as ShareIcon,
  Download as DownloadIcon,
  ArrowForward as ArrowForwardIcon
} from '@mui/icons-material';

// Individual Photo Component
const PhotoItem = ({ photo, index, handleOpen }) => {
  const [loaded, setLoaded] = useState(false);
  const [hovered, setHovered] = useState(false);
  
  return (
    <Card 
      elevation={2}
      sx={{
        position: 'relative',
        height: '100%',
        cursor: 'pointer',
        overflow: 'hidden',
        transition: 'transform 0.3s ease, box-shadow 0.3s ease',
        '&:hover': {
          transform: 'scale(1.02)',
          boxShadow: '0 8px 16px rgba(0,0,0,0.2)',
          '& .zoom-overlay': {
            opacity: 1
          }
        }
      }}
      onClick={() => handleOpen(index)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {!loaded && (
        <Skeleton
          variant="rectangular"
          animation="wave"
          sx={{
            height: index % 3 === 0 ? 300 : 220,
            width: '100%'
          }}
        />
      )}
      <CardMedia
        component="img"
        image={photo.imageUrl}
        alt={photo.title || 'Travel photo'}
        sx={{
          height: index % 3 === 0 ? 300 : 220,
          objectFit: 'cover',
          display: loaded ? 'block' : 'none'
        }}
        onLoad={() => setLoaded(true)}
      />
      
      {/* Hover Overlay */}
      <Box
        className="zoom-overlay"
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          bgcolor: 'rgba(0,0,0,0.4)',
          opacity: hovered ? 1 : 0,
          transition: 'opacity 0.3s ease',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
      >
        <IconButton
          aria-label="zoom"
          sx={{
            bgcolor: 'rgba(255,255,255,0.9)',
            '&:hover': {
              bgcolor: 'rgba(255,255,255,1)',
            }
          }}
        >
          <ZoomInIcon />
        </IconButton>
      </Box>
      
      {/* Caption overlay */}
      {photo.title && (
        <Box
          sx={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            p: 1.5,
            background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, transparent 100%)',
            color: 'white',
            opacity: hovered ? 1 : 0.8,
            transition: 'opacity 0.3s ease'
          }}
        >
          <Typography variant="subtitle1" sx={{ fontWeight: 500, textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}>
            {photo.title}
          </Typography>
          {photo.location && (
            <Typography variant="caption" component="div" sx={{ textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}>
              {photo.location}
            </Typography>
          )}
        </Box>
      )}
    </Card>
  );
};

// Photo Viewer Modal Component
const PhotoModal = ({ open, handleClose, currentIndex, photos, setCurrentIndex }) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
  const [favorite, setFavorite] = useState(false);
  const [loaded, setLoaded] = useState(false);
  
  const handlePrev = (e) => {
    e.stopPropagation();
    setLoaded(false);
    setCurrentIndex((prevIndex) => (prevIndex > 0 ? prevIndex - 1 : photos.length - 1));
  };
  
  const handleNext = (e) => {
    e.stopPropagation();
    setLoaded(false);
    setCurrentIndex((prevIndex) => (prevIndex < photos.length - 1 ? prevIndex + 1 : 0));
  };
  
  const toggleFavorite = (e) => {
    e.stopPropagation();
    setFavorite(!favorite);
  };
  
  // Reset loaded state when photo changes
  useEffect(() => {
    setLoaded(false);
  }, [currentIndex]);
  
  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!open) return;
      
      switch (e.key) {
        case 'ArrowLeft':
          handlePrev(e);
          break;
        case 'ArrowRight':
          handleNext(e);
          break;
        case 'Escape':
          handleClose();
          break;
        default:
          break;
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, handlePrev, handleNext, handleClose]);
  
  if (!open || !photos[currentIndex]) return null;
  
  const currentPhoto = photos[currentIndex];
  
  return (
    <Modal
      open={open}
      onClose={handleClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        p: { xs: 1, sm: 2, md: 4 }
      }}
    >
      <Fade in={open}>
        <Paper
          elevation={24}
          onClick={(e) => e.stopPropagation()}
          sx={{
            position: 'relative',
            maxWidth: fullScreen ? '100%' : '90%',
            maxHeight: fullScreen ? '100%' : '90%',
            width: fullScreen ? '100%' : 'auto',
            height: fullScreen ? '100%' : 'auto',
            outline: 'none',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            bgcolor: 'background.paper',
          }}
        >
          {/* Modal Header */}
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            p: 2,
            borderBottom: '1px solid',
            borderColor: 'divider'
          }}>
            <Box>
              <Typography variant="h6" component="h3" sx={{ fontWeight: 500 }}>
                {currentPhoto.title || 'Photo View'}
              </Typography>
              {currentPhoto.location && (
                <Typography variant="body2" color="text.secondary">
                  {currentPhoto.location}
                </Typography>
              )}
            </Box>
            
            <Box sx={{ display: 'flex', gap: 1 }}>
              <IconButton size="small" onClick={toggleFavorite} color={favorite ? "error" : "default"}>
                {favorite ? <FavoriteIcon /> : <FavoriteBorderIcon />}
              </IconButton>
              <IconButton size="small">
                <ShareIcon />
              </IconButton>
              <IconButton size="small">
                <DownloadIcon />
              </IconButton>
              <IconButton size="small" onClick={handleClose}>
                <CloseIcon />
              </IconButton>
            </Box>
          </Box>
          
          {/* Image Container */}
          <Box sx={{ 
            position: 'relative',
            flexGrow: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            bgcolor: 'black',
            overflow: 'hidden',
            minHeight: { xs: 300, sm: 400, md: 500 }
          }}>
            {!loaded && (
              <Box sx={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Skeleton 
                  variant="rectangular" 
                  width="100%" 
                  height="100%" 
                  animation="wave" 
                  sx={{ position: 'absolute' }}
                />
              </Box>
            )}
            
            <CardMedia
              component="img"
              image={currentPhoto.imageUrl}
              alt={currentPhoto.title || 'Travel photo'}
              sx={{
                maxWidth: '100%',
                maxHeight: '100%',
                objectFit: 'contain',
                opacity: loaded ? 1 : 0,
                transition: 'opacity 0.3s ease'
              }}
              onLoad={() => setLoaded(true)}
            />
            
            {/* Navigation Buttons */}
            <IconButton
              sx={{
                position: 'absolute',
                left: 16,
                bgcolor: 'rgba(255,255,255,0.7)',
                '&:hover': {
                  bgcolor: 'rgba(255,255,255,0.9)',
                }
              }}
              onClick={handlePrev}
              aria-label="previous photo"
            >
              <NavigateBeforeIcon />
            </IconButton>
            
            <IconButton
              sx={{
                position: 'absolute',
                right: 16,
                bgcolor: 'rgba(255,255,255,0.7)',
                '&:hover': {
                  bgcolor: 'rgba(255,255,255,0.9)',
                }
              }}
              onClick={handleNext}
              aria-label="next photo"
            >
              <NavigateNextIcon />
            </IconButton>
            
            {/* Photo Counter */}
            <Chip
              label={`${currentIndex + 1} / ${photos.length}`}
              size="small"
              sx={{
                position: 'absolute',
                bottom: 16,
                left: '50%',
                transform: 'translateX(-50%)',
                bgcolor: 'rgba(0,0,0,0.6)',
                color: 'white',
                backdropFilter: 'blur(4px)'
              }}
            />
          </Box>
          
          {/* Photo Description */}
          {currentPhoto.description && (
            <Box sx={{ p: 2, borderTop: '1px solid', borderColor: 'divider' }}>
              <Typography variant="body1">
                {currentPhoto.description}
              </Typography>
              {currentPhoto.tags && currentPhoto.tags.length > 0 && (
                <Box sx={{ mt: 2, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {currentPhoto.tags.map((tag, idx) => (
                    <Chip 
                      key={idx} 
                      label={tag} 
                      size="small" 
                      variant="outlined" 
                      sx={{ fontSize: 12 }}
                    />
                  ))}
                </Box>
              )}
            </Box>
          )}
        </Paper>
      </Fade>
    </Modal>
  );
};

// Main Photos Component
const Photos = ({ country = {} }) => {
  const theme = useTheme();
  const [open, setOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // Default photos if none provided
  const defaultPhotos = [
    {
      imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e",
      title: "Kiyomizu-dera Temple",
      location: "Kyoto, Japan",
      description: "Kiyomizu-dera is a Buddhist temple founded in 778 AD. Part of the Historic Monuments of Ancient Kyoto UNESCO World Heritage site.",
      tags: ["Temple", "Cultural", "UNESCO"]
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1528360983277-13d401cdc186",
      title: "Cherry Blossoms",
      location: "Tokyo, Japan",
      description: "Cherry blossom season (Sakura) typically occurs between late March and early April, and is a major tourist attraction.",
      tags: ["Sakura", "Spring", "Nature"]
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1545569341-9eb8b30979d9",
      title: "Mount Fuji",
      location: "Shizuoka, Japan",
      description: "Japan's highest mountain at 3,776 meters, this active volcano is a popular tourist destination and cultural icon.",
      tags: ["Mountain", "Nature", "Landmark"]
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1524413840807-0c3cb6fa808d",
      title: "Fushimi Inari Shrine",
      location: "Kyoto, Japan",
      description: "Famous for its thousands of vermilion torii gates, this Shinto shrine is dedicated to Inari, the god of rice.",
      tags: ["Shrine", "Cultural", "Torii"]
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1490806843957-31f4c9a91c65",
      title: "Shibuya Crossing",
      location: "Tokyo, Japan",
      description: "One of the busiest pedestrian crossings in the world, this famous intersection outside Shibuya Station is a symbol of modern Tokyo.",
      tags: ["Urban", "City", "Modern"]
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1480796927426-f609979314bd",
      title: "Traditional Japanese Garden",
      location: "Kanazawa, Japan",
      description: "Japanese gardens are designed with principles of minimalism and natural landscapes in mind.",
      tags: ["Garden", "Zen", "Nature"]
    }
  ];
  
  const photos = country.photos && country.photos.length > 0 ? country.photos : defaultPhotos;
  
  const handleOpen = (index) => {
    setCurrentIndex(index);
    setOpen(true);
  };
  
  const handleClose = () => {
    setOpen(false);
  };
  
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
        <PhotoLibraryIcon sx={{ fontSize: 28, color: theme.palette.primary.main, mr: 1.5 }} />
        <Typography variant="h4" component="h2" fontWeight="bold">
          Photo Gallery
        </Typography>
      </Box>
      
      <Typography variant="subtitle1" color="text.secondary" paragraph>
        Explore the beauty of {country.name || "this country"} through our carefully curated collection of stunning photos.
      </Typography>
      
      <Grid container spacing={2}>
        {photos.map((photo, index) => (
          <Grid 
            item 
            xs={12} 
            sm={index % 3 === 0 ? 12 : 6} 
            md={index % 3 === 0 ? 6 : 3}
            key={index}
          >
            <PhotoItem 
              photo={photo}
              index={index}
              handleOpen={handleOpen}
            />
          </Grid>
        ))}
      </Grid>
      
      {photos.length > 6 && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <Button 
            variant="outlined" 
            color="primary"
            endIcon={<ArrowForwardIcon />}
            size="large"
          >
            View Full Gallery
          </Button>
        </Box>
      )}
      
      {/* Photo Modal */}
      <PhotoModal
        open={open}
        handleClose={handleClose}
        currentIndex={currentIndex}
        photos={photos}
        setCurrentIndex={setCurrentIndex}
      />
    </Box>
  );
};

export default Photos;