import React, { useRef } from 'react';
import { Avatar, IconButton, Box } from '@mui/material';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import { useUserContext } from '../context/UserContext';

const UserAvatar = ({ size = 32, sx = {}, allowChange = false }) => {
  const { profilePhoto, updateProfilePhoto } = useUserContext();
  const fileInputRef = useRef(null);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newAvatar = reader.result;
        updateProfilePhoto(newAvatar);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClick = () => {
    if (allowChange) {
      fileInputRef.current.click();
    }
  };

  return (
    <Box 
      sx={{ 
        position: 'relative', 
        display: 'inline-block',
        '&:hover .profile-photo-edit': {
          opacity: 1,
        },
      }}
    >
      <Avatar
        src={profilePhoto}
        alt="User Avatar"
        sx={{
          width: size,
          height: size,
          cursor: allowChange ? 'pointer' : 'default',
          ...sx
        }}
        onClick={handleClick}
      />
      {allowChange && (
        <>
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileChange}
            style={{ display: 'none' }}
          />
          <IconButton
            className="profile-photo-edit"
            sx={{
              position: 'absolute',
              bottom: 0,
              right: 0,
              backgroundColor: 'primary.main',
              color: 'white',
              opacity: 0,
              transition: 'opacity 0.2s',
              '&:hover': {
                backgroundColor: 'primary.dark',
              },
              width: size * 0.4,
              height: size * 0.4,
              minWidth: 0,
              minHeight: 0,
            }}
            onClick={handleClick}
          >
            <PhotoCameraIcon sx={{ fontSize: size * 0.25 }} />
          </IconButton>
        </>
      )}
    </Box>
  );
};

export default UserAvatar; 