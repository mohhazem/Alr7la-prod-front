import React, { useState, useRef } from 'react';
import {
  Box, TextField, Typography, List, ListItem,
  ListItemAvatar, Avatar, ListItemText, IconButton, Popover
} from '@mui/material';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import FavoriteIcon from '@mui/icons-material/Favorite';
import SendIcon from '@mui/icons-material/Send';
import EmojiEmotionsIcon from '@mui/icons-material/EmojiEmotions';
import userAvatar from '../assets/images/khalid.jpg';
import EmojiPicker from 'emoji-picker-react';
import { useTheme } from '@mui/material/styles';
import { commentService } from '../services/networkService';

function timeAgo(date) {
  const now = new Date();
  const past = new Date(date);
  const seconds = Math.floor((now - past) / 1000);
  const intervals = [
    { label: 'year', seconds: 31536000 },
    { label: 'month', seconds: 2592000 },
    { label: 'week', seconds: 604800 },
    { label: 'day', seconds: 86400 },
    { label: 'hour', seconds: 3600 },
    { label: 'minute', seconds: 60 },
    { label: 'second', seconds: 1 },
  ];
  for (const interval of intervals) {
    const count = Math.floor(seconds / interval.seconds);
    if (count > 0) {
      return `${count} ${interval.label}${count !== 1 ? 's' : ''} ago`;
    }
  }
  return 'just now';
}

function ReplyItem({ reply, onLikeReply, likedReplies, onReplyToReply, replyToReplyId, onReplyTextChange, replyToReplyText, onSubmitReplyToReply, parentUsername }) {
  const [emojiAnchorEl, setEmojiAnchorEl] = useState(null);
  const replyInputRef = useRef(null);

  const handleEmojiClick = (event) => {
    setEmojiAnchorEl(event.currentTarget);
  };

  const handleEmojiClose = () => {
    setEmojiAnchorEl(null);
  };

  // Handle emoji selection for reply
  const onEmojiSelect = (emojiObject) => {
    const emoji = emojiObject.emoji;
    const inputField = replyInputRef.current;
    
    // Insert emoji at cursor position or at the end
    if (inputField) {
      const start = inputField.selectionStart || replyToReplyText.length;
      const end = inputField.selectionEnd || replyToReplyText.length;
      const newText = replyToReplyText.substring(0, start) + emoji + replyToReplyText.substring(end);
      onReplyTextChange(newText);
      
      // Set cursor position after the inserted emoji
      setTimeout(() => {
        inputField.selectionStart = inputField.selectionEnd = start + emoji.length;
        inputField.focus();
      }, 0);
    } else {
      // Fallback if direct insertion isn't possible
      onReplyTextChange(prevText => prevText + emoji);
    }
    
    handleEmojiClose();
  };

  return (
    <Box sx={{ 
      borderLeft: '2px solid #e6f2ff', 
      pl: 2, 
      ml: 5, 
      my: 1, 
      position: 'relative'
    }}>
      <ListItem alignItems="flex-start" sx={{ p: 0, mb: 1 }}>
        <ListItemAvatar sx={{ minWidth: 36 }}>
          <Avatar alt={reply.user} src={reply.avatar} sx={{ width: 28, height: 28 }} />
        </ListItemAvatar>
        <ListItemText
          primary={
            <Box display="flex" justifyContent="space-between" alignItems="center">
              <Box display="flex" alignItems="center">
                <Typography variant="subtitle2" sx={{ fontSize: 13, fontWeight: 600 }}>
                  {reply.user}
                </Typography>
                {parentUsername && (
                  <Typography 
                    variant="caption" 
                    sx={{ 
                      ml: 1, 
                      color: '#65676B', 
                      backgroundColor: '#F0F2F5', 
                      px: 0.7, 
                      py: 0.3, 
                      borderRadius: 1,
                      fontSize: 10
                    }}
                  >
                    Replying to {parentUsername}
                  </Typography>
                )}
              </Box>
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: 10 }}>
                {timeAgo(reply.time)}
              </Typography>
            </Box>
          }
          secondary={
            <Box>
              <Typography sx={{ 
                whiteSpace: 'normal', 
                fontSize: 13, 
                mb: 0.5, 
                mt: 0.5,
                wordWrap: 'break-word',    
                overflowWrap: 'break-word', 
                wordBreak: 'break-word',   
                maxWidth: '100%'           
              }}>
                {reply.text}
              </Typography>
              
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <IconButton
                    size="small"
                    onClick={() => onLikeReply(reply.id)}
                    sx={{
                      padding: "0px",
                      color: likedReplies[reply.id] ? '#d32f2f' : '#65676B',
                      '&:hover': { color: '#d32f2f', background: 'transparent' }
                    }}
                  >
                    {likedReplies[reply.id] ? 
                      <FavoriteIcon sx={{ fontSize: 16 }} /> : 
                      <FavoriteBorderIcon sx={{ fontSize: 16 }} />
                    }
                  </IconButton>
                  <Typography 
                    variant="caption" 
                    color="text.secondary" 
                    sx={{ fontSize: 11, ml: 0.5 }}
                  >
                    {reply.likeCount || 0}
                  </Typography>
                </Box>
                <Typography
                  variant="body2"
                  sx={{
                    ml: 0.5,
                    color: '#65676B',
                    fontWeight: 500,
                    fontSize: 12,
                    cursor: 'pointer',
                    transition: 'color 0.2s',
                    '&:hover': { color: '#1976d2', textDecoration: 'underline' }
                  }}
                  onClick={() => onReplyToReply(reply.id, reply.user)}
                >
                  Reply
                </Typography>
              </Box>
            </Box>
          }
        />
      </ListItem>
      
      {replyToReplyId === reply.id && (
        <Box sx={{ pl: 3, pr: 1, mb: 1.5 }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <TextField
              fullWidth
              size="small"
              autoFocus
              placeholder={`Reply to ${reply.user}...`}
              value={replyToReplyText}
              onChange={e => onReplyTextChange(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  onSubmitReplyToReply(reply.id, reply.user);
                }
              }}
              variant="outlined"
              inputRef={replyInputRef}
              sx={{ 
                backgroundColor: '#f0f2f5',
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: 'transparent',
                  },
                  '&:hover fieldset': {
                    borderColor: 'transparent',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#1976d2',
                    borderWidth: '1px',
                  },
                }
              }}
              InputProps={{ 
                style: { color: '#000', fontSize: 13 },
                sx: { py: 0.5, px: 1 }
              }}
            />
            <IconButton 
              color="warning"
              onClick={handleEmojiClick}
              sx={{ ml: 0.5 }}
            >
              <EmojiEmotionsIcon fontSize="small" />
            </IconButton>
            <IconButton 
              color="primary"
              onClick={() => onSubmitReplyToReply(reply.id, reply.user)}
              disabled={!replyToReplyText.trim()}
              sx={{ ml: 0.5 }}
            >
              <SendIcon fontSize="small" />
            </IconButton>
          </Box>
          
          {/* Emoji Picker Popover */}
          <Popover
            open={Boolean(emojiAnchorEl)}
            anchorEl={emojiAnchorEl}
            onClose={handleEmojiClose}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
          >
            <EmojiPicker 
              onEmojiClick={onEmojiSelect} 
              searchDisabled={false}
              width={280}
              height={350}
            />
          </Popover>
        </Box>
      )}
    </Box>
  );
}

export default function CommentSection({ comments, setComments, postId, onAddComment, onDeleteComment, onUpdateComment, loading, error, hasMore, onLoadMore }) {
  const [comment, setComment] = useState('');
  const [likedComments, setLikedComments] = useState({});
  const [likedReplies, setLikedReplies] = useState({});
  const [replyAnchor, setReplyAnchor] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [replyToReplyId, setReplyToReplyId] = useState(null);
  const [replyToReplyText, setReplyToReplyText] = useState('');
  const [replyingTo, setReplyingTo] = useState('');
  const [expandedReplies, setExpandedReplies] = useState({});
  const [emojiAnchorEl, setEmojiAnchorEl] = useState(null);
  const [replyEmojiAnchorEl, setReplyEmojiAnchorEl] = useState(null);
  const commentInputRef = useRef(null);
  const replyInputRef = useRef(null);
  const theme = useTheme();

  // Always use an array for comments
  const safeComments = Array.isArray(comments) ? comments : [];

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submitComment();
    }
  };

  const submitComment = async () => {
    if (comment.trim() === '') return;
    
    try {
      console.log('Submitting comment for post:', postId);
      console.log('Comment content:', comment.trim());
      
      const response = await commentService.createComment(postId, comment.trim());
      console.log('Comment created successfully:', response);

      if (!response || !response.data) {
        throw new Error('Invalid response from server');
      }

      const newComment = {
        id: response.data.id,
        user: response.data.User?.name || 'You',
        avatar: response.data.User?.profile_picture || userAvatar,
        text: response.data.description || comment.trim(),
        time: response.data.created_at || new Date().toISOString(),
        replies: [],
        likeCount: response.data.likeCount || 0
      };

      // Update local state
      setComments([newComment, ...safeComments]);
      setComment('');

      // Call the parent's onAddComment if provided
      if (onAddComment) {
        onAddComment(newComment);
      }
    } catch (error) {
      console.error('Error creating comment:', error);
      console.error('Error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status
      });
      // You might want to show an error message to the user here
    }
  };

  const toggleLike = (id) => {
    setLikedComments((prev) => ({ ...prev, [id]: !prev[id] }));
    
    // Update like count in the comments
    setComments(safeComments.map(comment => {
      if (comment.id === id) {
        const newLikeCount = (comment.likeCount || 0) + (likedComments[id] ? -1 : 1);
        return {
          ...comment,
          likeCount: Math.max(0, newLikeCount) // Ensure count doesn't go below 0
        };
      }
      return comment;
    }));
  };

  const toggleLikeReply = (id) => {
    setLikedReplies((prev) => ({ ...prev, [id]: !prev[id] }));
    
    // Find which comment contains this reply and update the like count
    setComments(safeComments.map(comment => {
      // Check if this comment has the reply
      const replyIndex = comment.replies.findIndex(reply => reply.id === id);
      
      if (replyIndex >= 0) {
        // This comment contains the reply we want to update
        const updatedReplies = [...comment.replies];
        const reply = updatedReplies[replyIndex];
        
        // If not previously liked, increment; otherwise decrement
        const newLikeCount = (reply.likeCount || 0) + (likedReplies[id] ? -1 : 1);
        
        updatedReplies[replyIndex] = {
          ...reply,
          likeCount: Math.max(0, newLikeCount) // Ensure count doesn't go below 0
        };
        
        return {
          ...comment,
          replies: updatedReplies
        };
      }
      
      return comment;
    }));
  };

  const handleReply = (id) => {
    setReplyAnchor(id === replyAnchor ? null : id);
    setReplyToReplyId(null);
  };

  const handleReplyToReply = (id, username) => {
    setReplyToReplyId(id === replyToReplyId ? null : id);
    setReplyingTo(username);
    setReplyAnchor(null);
  };

  const handleReplyKeyPress = (e, commentId) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submitReply(commentId);
    }
  };

  const toggleReplies = (commentId) => {
    // Simply toggle the expanded state
    setExpandedReplies(prev => ({
      ...prev,
      [commentId]: !prev[commentId]
    }));
  };

  // Handle emoji picker for main comment
  const handleEmojiClick = (event) => {
    setEmojiAnchorEl(event.currentTarget);
  };

  const handleEmojiClose = () => {
    setEmojiAnchorEl(null);
  };

  // Handle emoji selection for main comment
  const onEmojiSelect = (emojiObject) => {
    const emoji = emojiObject.emoji;
    const inputField = commentInputRef.current;
    
    // Insert emoji at cursor position or at the end
    if (inputField) {
      const start = inputField.selectionStart || comment.length;
      const end = inputField.selectionEnd || comment.length;
      const newText = comment.substring(0, start) + emoji + comment.substring(end);
      setComment(newText);
      
      // Set cursor position after the inserted emoji
      setTimeout(() => {
        inputField.selectionStart = inputField.selectionEnd = start + emoji.length;
        inputField.focus();
      }, 0);
    } else {
      // Fallback if direct insertion isn't possible
      setComment(prevText => prevText + emoji);
    }
    
    handleEmojiClose();
  };

  // Handle emoji picker for reply
  const handleReplyEmojiClick = (event) => {
    setReplyEmojiAnchorEl(event.currentTarget);
  };

  const handleReplyEmojiClose = () => {
    setReplyEmojiAnchorEl(null);
  };

  // Handle emoji selection for reply
  const onReplyEmojiSelect = (emojiObject) => {
    const emoji = emojiObject.emoji;
    const inputField = replyInputRef.current;
    
    // Insert emoji at cursor position or at the end
    if (inputField) {
      const start = inputField.selectionStart || replyText.length;
      const end = inputField.selectionEnd || replyText.length;
      const newText = replyText.substring(0, start) + emoji + replyText.substring(end);
      setReplyText(newText);
      
      // Set cursor position after the inserted emoji
      setTimeout(() => {
        inputField.selectionStart = inputField.selectionEnd = start + emoji.length;
        inputField.focus();
      }, 0);
    } else {
      // Fallback if direct insertion isn't possible
      setReplyText(prevText => prevText + emoji);
    }
    
    handleReplyEmojiClose();
  };

  // Flat structure for all replies
  const submitReply = (parentId) => {
    if (replyText.trim() === '') return;
    
    const newReply = {
      id: Date.now(),
      user: 'You',
      avatar: userAvatar,
      text: replyText.trim(),
      time: new Date().toISOString(),
      parentId: parentId,
      parentType: 'comment',
      likeCount: 0
    };
    
    setComments(safeComments =>
      safeComments.map(comment =>
        comment.id === parentId
          ? {
              ...comment,
              replies: [...(comment.replies || []), newReply]
            }
          : comment
      )
    );
    
    // When adding a reply, automatically show it
    setExpandedReplies(prev => ({ ...prev, [parentId]: true }));
    
    setReplyText('');
    setReplyAnchor(null);
  };

  const submitReplyToReply = (parentReplyId, replyingToUsername) => {
    if (replyToReplyText.trim() === '') return;
    
    // Find which comment this reply belongs to
    let parentCommentId = null;
    for (const comment of safeComments) {
      const foundReply = comment.replies.find(reply => reply.id === parentReplyId);
      if (foundReply) {
        parentCommentId = comment.id;
        break;
      }
    }
    
    if (!parentCommentId) return;
    
    const newReply = {
      id: Date.now(),
      user: 'You',
      avatar: userAvatar,
      text: replyToReplyText.trim(),
      time: new Date().toISOString(),
      parentId: parentReplyId,
      parentType: 'reply',
      replyingTo: replyingToUsername,
      likeCount: 0
    };
    
    setComments(safeComments =>
      safeComments.map(comment =>
        comment.id === parentCommentId
          ? {
              ...comment,
              replies: [...comment.replies, newReply]
            }
          : comment
      )
    );
    
    // Show all replies when replying to a reply
    setExpandedReplies(prev => ({ ...prev, [parentCommentId]: true }));
    
    setReplyToReplyText('');
    setReplyToReplyId(null);
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Box sx={{ flexGrow: 1, overflowY: 'auto', mb: 2, backgroundColor: theme.palette.mode === 'dark' ? '#242526' : '#fff' }}>
        {safeComments.length === 0 ? (
          <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic', textAlign: 'center' }}>
            No comments yet. Be the first to comment!
          </Typography>
        ) : (
          <List dense>
            {safeComments.map(({ id, user, avatar, text, time, replies, likeCount = 0 }) => {
              const shouldShowReplies = expandedReplies[id] || false;
              
              return (
                <Box
                  key={id}
                  component="div"
                  sx={{
                    borderBottom: '1px solid #eee',
                    pb: 2,
                    mb: 1,
                  }}
                >
                  <ListItem alignItems="flex-start" sx={{ alignItems: 'flex-start', p: '4px 0' }}>
                    <ListItemAvatar sx={{ minWidth: 40 }}>
                      <Avatar alt={user} src={avatar} sx={{ width: 32, height: 32 }} />
                    </ListItemAvatar>
                    <ListItemText
                      primary={
                        <Box display="flex" alignItems="center">
                          <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{user}</Typography>
                          <Typography variant="caption" color="text.secondary" sx={{ fontSize: 13, ml: 2 }}>
                            {timeAgo(time)}
                          </Typography>
                        </Box>
                      }
                      secondary={
                        <Box>
                          <Typography sx={{ 
                            whiteSpace: 'normal', 
                            mb: 0.5,
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word',
                            wordBreak: 'break-word',
                            maxWidth: '100%'
                          }}>{text}</Typography>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              <IconButton
                                size="small"
                                onClick={() => toggleLike(id)}
                                sx={{
                                  padding: "2px",
                                  color: likedComments[id] ? '#d32f2f' : '#65676B',
                                  '&:hover': { color: '#d32f2f', background: 'transparent' }
                                }}
                              >
                                {likedComments[id] ? <FavoriteIcon fontSize="small" /> : <FavoriteBorderIcon fontSize="small" />}
                              </IconButton>
                              <Typography 
                                variant="caption" 
                                color="text.secondary" 
                                sx={{ fontSize: 12, ml: 0.5 }}
                              >
                                {likeCount}
                              </Typography>
                            </Box>
                            <Typography
                              variant="body2"
                              sx={{
                                ml: 0.5,
                                color: '#65676B',
                                fontWeight: 500,
                                fontSize: 15,
                                cursor: 'pointer',
                                transition: 'color 0.2s',
                                '&:hover': { color: '#1976d2', textDecoration: 'underline' }
                              }}
                              onClick={() => handleReply(id)}
                            >
                              Reply
                            </Typography>
                          </Box>
                          
                          {replyAnchor === id && (
                            <Box sx={{ pl: 5, pr: 2, mt: 1 }}>
                              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                <TextField
                                  fullWidth
                                  size="small"
                                  autoFocus
                                  placeholder="Write a reply..."
                                  value={replyText}
                                  onChange={e => setReplyText(e.target.value)}
                                  onKeyDown={e => handleReplyKeyPress(e, id)}
                                  variant="outlined"
                                  inputRef={replyInputRef}
                                  sx={{ backgroundColor: '#f8f8fa' }}
                                  InputProps={{ style: { color: theme.palette.mode === 'dark' ? '#fff' : '#000', fontSize: 14 } }}
                                />
                                <IconButton 
                                  color="warning"
                                  onClick={handleReplyEmojiClick}
                                  sx={{ ml: 0.5 }}
                                >
                                  <EmojiEmotionsIcon fontSize="small" />
                                </IconButton>
                                <IconButton 
                                  color="primary"
                                  onClick={() => submitReply(id)}
                                  disabled={!replyText.trim()}
                                  sx={{ ml: 0.5 }}
                                >
                                  <SendIcon fontSize="small" />
                                </IconButton>
                              </Box>
                              
                              {/* Emoji Picker Popover for Reply */}
                              <Popover
                                open={Boolean(replyEmojiAnchorEl)}
                                anchorEl={replyEmojiAnchorEl}
                                onClose={handleReplyEmojiClose}
                                anchorOrigin={{
                                  vertical: 'top',
                                  horizontal: 'center',
                                }}
                                transformOrigin={{
                                  vertical: 'bottom',
                                  horizontal: 'center',
                                }}
                              >
                                <EmojiPicker 
                                  onEmojiClick={onReplyEmojiSelect} 
                                  searchDisabled={false}
                                  width={280}
                                  height={350}
                                />
                              </Popover>
                            </Box>
                          )}
                          
                          {/* Show replies or view replies button */}
                          {(replies || []).length > 0 && (
                            <>
                              {/* Visible replies when expanded */}
                              {shouldShowReplies && (
                                <Box sx={{ mt: 1.5 }}>
                                  {(replies || []).map(reply => (
                                    <ReplyItem
                                      key={reply.id}
                                      reply={reply}
                                      onLikeReply={toggleLikeReply}
                                      likedReplies={likedReplies}
                                      onReplyToReply={handleReplyToReply}
                                      replyToReplyId={replyToReplyId}
                                      onReplyTextChange={setReplyToReplyText}
                                      replyToReplyText={replyToReplyText}
                                      onSubmitReplyToReply={submitReplyToReply}
                                      parentUsername={reply.replyingTo}
                                    />
                                  ))}
                                </Box>
                              )}
                              
                              {/* Toggle button */}
                              <Typography
                                variant="body2"
                                onClick={() => toggleReplies(id)}
                                sx={{ 
                                  fontSize: 13,
                                  fontWeight: 500,
                                  color: '#65676B',
                                  ml: 5,
                                  mt: 1,
                                  cursor: 'pointer',
                                  '&:hover': { 
                                    textDecoration: 'underline',
                                    color: '#1976d2' 
                                  },
                                  display: 'inline-block'
                                }}
                              >
                                {!shouldShowReplies 
                                  ? `View ${(replies || []).length === 1 ? '1 reply' : `all ${(replies || []).length} replies`}` 
                                  : ((replies || []).length === 1 ? 'Hide reply' : 'Hide replies')}
                              </Typography>
                            </>
                          )}
                        </Box>
                      }
                    />
                  </ListItem>
                </Box>
              );
            })}
          </List>
        )}
      </Box>
      
      <Box sx={{ display: 'flex', alignItems: 'flex-start', mt: 'auto' }}>
        <Avatar 
          src={userAvatar} 
          alt="Your Avatar" 
          sx={{ 
            width: 32, 
            height: 32, 
            mr: 1.5,
            mt: 0.5
          }} 
        />
        <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
          <TextField
            fullWidth
            multiline
            minRows={1}
            maxRows={3}
            placeholder="Write a comment..."
            variant="outlined"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            onKeyDown={handleKeyPress}
            inputRef={commentInputRef}
            sx={{ 
              backgroundColor: '#f5f5f7',
              borderRadius: 1,
              '& .MuiOutlinedInput-root': {
                p: '8px 10px',
              }
            }}
            InputProps={{ style: { color: theme.palette.mode === 'dark' ? '#fff' : '#000' } }}
          />
          <IconButton 
            color="warning"
            onClick={handleEmojiClick}
            sx={{ ml: 1 }}
            aria-label="Add emoji"
          >
            <EmojiEmotionsIcon />
          </IconButton>
          <IconButton 
            color="primary"
            onClick={submitComment}
            disabled={!comment.trim()}
            sx={{ ml: 1 }}
            aria-label="Post comment"
          >
            <SendIcon />
          </IconButton>
        </Box>
      </Box>
      
      {/* Emoji Picker Popover for Main Comment */}
      <Popover
        open={Boolean(emojiAnchorEl)}
        anchorEl={emojiAnchorEl}
        onClose={handleEmojiClose}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
      >
        <EmojiPicker 
          onEmojiClick={onEmojiSelect} 
          searchDisabled={false}
          width={280}
          height={350}
        />
      </Popover>
    </Box>
  );
}