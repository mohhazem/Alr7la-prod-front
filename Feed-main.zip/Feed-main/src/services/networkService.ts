import axios, { AxiosInstance } from 'axios';
import authInterceptor from './authInterceptor';
import { requestLogger, responseLogger, errorLogger } from './loggingInterceptor';

const BASE_URL = 'https://alr7la-backend-production.up.railway.app';

const api: AxiosInstance = axios.create({
    baseURL: BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Add interceptors
api.interceptors.request.use(authInterceptor);
api.interceptors.request.use(requestLogger);
api.interceptors.response.use(responseLogger, errorLogger);

// Auth Services
export const authService = {
    login: (email: string, password: string) =>
        api.post('/auth/login', { email, password }),

    register: (userData: any) =>
        api.post('/auth', userData),

    refreshToken: () =>
        api.post('/auth/refreshToken'),

    sendOTP: (email: string) =>
        api.post(`/auth/send-otp/${email}`),

    verifyOTP: (email: string, otp: string, newPassword: string) =>
        api.post('/auth/verify-otp', { email, otp, newPassword }),
};

// Comments Services
export const commentService = {
    createComment: (postId: string, description: string) => 
        api.post(`/comments/posts/${postId}`, { description }),
    
    getComments: (postId: string, page?: number, limit?: number) => 
        api.get(`/comments/posts/${postId}`, { params: { page, limit } }),
    
    updateComment: (commentId: string, description: string) => 
        api.put(`/comments/${commentId}`, { description }),
    
    deleteComment: (commentId: string) => 
        api.delete(`/comments/${commentId}`),
};

// Posts Services
export const postService = {
    createPost: (formData: FormData) =>
        api.post('/posts/create-post', formData),

    updatePost: (postId: string, content: string, visibility: string) =>
        api.put(`/posts/update-post/${postId}`, { content, visibility }),

    deletePost: (postId: string) =>
        api.delete(`/posts/delete-post/${postId}`),

    toggleLike: (postId: string) =>
        api.post(`/posts/${postId}/like`),

    getUserPosts: (userId: string) =>
        api.get(`/posts/user/${userId}`),

    getSavedPosts: () =>
        api.get('/posts/saved-posts'),

    toggleSave: (postId: string) =>
        api.post(`/posts/toggle-save/${postId}`),
};

// Friends Services
export const friendService = {
    getFriends: (userId: string) =>
        api.get(`/friends/get-friends/${userId}`),

    getFriendRequests: () =>
        api.get('/friends/friendRequests'),

    updateFriendRequest: (user_id: Int16Array, status: 'accepted' | 'rejected') =>
        api.put('/friends/friendRequests', { user_id, status }),
};

// Profile Services
export const profileService = {
    getProfile: (userId: string) =>
        api.get(`/profile/${userId}`),

    updateProfile: (profileData: any) =>
        api.put('/profile/edit-profile', profileData),
};

// Trip Services
export const tripService = {
    getTravelInfo: (travelData: any) =>
        api.post('/trip/travel-info', travelData),

    createTrip: (tripData: any) =>
        api.post('/trip/', tripData),

    getTrip: (tripId: number) =>
        api.get(`/trip/${tripId}`),

    updateTrip: (tripId: number, tripData: any) =>
        api.put(`/trip/trips/${tripId}`, tripData),
    deleteTrip:(tripId:number) =>
        api.delete(`/trip/user/${tripId}`),
};

// Feed Services
export const feedService = {
    getFeed: () =>
        api.get('/feed'),

    recordInteraction: (postId: string, interactionType: string) =>
        api.post('/feed/interactions', { postId, interactionType }),
};

// Places Services
export const placeService = {
    createPlace: (placeData: any) =>
        api.post('/places', placeData),

    getAllPlaces: () =>
        api.get('/places'),

    getPlacesByCountry: (country: string) =>
        api.get(`/places/country/${country}`),

    getPlace: (id: string) =>
        api.get(`/places/${id}`),

    updatePlace: (id: string, placeData: any) =>
        api.put(`/places/${id}`, placeData),

    deletePlace: (id: string) =>
        api.delete(`/places/${id}`),
};

// Visited Countries Services
export const visitedCountryService = {
    getVisitedCountries: (userId: string) =>
        api.get(`/visited-countries/${userId}`),

    addVisitedCountry: (visitData: any) =>
        api.post('/visited-countries', visitData),

    deleteVisitedCountry: (userId: string, countryId: string) =>
        api.delete(`/visited-countries/${userId}/${countryId}`),
};

// Weather Services
export const weatherService = {
    getWeather: (city: string) =>
        api.get(`/weather/${city}`),
};

// Upload Services
export const uploadService = {
    uploadProfilePicture: (file: File) => {
        const formData = new FormData();
        formData.append('file', file);
        return api.post('/upload/profilePicture', formData);
    },

    uploadWallpaper: (file: File) => {
        const formData = new FormData();
        formData.append('file', file);
        return api.post('/upload/wallpaper', formData);
    },
};

// Visa Services
export const visaService = {
    getVisaRequirements: (source: string, destination: string) =>
        api.get(`/visa/${source}/${destination}`),
};
