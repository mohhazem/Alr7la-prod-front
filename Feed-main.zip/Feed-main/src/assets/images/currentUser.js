// src/assets/currentUser.js

import avatarKhalid from './hazem.jpg'; // Use the real image you want

const currentUser = {
  name: 'Mohamed Hazem',    // <-- put the actual user's name here
  avatar: avatarKhalid     // <-- and the imported image variable here
};

export default currentUser;