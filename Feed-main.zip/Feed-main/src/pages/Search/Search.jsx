import axios from 'axios';
import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, 
  TextField, 
  InputAdornment, 
  Avatar, 
  Typography, 
  IconButton,
  Fade,
  CircularProgress,
  useTheme,
  styled,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  alpha,
  Button
} from '@mui/material';
import { 
  Search as SearchIcon, 
  Person, 
  TravelExplore,
  Clear,
  History,
  AccessTime,
  Check,
  Groups,
  PersonAdd
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import localStorageService from '../../services/localStorageService';

// Styled search input
const SearchInput = styled(TextField)(({ theme }) => ({
  '& .MuiInputBase-root': {
    borderRadius: 50,
    backgroundColor: theme.palette.mode === 'dark' 
      ? alpha(theme.palette.common.white, 0.08)
      : alpha(theme.palette.common.black, 0.04),
    transition: theme.transitions.create([
      'background-color',
      'box-shadow',
    ]),
    '&:hover': {
      backgroundColor: theme.palette.mode === 'dark' 
        ? alpha(theme.palette.common.white, 0.12)
        : alpha(theme.palette.common.black, 0.06),
    },
    '&.Mui-focused': {
      backgroundColor: theme.palette.mode === 'dark' 
        ? alpha(theme.palette.common.white, 0.12)
        : alpha(theme.palette.common.black, 0.06),
      boxShadow: `0 0 0 1px ${theme.palette.primary.main}`,
    },
  },
  '& .MuiOutlinedInput-notchedOutline': {
    border: 'none',
  },
}));

function Search() {
  const theme = useTheme();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedResultIndex, setSelectedResultIndex] = useState(-1);
  const searchInputRef = useRef(null);
  const resultsRef = useRef(null);
  
  // Get saved searches from localStorage or use defaults
  const getSavedSearches = () => {
    const savedSearches = localStorage.getItem('recentSearches');
    return savedSearches ? JSON.parse(savedSearches) : ['Omar Ahmed', 'Ahmed Abdelmoneim', 'Mohamed Ramdan'];
  };
  
  const [recentSearches, setRecentSearches] = useState(getSavedSearches);
  
  // Mock data with improved structure - focused only on people
  const mockUsers = [
    { 
      id: 1, 
      name: 'Omar Ahmed', 
      username: '@omar', 
      avatar: './hany.jpg', 
      followers: 1240, 
      following: 345, 
      mutualFriends: 3,
      bio: 'Software Developer | React Enthusiast | Photography Lover',
      location: 'Cairo, Egypt'
    },
    { 
      id: 2, 
      name: 'Ahmed Abdelmoneim', 
      username: '@ahmed', 
      avatar: './hazem.jpg', 
      followers: 890, 
      following: 211, 
      mutualFriends: 5,
      bio: 'UX Designer | Coffee Addict',
      location: 'Alexandria, Egypt'
    },
    { 
      id: 3, 
      name: 'Mohamed Ramdan', 
      username: '@mohamed', 
      avatar: './jinzo.jpg', 
      followers: 2300, 
      following: 178, 
      mutualFriends: 1,
      bio: 'Frontend Developer | UI/UX Designer',
      location: 'Giza, Egypt'
    },
    { 
      id: 4, 
      name: 'Ahmed Moghazy', 
      username: '@moghazy', 
      avatar: './hazem.jpg', 
      followers: 756, 
      following: 290,
      bio: 'Backend Developer | Node.js Expert',
      location: 'Cairo, Egypt'
    },
    { 
      id: 5, 
      name: 'Mostafa Islam', 
      username: '@mostafa', 
      avatar: './postKhalid.jpg', 
      followers: 1820, 
      following: 432, 
      mutualFriends: 7,
      bio: 'Full Stack Developer | Tech Enthusiast',
      location: 'Mansoura, Egypt'
    },
    { 
      id: 6, 
      name: 'Khalid Osama', 
      username: '@khalid', 
      avatar: './khalid.jpg', 
      followers: 3450, 
      following: 501, 
      verified: true,
      bio: 'Senior Software Engineer | React & Node.js',
      location: 'Cairo, Egypt'
    },
  ];

  // Support keyboard navigation and shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Arrow navigation for search results
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        
        if (searchResults.length === 0) return;
        
        if (e.key === 'ArrowDown') {
          setSelectedResultIndex(prev => 
            prev < searchResults.length - 1 ? prev + 1 : 0
          );
        } else {
          setSelectedResultIndex(prev => 
            prev > 0 ? prev - 1 : searchResults.length - 1
          );
        }
        
        // Scroll the result into view if needed
        if (resultsRef.current) {
          const selectedElement = resultsRef.current.querySelector(`[data-selected="true"]`);
          if (selectedElement) {
            selectedElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }
        }
      }
      
      // Enter selects the highlighted result
      if (e.key === 'Enter' && selectedResultIndex >= 0) {
        handleProfileClick(searchResults[selectedResultIndex].id);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [searchResults, selectedResultIndex]);

  // Auto focus the search input when component mounts
  useEffect(() => {
    const timer = setTimeout(() => {
      searchInputRef.current?.focus();
    }, 300);
    return () => clearTimeout(timer);
  }, []);

useEffect(() => {
  const cancelTokenSource = axios.CancelToken.source();
  const token = localStorageService.getItem('token'); 
  if (searchQuery.trim() !== '') {
    setIsLoading(true);
    setSelectedResultIndex(-1);
    console.log("search query is: ", searchQuery.trim())
    const timer = setTimeout(async () => {
      try {
        const response = await axios.get(
          `https://alr7la-backend-production.up.railway.app/users/users/`,
          {
            params: { name: searchQuery },
            cancelToken: cancelTokenSource.token,
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            }
          }
        );
        
        console.log('Search response data:', response.data);
        console.log('Users data structure:', response.data.users ? response.data.users[0] : 'No users found');
        setSearchResults(response.data.users);

      } catch (error) {
        if (!axios.isCancel(error)) {
          console.error('Search failed:', error);
          setSearchResults([]);
          // Handle unauthorized (401) errors:
          if (error.response?.status === 401) {
            // Redirect to login or refresh token
          }
        }
      } finally {
        setIsLoading(false);
      }
    }, 400);

    return () => {
      clearTimeout(timer);
      cancelTokenSource.cancel('Operation canceled due to new request');
    };
  } else {
    setSearchResults([]);
  }
}, [searchQuery]);


  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    searchInputRef.current?.focus();
  };

  const handleRecentSearch = (term) => {
    setSearchQuery(term);
    
    // Move this search to the top of recent searches
    if (recentSearches.includes(term)) {
      const updatedSearches = [
        term, 
        ...recentSearches.filter(s => s !== term)
      ];
      setRecentSearches(updatedSearches);
      localStorage.setItem('recentSearches', JSON.stringify(updatedSearches));
    }
  };
  
  const saveToRecentSearches = (term) => {
    if (!term.trim()) return;
    
    // Add to recent searches if not already present, or move to top if it is
    const updatedSearches = [
      term, 
      ...recentSearches.filter(s => s !== term)
    ].slice(0, 8); // Keep only latest 8
    
    setRecentSearches(updatedSearches);
    localStorage.setItem('recentSearches', JSON.stringify(updatedSearches));
  };

  const handleSubmitSearch = (e) => {
    if (e.key === 'Enter' && searchQuery.trim() !== '') {
      // If we have results, navigate to the first result
      if (searchResults.length > 0) {
        handleProfileClick(searchResults[0].id);
      }
    }
  };

  const handleProfileClick = (userId) => {
    // Find the user and save their full name to recent searches
    const user = mockUsers.find(user => user.id === userId);
    if (user) {
      saveToRecentSearches(user.name);
    }
    
    navigate(`/profile/${userId}`);
  };

  const handleRemoveRecentSearch = (e, term) => {
    e.stopPropagation();
    
    // Remove this term from recent searches
    const updatedSearches = recentSearches.filter(s => s !== term);
    setRecentSearches(updatedSearches);
    localStorage.setItem('recentSearches', JSON.stringify(updatedSearches));
  };

  const handleClearAllRecentSearches = () => {
    setRecentSearches([]);
    localStorage.setItem('recentSearches', JSON.stringify([]));
  };

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ 
        position: 'sticky', 
        top: 0, 
        zIndex: 2,
        bgcolor: 'background.paper',
        borderBottom: 1, 
        borderColor: 'divider',
        px: 3,
        py: 2
      }}>
        <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
          <Box display="flex" alignItems="center">
            <Person sx={{ mr: 1.5, color: 'primary.main', fontSize: 28 }} />
            <Typography variant="h5" sx={{ fontWeight: 600 }}>Search</Typography>
          </Box>
        </Box>
        
        <SearchInput
          id="search-input"
          fullWidth
          size="medium"
          placeholder="Search for people by name or username..."
          value={searchQuery}
          onChange={handleSearch}
          onKeyDown={handleSubmitSearch}
          autoComplete="off"
          inputRef={searchInputRef}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
            endAdornment: searchQuery && (
              <InputAdornment position="end">
                <IconButton onClick={handleClearSearch} edge="end" size="small">
                  <Clear />
                </IconButton>
              </InputAdornment>
            )
          }}
        />
      </Box>
      
      <Box sx={{ 
        p: 3, 
        pt: 2,
        overflowY: 'auto',
        flex: 1,
        bgcolor: theme.palette.mode === 'dark' ? '#242526' : 'transparent'
      }}>
        {!searchQuery ? (
          <Box>
            <Box display="flex" alignItems="center" justifyContent="space-between" mb={1.5}>
              <Box display="flex" alignItems="center">
                <AccessTime fontSize="small" sx={{ color: 'text.secondary', mr: 1 }} />
                <Typography variant="subtitle2">Recent Searches</Typography>
              </Box>
              {recentSearches.length > 0 && (
                <Button 
                  size="small" 
                  onClick={handleClearAllRecentSearches}
                  sx={{ 
                    textTransform: 'none',
                    color: 'text.secondary',
                    '&:hover': {
                      backgroundColor: 'action.hover',
                    }
                  }}
                >
                  Clear all
                </Button>
              )}
            </Box>
            {recentSearches.length > 0 ? (
              <List disablePadding sx={{ '& .MuiListItem-root': { px: 1 } }}>
                {recentSearches.map((term, index) => (
                  <ListItem 
                    key={index} 
                    button 
                    onClick={() => handleRecentSearch(term)}
                    sx={{ 
                      borderRadius: 1,
                      mb: 0.5,
                      transition: 'all 0.2s',
                      '&:hover': {
                        backgroundColor: alpha(theme.palette.primary.main, 0.05),
                      }
                    }}
                  >
                    <ListItemAvatar sx={{ minWidth: 40 }}>
                      <Avatar 
                        sx={{ 
                          width: 32, 
                          height: 32, 
                          bgcolor: alpha(theme.palette.primary.main, 0.1),
                          color: 'primary.main'
                        }}
                      >
                        <History fontSize="small" />
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText 
                      primary={term} 
                      sx={{ m: 0 }}
                    />
                    <IconButton 
                      size="small" 
                      onClick={(e) => handleRemoveRecentSearch(e, term)}
                      sx={{
                        opacity: 0.6,
                        '&:hover': {
                          opacity: 1,
                          backgroundColor: alpha(theme.palette.error.main, 0.1),
                        }
                      }}
                    >
                      <Clear fontSize="small" />
                    </IconButton>
                  </ListItem>
                ))}
              </List>
            ) : (
              <Box 
                sx={{ 
                  display: 'flex', 
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  p: 4,
                  height: 200,
                  color: 'text.secondary'
                }}
              >
                <History sx={{ fontSize: 40, opacity: 0.3, mb: 1 }} />
                <Typography variant="body2" color="inherit">
                  No recent searches
                </Typography>
              </Box>
            )}
          </Box>
        ) : isLoading ? (
          <Box sx={{ 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center', 
            p: 5,
            height: 200
          }}>
            <CircularProgress size={36} />
          </Box>
        ) : searchResults.length > 0 ? (
          <Fade in>
            <List disablePadding ref={resultsRef}>
              {searchResults.map((user, index) => (
                <ListItem 
                  key={user.id} 
                  button 
                  divider 
                  onClick={() => handleProfileClick(user.id)}
                  alignItems="flex-start"
                  sx={{ 
                    py: 2,
                    px: 1.5,
                    borderRadius: 1,
                    mb: 0.5,
                    backgroundColor: selectedResultIndex === index ? 
                      alpha(theme.palette.primary.main, 0.08) : 'transparent',
                    '&:hover': {
                      backgroundColor: alpha(theme.palette.primary.main, 0.05)
                    }
                  }}
                  data-selected={selectedResultIndex === index}
                >
                  <ListItemAvatar>
                    <Avatar 
                      src={user.avatar} 
                      alt={user.name} 
                      sx={{ 
                        width: 48, 
                        height: 48,
                        border: user.verified ? `2px solid ${theme.palette.primary.main}` : 'none'
                      }}
                    />
                  </ListItemAvatar>
                  <ListItemText 
                    primary={
                      <Box component="span" sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                          {user.name}
                        </Typography>
                        {user.verified && (
                          <Check 
                            sx={{ 
                              ml: 0.5, 
                              color: 'primary.main', 
                              fontSize: 16,
                              backgroundColor: alpha(theme.palette.primary.main, 0.1),
                              borderRadius: '50%',
                              p: 0.1
                            }} 
                          />
                        )}
                      </Box>
                    }
                    secondary={
                      <Box>
                        <Typography variant="body2" color="text.secondary">
                          {user.username}
                        </Typography>
                        
                        {user.bio && (
                          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5, fontSize: '0.85rem' }}>
                            {user.bio}
                          </Typography>
                        )}
                        
                        <Box sx={{ 
                          display: 'flex', 
                          flexWrap: 'wrap',
                          alignItems: 'center', 
                          mt: 0.75, 
                          gap: 1.5,
                          fontSize: '0.75rem',
                          color: 'text.secondary'
                        }}>
                          {user.location && (
                            <Typography variant="caption" color="text.secondary">
                              {user.location}
                            </Typography>
                          )}
                          
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Typography variant="caption" component="span" fontWeight="bold" color="text.primary">
                              {(user.followers || 0).toLocaleString()}
                            </Typography>
                            <Typography variant="caption" component="span" sx={{ ml: 0.5 }}>
                              followers
                            </Typography>
                          </Box>
                          
                          {user.mutualFriends > 0 && (
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              <Groups fontSize="small" sx={{ fontSize: 14, mr: 0.5, color: 'primary.main' }} />
                              <Typography variant="caption">
                                {user.mutualFriends} mutual connection{user.mutualFriends !== 1 && 's'}
                              </Typography>
                            </Box>
                          )}
                        </Box>
                      </Box>
                    }
                  />
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<PersonAdd />}
                    sx={{ 
                      ml: 2, 
                      mt: 1.5, 
                      minWidth: 100, 
                      borderRadius: 6,
                      textTransform: 'none',
                      '&:hover': {
                        backgroundColor: alpha(theme.palette.primary.main, 0.05)
                      }
                    }}
                    onClick={(e) => {
                      e.stopPropagation(); // Prevent navigating to profile
                      // Add friend logic here
                    }}
                  >
                    Add
                  </Button>
                </ListItem>
              ))}
            </List>
          </Fade>
        ) : (
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            p: 4,
            height: '60%',
            minHeight: 200
          }}>
            <TravelExplore sx={{ fontSize: 60, color: 'text.secondary', opacity: 0.4, mb: 2 }} />
            <Typography variant="h6" gutterBottom>No people found</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', maxWidth: 300, mb: 2 }}>
              We couldn't find anyone matching "{searchQuery}".
              Try different keywords or check spelling.
            </Typography>
            <Button 
              variant="outlined" 
              size="small"
              onClick={handleClearSearch}
              startIcon={<Clear />}
              sx={{ 
                borderRadius: 6,
                textTransform: 'none',
                px: 2
              }}
            >
              Clear search
            </Button>
          </Box>
        )}
      </Box>
    </Box>
  );
}

export default Search;