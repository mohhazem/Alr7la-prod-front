import React from 'react';
import { Box, Container, useTheme } from '@mui/material';
import Search from './Search';
import ResponsiveAppBar from '../../components/ResponsiveAppBar';
import LeftSider from '../../components/LeftSider';
import Sidebar from '../../components/SideBar';

function SearchPage() {
  const theme = useTheme();
  const isDarkMode = theme.palette.mode === 'dark';

  return (
    <>
      <ResponsiveAppBar />
      <Box sx={{ 
        display: 'flex',
        minHeight: '100vh',
        bgcolor: isDarkMode ? '#18191a' : 'background.default',
        pt: 12 // Increased padding top to move content down
      }}>
        {/* Left Sidebar */}
        <LeftSider>
          <Sidebar page="search" />
        </LeftSider>

        {/* Main Content */}
        <Box sx={{ 
          flex: 1,
          display: 'flex',
          justifyContent: 'flex-start',
          pl: { md: 8, lg: 12 },
          pr: 3
        }}>
          <Container maxWidth="lg" sx={{ 
            height: 'calc(100vh - 140px)', // Adjusted height to account for increased top padding
            maxWidth: '800px !important'
          }}>
            <Box sx={{ 
              bgcolor: isDarkMode ? '#242526' : 'background.paper',
              borderRadius: 2,
              boxShadow: isDarkMode 
                ? '0 4px 20px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.1)'
                : '0 4px 20px rgba(0, 0, 0, 0.1)',
              overflow: 'hidden',
              height: '100%',
              border: isDarkMode ? '1px solid rgba(255, 255, 255, 0.1)' : 'none',
              backdropFilter: isDarkMode ? 'blur(10px)' : 'none'
            }}>
              <Search />
            </Box>
          </Container>
        </Box>
      </Box>
    </>
  );
}

export default SearchPage; 