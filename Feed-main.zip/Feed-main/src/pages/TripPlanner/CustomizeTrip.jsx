import React, { useState, useEffect } from 'react';
import { CalendarDays, MapPin, DollarSign, Zap, Globe, Search, PlaneTakeoff, 
         Heart, Sparkles, ArrowRight, Loader, Flag, RefreshCw } from 'lucide-react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { tripService } from '../../services/networkService';

const tripPreferences = [
  "Adventure", "Art", "Café", "Children Activity", "Historic Landmark",
  "Hotel", "Museum", "Park", "Religious Landmark", "Restaurant",
  "Shop", "Sightseeing", "Sports Activity", "Theater", "Tourist Office", "Water Activity"
];

const styles = ["budget", "moderate", "luxury"];
const paces = ["slow-pace", "moderate", "fast-pace"];

// Fallback data in case API fails
const fallbackDestinations = [
  { country: "Egypt", code: "EG", cities: ["Cairo", "Alexandria", "Luxor", "Aswan"] },
  { country: "Switzerland", code: "CH", cities: ["Zurich", "Geneva", "Bern", "Basel"] },
  { country: "Greece", code: "GR", cities: ["Athens", "Thessaloniki", "Patras", "Heraklion"] },
  { country: "Turkey", code: "TR", cities: ["Istanbul", "Ankara", "Izmir", "Antalya"] },
  { country: "France", code: "FR", cities: ["Paris", "Nice", "Lyon", "Marseille", "Bordeaux"] },
  { country: "Italy", code: "IT", cities: ["Rome", "Milan", "Venice", "Florence", "Naples"] },
  { country: "Japan", code: "JP", cities: ["Tokyo", "Osaka", "Kyoto", "Sapporo", "Hiroshima"] },
  { country: "Brazil", code: "BR", cities: ["Rio de Janeiro", "São Paulo", "Brasília", "Salvador"] },
  { country: "United States", code: "US", cities: ["New York", "Los Angeles", "Chicago", "Miami", "San Francisco"] },
];

const TripPlannerForm = () => {
  const navigate = useNavigate();
  
  // Form state
  const [formData, setFormData] = useState({
    sourceCountry: "",
    sourceCity: "",
    destinationCountry: "",
    destinationCity: "",
    startDate: "",
    endDate: "",
    days: 0,
    style: "moderate",
    pace: "moderate",
    tripPreferences: []
  });

  // UI states
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("locations");
  
  // API data states
  const [countries, setCountries] = useState([]);
  const [sourceCities, setSourceCities] = useState([]);
  const [destinationCities, setDestinationCities] = useState([]);
  
  // Loading states
  const [loading, setLoading] = useState({
    countries: false,
    sourceCities: false,
    destinationCities: false
  });

  // Fetch countries on component mount
  useEffect(() => {
    const fetchCountries = async () => {
      setLoading(prev => ({ ...prev, countries: true }));
      try {
        // Using the REST Countries API
        const response = await axios.get('https://restcountries.com/v3.1/all?fields=name,cca2,flags');
        const sortedCountries = response.data
          .map(country => ({
            name: country.name.common,
            code: country.cca2,
            flag: country.flags.svg
          }))
          .sort((a, b) => a.name.localeCompare(b.name));
        
        setCountries(sortedCountries);
      } catch (error) {
        console.error("Failed to fetch countries:", error);
        // Fallback to static data if API fails
        const staticCountries = fallbackDestinations.map(dest => ({
          name: dest.country,
          code: dest.code,
          flag: null
        }));
        setCountries(staticCountries);
      } finally {
        setLoading(prev => ({ ...prev, countries: false }));
      }
    };

    fetchCountries();
  }, []);

  // Fetch cities when countries are selected
  useEffect(() => {
    const fetchCities = async (countryCode, type) => {
      if (!countryCode) return;
      
      setLoading(prev => ({ 
        ...prev, 
        [type === 'source' ? 'sourceCities' : 'destinationCities']: true 
      }));
      
      try {
        // In a production app, you would use a real cities API
        // Simulating API response with fallback data
        const fallbackCountry = fallbackDestinations.find(dest => 
          dest.code === countryCode.toUpperCase()
        );
        
        // Add some delay to simulate network request
        await new Promise(resolve => setTimeout(resolve, 800));
        
        const cityList = fallbackCountry?.cities || 
          ["Capital City", "Major City 1", "Major City 2", "Tourist City", "Business Hub"];
        
        if (type === 'source') {
          setSourceCities(cityList);
        } else {
          setDestinationCities(cityList);
        }
      } catch (error) {
        console.error(`Failed to fetch ${type} cities:`, error);
        // Set some default cities as fallback
        const defaultCities = ["Capital City", "Major City", "Tourist Destination"];
        if (type === 'source') {
          setSourceCities(defaultCities);
        } else {
          setDestinationCities(defaultCities);
        }
      } finally {
        setLoading(prev => ({ 
          ...prev, 
          [type === 'source' ? 'sourceCities' : 'destinationCities']: false 
        }));
      }
    };

    if (formData.sourceCountry) {
      fetchCities(formData.sourceCountry, 'source');
    }
    
    if (formData.destinationCountry) {
      fetchCities(formData.destinationCountry, 'destination');
    }
  }, [formData.sourceCountry, formData.destinationCountry]);

  const calculateDays = (start, end) => {
    if (!start || !end) return 0;
    const startDate = new Date(start);
    const endDate = new Date(end);
    const diffTime = Math.abs(endDate - startDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      
      // Auto-calculate days when dates change
      if (field === 'startDate' || field === 'endDate') {
        updated.days = calculateDays(
          field === 'startDate' ? value : prev.startDate,
          field === 'endDate' ? value : prev.endDate
        );
      }
      
      // Clear destination city when country changes
      if (field === 'destinationCountry') {
        updated.destinationCity = "";
      }
      
      // Clear source city when source country changes
      if (field === 'sourceCountry') {
        updated.sourceCity = "";
      }
      
      return updated;
    });
    
    // Clear field-specific errors
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const togglePreference = (preference) => {
    setFormData(prev => ({
      ...prev,
      tripPreferences: prev.tripPreferences.includes(preference)
        ? prev.tripPreferences.filter(p => p !== preference)
        : [...prev.tripPreferences, preference]
    }));
  };

  const validateLocationsTab = () => {
    const newErrors = {};
    
    if (!formData.sourceCountry) newErrors.sourceCountry = "Source country is required";
    if (!formData.sourceCity) newErrors.sourceCity = "Source city is required";
    if (!formData.destinationCountry) newErrors.destinationCountry = "Destination country is required";
    if (!formData.destinationCity) newErrors.destinationCity = "Destination city is required";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateDatesTab = () => {
    const newErrors = {};
    
    if (!formData.startDate) newErrors.startDate = "Start date is required";
    if (!formData.endDate) newErrors.endDate = "End date is required";
    if (formData.startDate && formData.endDate && new Date(formData.endDate) <= new Date(formData.startDate)) {
      newErrors.endDate = "End date must be after start date";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validatePreferencesTab = () => {
    const newErrors = {};
    
    if (formData.tripPreferences.length === 0) {
      newErrors.tripPreferences = "Please select at least one preference";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateForm = () => {
    return validateLocationsTab() && validateDatesTab() && validatePreferencesTab();
  };

  const handleTabChange = (nextTab) => {
    // Validate the current tab before allowing navigation
    let canProceed = false;
    
    if (activeTab === "locations" && nextTab === "dates") {
      canProceed = validateLocationsTab();
    } else if (activeTab === "dates" && nextTab === "preferences") {
      canProceed = validateDatesTab();
    } else if (activeTab === "dates" && nextTab === "locations") {
      canProceed = true; // Allow going back
    } else if (activeTab === "preferences" && nextTab === "dates") {
      canProceed = true; // Allow going back
    }
    
    if (canProceed) {
      setActiveTab(nextTab);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    // Find the country names from the codes
    const sourceCountryData = fallbackDestinations.find(dest => dest.code === formData.sourceCountry.toUpperCase());
    const destinationCountryData = fallbackDestinations.find(dest => dest.code === formData.destinationCountry.toUpperCase());
    
    // Prepare API payload
    const travelData = {
      sourceCountry: sourceCountryData?.country || formData.sourceCountry,
      sourceCity: formData.sourceCity,
      destinationCountry: destinationCountryData?.country || formData.destinationCountry,
      destinationCity: formData.destinationCity,
      startDate: formData.startDate,
      endDate: formData.endDate,
      days: formData.days,
      style: formData.style,
      pace: formData.pace,
      tripPreferences: formData.tripPreferences
    };
    
    try {
      const response = await tripService.getTravelInfo(travelData);
      
      if (response.data.success) {
        // Navigate to trip planner with the response data
        navigate('./result', {
          state: {
            tripDetails: response.data.data.tripDetails,
            tripPlan: response.data.data.tripPlan,
            destination: response.data.data.destination,
            visaRequirements: response.data.data.visaRequirements,
            currencyInfo: response.data.data.currencyInfo,
            electricalInfo: response.data.data.electricalInfo,
            packingList: response.data.data.packingList,
            startDate: formData.startDate,
            endDate: formData.endDate,
            tripStyle: formData.style,
          }
        });
      } else {
        throw new Error('Failed to generate trip plan');
      }
    } catch (error) {
      console.error("Error generating trip:", error);
      alert("Error generating trip. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 mt-16">
      {/* Header */}
      <div className="flex items-center justify-center pt-8 pb-6">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-3 rounded-2xl shadow-lg transform -rotate-6 mr-4">
          <PlaneTakeoff className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
          ALR7LA Trip Planner
        </h1>
      </div>
      
      <div className="text-center mb-6">
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Customize your perfect trip with AI-powered recommendations tailored to your preferences
        </p>
      </div>

      {/* Main form card */}
      <div className="max-w-5xl mx-auto bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl border border-indigo-100/50 overflow-hidden mb-10">
        {/* Tabs navigation */}
        <div className="flex bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
          <button
            type="button"
            onClick={() => handleTabChange("locations")}
            className={`flex-1 py-4 px-4 flex items-center justify-center gap-2 transition-all ${
              activeTab === "locations" 
                ? "bg-white/20 font-medium" 
                : "hover:bg-white/10"
            }`}
          >
            <MapPin className="w-5 h-5" />
            <span>Locations</span>
          </button>
          
          <button
            type="button"
            onClick={() => handleTabChange("dates")}
            className={`flex-1 py-4 px-4 flex items-center justify-center gap-2 transition-all ${
              activeTab === "dates" 
                ? "bg-white/20 font-medium" 
                : "hover:bg-white/10"
            }`}
          >
            <CalendarDays className="w-5 h-5" />
            <span>Dates</span>
          </button>
          
          <button
            type="button"
            onClick={() => handleTabChange("preferences")}
            className={`flex-1 py-4 px-4 flex items-center justify-center gap-2 transition-all ${
              activeTab === "preferences" 
                ? "bg-white/20 font-medium" 
                : "hover:bg-white/10"
            }`}
          >
            <Heart className="w-5 h-5" />
            <span>Preferences</span>
          </button>
        </div>
        
        {/* Form content */}
        <form onSubmit={handleSubmit} className="p-8">
          {/* Locations tab */}
          {activeTab === "locations" && (
            <div className="space-y-8 animate-fadeIn">
              <div className="flex items-center mb-6">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
                  <MapPin className="w-5 h-5 text-indigo-600" />
                </div>
                <h2 className="text-xl font-semibold text-gray-800">Where are you traveling?</h2>
              </div>
              
              {/* Source Location */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <Flag className="w-4 h-4 mr-2 text-indigo-500" />
                    From Country
                  </label>
                  <div className="relative">
                    {loading.countries ? (
                      <div className="flex items-center justify-center h-11 border rounded-lg border-gray-300 bg-gray-50">
                        <RefreshCw className="h-5 w-5 text-indigo-500 animate-spin" />
                        <span className="ml-2 text-gray-500">Loading countries...</span>
                      </div>
                    ) : (
                      <select
                        value={formData.sourceCountry}
                        onChange={(e) => handleInputChange('sourceCountry', e.target.value)}
                        className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 ${errors.sourceCountry ? 'border-red-500' : 'border-gray-300'}`}
                      >
                                        <option value="">Select source country</option>
                        {countries.map(country => (
                          <option key={country.code} value={country.code}>
                            {country.flag && '🏴 '}{country.name}
                          </option>
                        ))}
                      </select>
                    )}
                    {errors.sourceCountry && <p className="text-red-500 text-sm mt-1">{errors.sourceCountry}</p>}
                  </div>
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <MapPin className="w-4 h-4 mr-2 text-indigo-500" />
                    From City
                  </label>
                  <div className="relative">
                    {loading.sourceCities ? (
                      <div className="flex items-center justify-center h-11 border rounded-lg border-gray-300 bg-gray-50">
                        <RefreshCw className="h-5 w-5 text-indigo-500 animate-spin" />
                        <span className="ml-2 text-gray-500">Loading cities...</span>
                      </div>
                    ) : (
                      <select
                        value={formData.sourceCity}
                        onChange={(e) => handleInputChange('sourceCity', e.target.value)}
                        disabled={!formData.sourceCountry}
                        className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 ${errors.sourceCity ? 'border-red-500' : 'border-gray-300'} ${!formData.sourceCountry ? 'bg-gray-100 cursor-not-allowed' : ''}`}
                      >
                        <option value="">Select your city</option>
                        {sourceCities.map(city => (
                          <option key={city} value={city}>{city}</option>
                        ))}
                      </select>
                    )}
                    {errors.sourceCity && <p className="text-red-500 text-sm mt-1">{errors.sourceCity}</p>}
                  </div>
                </div>
              </div>

              {/* Destination */}
              <div className="grid md:grid-cols-2 gap-6 mt-8">
                <div>
                  <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <Flag className="w-4 h-4 mr-2 text-indigo-500" />
                    Destination Country
                  </label>
                  <div className="relative">
                    {loading.countries ? (
                      <div className="flex items-center justify-center h-11 border rounded-lg border-gray-300 bg-gray-50">
                        <RefreshCw className="h-5 w-5 text-indigo-500 animate-spin" />
                        <span className="ml-2 text-gray-500">Loading countries...</span>
                      </div>
                    ) : (
                      <select
                        value={formData.destinationCountry}
                        onChange={(e) => handleInputChange('destinationCountry', e.target.value)}
                        className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 ${errors.destinationCountry ? 'border-red-500' : 'border-gray-300'}`}
                      >
                        <option value="">Select destination country</option>
                        {countries.map(country => (
                          <option key={country.code} value={country.code}>
                            {country.flag && '🏴'}{country.name}
                          </option>
                        ))}
                      </select>
                    )}
                    {errors.destinationCountry && <p className="text-red-500 text-sm mt-1">{errors.destinationCountry}</p>}
                  </div>
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <MapPin className="w-4 h-4 mr-2 text-indigo-500" />
                    Destination City
                  </label>
                  <div className="relative">
                    {loading.destinationCities ? (
                      <div className="flex items-center justify-center h-11 border rounded-lg border-gray-300 bg-gray-50">
                        <RefreshCw className="h-5 w-5 text-indigo-500 animate-spin" />
                        <span className="ml-2 text-gray-500">Loading cities...</span>
                      </div>
                    ) : (
                      <select
                        value={formData.destinationCity}
                        onChange={(e) => handleInputChange('destinationCity', e.target.value)}
                        disabled={!formData.destinationCountry}
                        className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 ${errors.destinationCity ? 'border-red-500' : 'border-gray-300'} ${!formData.destinationCountry ? 'bg-gray-100 cursor-not-allowed' : ''}`}
                      >
                        <option value="">Select destination city</option>
                        {destinationCities.map(city => (
                          <option key={city} value={city}>{city}</option>
                        ))}
                      </select>
                    )}
                    {errors.destinationCity && <p className="text-red-500 text-sm mt-1">{errors.destinationCity}</p>}
                  </div>
                </div>
              </div>

              <div className="flex justify-end mt-6">
                <button
                  type="button"
                  onClick={() => handleTabChange("dates")}
                  className="px-5 py-2 bg-indigo-600 text-white rounded-lg flex items-center hover:bg-indigo-700 transition-colors"
                >
                  Next: Select Dates
                  <ArrowRight className="ml-2 w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Dates tab */}
          {activeTab === "dates" && (
            <div className="space-y-8 animate-fadeIn">
              <div className="flex items-center mb-6">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
                  <CalendarDays className="w-5 h-5 text-indigo-600" />
                </div>
                <h2 className="text-xl font-semibold text-gray-800">When are you traveling?</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <CalendarDays className="w-4 h-4 mr-2 text-indigo-500" />
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => handleInputChange('startDate', e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 ${errors.startDate ? 'border-red-500' : 'border-gray-300'}`}
                  />
                  {errors.startDate && <p className="text-red-500 text-sm mt-1">{errors.startDate}</p>}
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <CalendarDays className="w-4 h-4 mr-2 text-indigo-500" />
                    End Date
                  </label>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => handleInputChange('endDate', e.target.value)}
                    min={formData.startDate || new Date().toISOString().split('T')[0]}
                    className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 ${errors.endDate ? 'border-red-500' : 'border-gray-300'}`}
                  />
                  {errors.endDate && <p className="text-red-500 text-sm mt-1">{errors.endDate}</p>}
                </div>
              </div>

              <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100 flex items-center">
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mr-4">
                  <CalendarDays className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Trip Duration</h3>
                  <p className="text-2xl font-bold text-indigo-600">
                    {formData.days} {formData.days === 1 ? 'day' : 'days'}
                  </p>
                </div>
              </div>

              <div className="flex justify-between mt-6">
                <button
                  type="button"
                  onClick={() => handleTabChange("locations")}
                  className="px-5 py-2 bg-gray-200 text-gray-700 rounded-lg flex items-center hover:bg-gray-300 transition-colors"
                >
                  <ArrowRight className="mr-2 w-4 h-4 transform rotate-180" />
                  Back to Locations
                </button>
                
                <button
                  type="button"
                  onClick={() => handleTabChange("preferences")}
                  className="px-5 py-2 bg-indigo-600 text-white rounded-lg flex items-center hover:bg-indigo-700 transition-colors"
                >
                  Next: Set Preferences
                  <ArrowRight className="ml-2 w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Preferences tab */}
          {activeTab === "preferences" && (
            <div className="space-y-8 animate-fadeIn">
              <div className="flex items-center mb-6">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
                  <Heart className="w-5 h-5 text-indigo-600" />
                </div>
                <h2 className="text-xl font-semibold text-gray-800">What's your travel style?</h2>
              </div>
              
              {/* Travel Style */}
              <div>
                <label className="flex items-center text-sm font-medium text-gray-700 mb-3">
                  <DollarSign className="w-4 h-4 mr-2 text-indigo-500" />
                  Budget Level
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {styles.map(style => (
                    <button
                      key={style}
                      type="button"
                      onClick={() => handleInputChange('style', style)}
                      className={`p-3 rounded-lg transition-all ${
                        formData.style === style
                          ? 'bg-indigo-100 border-2 border-indigo-500 text-indigo-700 font-medium'
                          : 'bg-white border-2 border-gray-200 hover:border-indigo-200 hover:bg-indigo-50'
                      }`}
                    >
                      <div className="flex flex-col items-center">
                        <DollarSign className={`w-6 h-6 ${formData.style === style ? 'text-indigo-600' : 'text-gray-500'}`} />
                        <span className="mt-1 capitalize">{style}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Pace Selection */}
              <div>
                <label className="flex items-center text-sm font-medium text-gray-700 mb-3">
                  <Zap className="w-4 h-4 mr-2 text-indigo-500" />
                  Travel Pace
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {paces.map(pace => (
                    <button
                      key={pace}
                      type="button"
                      onClick={() => handleInputChange('pace', pace)}
                      className={`p-3 rounded-lg transition-all ${
                        formData.pace === pace
                          ? 'bg-indigo-100 border-2 border-indigo-500 text-indigo-700 font-medium'
                          : 'bg-white border-2 border-gray-200 hover:border-indigo-200 hover:bg-indigo-50'
                      }`}
                    >
                      <div className="flex flex-col items-center">
                        <Zap className={`w-6 h-6 ${formData.pace === pace ? 'text-indigo-600' : 'text-gray-500'}`} />
                        <span className="mt-1 capitalize">{pace}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Trip Preferences */}
              <div>
                <label className="flex items-center text-sm font-medium text-gray-700 mb-3">
                  <Sparkles className="w-4 h-4 mr-2 text-indigo-500" />
                  Trip Preferences (Select at least one)
                </label>
                
                {errors.tripPreferences && (
                  <p className="text-red-500 text-sm mb-2">{errors.tripPreferences}</p>
                )}
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {tripPreferences.map(preference => (
                    <button
                      key={preference}
                      type="button"
                      onClick={() => togglePreference(preference)}
                      className={`p-3 rounded-lg text-left transition-all ${
                        formData.tripPreferences.includes(preference)
                          ? 'bg-indigo-100 border-2 border-indigo-500 text-indigo-700 font-medium'
                          : 'bg-white border-2 border-gray-200 hover:border-indigo-200 hover:bg-indigo-50'
                      }`}
                    >
                      <span>{preference}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-between mt-6">
                <button
                  type="button"
                  onClick={() => handleTabChange("dates")}
                  className="px-5 py-2 bg-gray-200 text-gray-700 rounded-lg flex items-center hover:bg-gray-300 transition-colors"
                >
                  <ArrowRight className="mr-2 w-4 h-4 transform rotate-180" />
                  Back to Dates
                </button>
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`px-5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg flex items-center ${
                    isSubmitting ? 'opacity-70 cursor-not-allowed' : 'hover:from-indigo-700 hover:to-purple-700'
                  }`}
                >
                  {isSubmitting ? (
                    <>
                      <Loader className="animate-spin mr-2 w-4 h-4" />
                      Generating Trip...
                    </>
                  ) : (
                    <>
                      Generate Trip Plan
                      <Sparkles className="ml-2 w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default TripPlannerForm;