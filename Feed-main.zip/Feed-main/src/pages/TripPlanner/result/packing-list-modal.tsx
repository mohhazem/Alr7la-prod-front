import React, { useState } from 'react';
import { Check, X, AlertCircle, Luggage, Plus, Minus, PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface PackingListItem {
  [key: string]: number;
}

interface PackingListData {
  [category: string]: PackingListItem;
}

interface PackingListModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Define valid category types
type CategoryType = "Clothes" | "Footwear" | "Toiletries" | "Miscellaneous" | "Documents" | "Electronics" | "Other";

const defaultPackingList: Record<CategoryType, PackingListItem> = {
  "Clothes": {
    "T-Shirts": 3,
    "Pants": 1,
    "Shorts": 2,
    "Underwear": 3,
    "Socks": 3,
    "Jacket": 0,
    "Swimwear": 0
  },
  "Footwear": {
    "Casual Shoes": 1,
    "Hiking Boots": 0,
    "Sandals": 1,
    "Flip Flops": 1
  },
  "Toiletries": {
    "Toothbrush": 1,
    "Hairbrush": 1,
    "Deodorant": 1,
    "Toothpaste": 1,
    "Shampoo": 1,
    "Soap": 1
  },
  "Miscellaneous": {
    "Sunscreen": 1,
    "Hat": 1,
    "Gloves": 0,
    "Scarf": 0
  },
  "Documents": {
    "Passport": 1,
    "Travel Insurance": 1,
    "Tickets": 1,
    "Emergency Contacts": 1
  },
  "Electronics": {
    "Phone": 1,
    "Phone Charger": 1,
    "Camera": 1,
    "Power Bank": 1,
    "Headphones": 1
  },
  "Other": {}
};

const categoryColors: Record<CategoryType, string> = {
  "Clothes": "from-purple-500 to-pink-500",
  "Footwear": "from-blue-500 to-cyan-500", 
  "Toiletries": "from-green-500 to-emerald-500",
  "Miscellaneous": "from-orange-500 to-red-500",
  "Documents": "from-indigo-500 to-purple-500",
  "Electronics": "from-yellow-500 to-orange-500",
  "Other": "from-gray-500 to-slate-500"
};

const categoryIcons: Record<CategoryType, string> = {
  "Clothes": "👕",
  "Footwear": "👟",
  "Toiletries": "🧴",
  "Miscellaneous": "🎒",
  "Documents": "📄", 
  "Electronics": "📱",
  "Other": "📦"
};

const PackingListModal: React.FC<PackingListModalProps> = ({ isOpen, onClose }) => {
  const [packingList, setPackingList] = useState<Record<CategoryType, PackingListItem>>(defaultPackingList);
  const [newItemName, setNewItemName] = useState("");
  const [addingToCategory, setAddingToCategory] = useState<CategoryType | null>(null);

  const getStatusColor = (quantity: number) => {
    if (quantity === 0) return "text-slate-400";
    return "text-emerald-600";
  };

  const getStatusIcon = (quantity: number) => {
    if (quantity === 0) return <AlertCircle className="h-4 w-4 text-slate-400" />;
    return <Check className="h-4 w-4 text-emerald-500" />;
  };

  const getItemBg = (quantity: number) => {
    if (quantity === 0) return "bg-slate-50 border-slate-200";
    return "bg-white border-emerald-100 shadow-sm";
  };

  const updateItemQuantity = (category: CategoryType, item: string, delta: number) => {
    setPackingList(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [item]: Math.max(0, (prev[category][item] || 0) + delta)
      }
    }));
  };

  const addNewItem = (category: CategoryType) => {
    if (newItemName.trim()) {
      setPackingList(prev => ({
        ...prev,
        [category]: {
          ...prev[category],
          [newItemName.trim()]: 1
        }
      }));
      setNewItemName("");
      setAddingToCategory(null);
    }
  };

  const totalItems = Object.values(packingList).reduce((total, category) => 
    total + Object.values(category).filter(qty => qty > 0).length, 0
  );

  const totalPacked = Object.values(packingList).reduce((total, category) => 
    total + Object.values(category).reduce((sum, qty) => sum + qty, 0), 0
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 p-6 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-black bg-opacity-10"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Luggage className="h-8 w-8" />
                <div>
                  <h2 className="text-3xl font-bold">Travel Packing List</h2>
                  <p className="text-blue-100 mt-1">
                    {totalItems} categories • {totalPacked} items packed
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-2 transition-all duration-200"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)] bg-gradient-to-br from-slate-50 to-white">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(Object.entries(packingList) as [CategoryType, PackingListItem][]).map(([category, items]) => {
              const packedCount = Object.values(items).filter(qty => qty > 0).length;
              const totalCount = Object.keys(items).length;
              const completionPercentage = totalCount === 0 ? 0 : (packedCount / totalCount) * 100;
              
              return (
                <div
                  key={category}
                  className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden border border-slate-200"
                >
                  {/* Category Header */}
                  <div className={`bg-gradient-to-r ${categoryColors[category]} p-4 text-white`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{categoryIcons[category]}</span>
                        <h3 className="text-lg font-bold">{category}</h3>
                      </div>
                      <div className="text-right">
                        <div className="bg-white bg-opacity-20 rounded-full px-3 py-1 text-sm font-semibold">
                          {packedCount}/{totalCount}
                        </div>
                      </div>
                    </div>
                    
                    {/* Progress Bar */}
                    <div className="mt-3 bg-white bg-opacity-20 rounded-full h-2">
                      <div 
                        className="bg-white h-2 rounded-full transition-all duration-500 ease-out"
                        style={{ width: `${completionPercentage}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="p-4 space-y-2">
                    {Object.entries(items).map(([item, quantity]) => (
                      <div
                        key={item}
                        className={`flex items-center justify-between p-3 rounded-lg border transition-all duration-200 hover:scale-[1.02] ${getItemBg(quantity)}`}
                      >
                        <div className="flex items-center gap-3">
                          {getStatusIcon(quantity)}
                          <span className={`font-medium ${getStatusColor(quantity)}`}>
                            {item}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateItemQuantity(category, item, -1)}
                            className="p-1 hover:bg-slate-100 rounded-full"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                          <span className={`font-medium ${getStatusColor(quantity)} w-6 text-center`}>
                            {quantity}
                          </span>
                          <button
                            onClick={() => updateItemQuantity(category, item, 1)}
                            className="p-1 hover:bg-slate-100 rounded-full"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}

                    {/* Add Item Section */}
                    <div className="mt-4">
                      {addingToCategory === category ? (
                        <div className="flex gap-2">
                          <Input
                            type="text"
                            placeholder={`Add item to ${category}`}
                            value={newItemName}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewItemName(e.target.value)}
                            onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>) => e.key === "Enter" && addNewItem(category)}
                            className="flex-1"
                          />
                          <Button onClick={() => addNewItem(category)} size="sm">
                            Add
                          </Button>
                          <Button 
                            onClick={() => setAddingToCategory(null)} 
                            variant="outline" 
                            size="sm"
                          >
                            Cancel
                          </Button>
                        </div>
                      ) : (
                        <Button
                          onClick={() => setAddingToCategory(category)}
                          variant="outline"
                          className="w-full"
                        >
                          <PlusCircle className="h-4 w-4 mr-2" />
                          Add Item to {category}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Summary Footer */}
          <div className="mt-8 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-xl p-6 text-white">
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-2">Packing Progress</h3>
              <div className="flex justify-center items-center gap-6 text-lg">
                <div className="flex items-center gap-2">
                  <Check className="h-5 w-5" />
                  <span>{totalItems} Categories Ready</span>
                </div>
                <div className="flex items-center gap-2">
                  <Luggage className="h-5 w-5" />
                  <span>{totalPacked} Items Packed</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PackingListModal;