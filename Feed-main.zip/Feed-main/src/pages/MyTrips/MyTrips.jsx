import React, { useState, useEffect } from 'react';
import { Box, Container, Typography, Grid, CircularProgress } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import localStorageService from '../../services/localStorageService';
import { useNavigate } from 'react-router-dom';
import TripCard from '../../components/TripCard/TripCard';
import { tripService } from '../../services/networkService';

const MyTrips = () => {
    const theme = useTheme();
    const isDarkMode = theme.palette.mode === 'dark';
    const navigate = useNavigate();
    const [trips, setTrips] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const checkAuth = () => {
            const token = localStorageService.getItem('token');
            if (!token) {
                navigate('/');
                return;
            }
            fetchUserTrips();
        };

        checkAuth();
    }, [navigate]);

    const fetchUserTrips = async () => {
        try {
            const userId = localStorageService.getItem('id');
            const response = await tripService.getUserTrips(userId);
            if (response.data.success) {
                setTrips(response.data.userTrips);
            } else {
                throw new Error('Failed to fetch trips');
            }
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleDeleteTrip = async (tripId) => {
        try {
            await tripService.deleteTrip(tripId);
            setTrips((prevTrips) => prevTrips.filter((userTrip) => userTrip.trip_id !== tripId));
        } catch (error) {
            setError(error.message || 'Failed to delete trip');
        }
    };

    if (loading) {
        return (
            <Box
                sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    minHeight: '100vh',
                    backgroundColor: isDarkMode ? '#18191A' : '#F0F2F5',
                }}
            >
                <CircularProgress />
            </Box>
        );
    }

    if (error) {
        return (
            <Box
                sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    minHeight: '100vh',
                    backgroundColor: isDarkMode ? '#18191A' : '#F0F2F5',
                }}
            >
                <Typography color="error">{error}</Typography>
            </Box>
        );
    }

    return (
        <Box
            sx={{
                minHeight: '100vh',
                background: isDarkMode ? 'linear-gradient(145deg, #18191A, #242526)' : 'linear-gradient(145deg, #F0F2F5, #E4E6EB)',
                pt: 10,
                pb: 4,
            }}
        >
            <Container maxWidth="lg">
                <Typography
                    variant="h3"
                    component="h1"
                    sx={{
                        mb: 4,
                        color: isDarkMode ? '#E4E6EB' : '#1E1E1E',
                        fontWeight: 700,
                        textAlign: 'center',
                    }}
                >
                    My Trips
                </Typography>

                {trips.length === 0 ? (
                    <Box
                        sx={{
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            minHeight: '50vh',
                        }}
                    >
                        <Typography
                            variant="h6"
                            sx={{
                                color: isDarkMode ? '#E4E6EB' : '#1E1E1E',
                            }}
                        >
                            No trips found. Start planning your next adventure!
                        </Typography>
                    </Box>
                ) : (
                    <Grid container spacing={3}>
                        {trips.map((userTrip) => (
                            <Grid item xs={12} sm={6} md={4} key={userTrip.trip_id}>
                                <TripCard
                                    trip={userTrip.Trip}
                                    onDelete={() => handleDeleteTrip(userTrip.trip_id)}
                                />
                            </Grid>
                        ))}
                    </Grid>
                )}
            </Container>
        </Box>
    );
};

export default MyTrips; 