import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import '../../App.css';
import ResponsiveAppBar from '../../components/ResponsiveAppBar';
import PostCard from '../../components/Post';
import Sidebar from '../../components/SideBar';
import AboutSection from '../../components/AboutSection';
import VisitedCountriesMap from '../../components/VisitedCountries';
import UserAvatar from '../../components/UserAvatar';
import {
  Box,
  Typography,
  Tabs,
  Tab,
  Paper,
  IconButton,
  useTheme,
  CircularProgress,
  Alert
} from '@mui/material';
import postKhalid from '../../assets/images/postKhalid.jpg'
import { usePostContext } from '../../context/PostContext';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import { useUserContext } from '../../context/UserContext';
import LeftSider from '../../components/LeftSider';
import { visitedCountryService, postService } from '../../services/networkService'
import { profileService } from '../../services/networkService'
import localStorageService from '../../services/localStorageService';
import FriendsList from '../../components/FriendsList';
import CreatePost from '../../components/CreatePost';
// Map of country IDs to alpha2 codes
const countryIdToAlpha2 = {
  1: 'AF', // Afghanistan
  2: 'AL', // Albania
  3: 'DZ', // Algeria
  4: 'AD', // Andorra
  5: 'AO', // Angola
  6: 'AG', // Antigua and Barbuda
  7: 'AR', // Argentina
  8: 'AM', // Armenia
  9: 'AU', // Australia
  10: 'AT', // Austria
  11: 'AZ', // Azerbaijan
  12: 'BS', // Bahamas
  13: 'BH', // Bahrain
  14: 'BD', // Bangladesh
  15: 'BB', // Barbados
  16: 'BY', // Belarus
  17: 'BE', // Belgium
  18: 'BZ', // Belize
  19: 'BJ', // Benin
  20: 'BT', // Bhutan
  21: 'BO', // Bolivia
  22: 'BA', // Bosnia and Herzegovina
  23: 'BW', // Botswana
  24: 'BR', // Brazil
  25: 'BN', // Brunei
  26: 'BG', // Bulgaria
  27: 'BF', // Burkina Faso
  28: 'BI', // Burundi
  29: 'CV', // Cabo Verde
  30: 'KH', // Cambodia
  31: 'CM', // Cameroon
  32: 'CA', // Canada
  33: 'CF', // Central African Republic
  34: 'TD', // Chad
  35: 'CL', // Chile
  36: 'CN', // China
  37: 'CO', // Colombia
  38: 'KM', // Comoros
  39: 'CG', // Congo (Congo-Brazzaville)
  40: 'CD', // Congo (Democratic Republic)
  41: 'CR', // Costa Rica
  42: 'HR', // Croatia
  43: 'CU', // Cuba
  44: 'CY', // Cyprus
  45: 'CZ', // Czechia (Czech Republic)
  46: 'DK', // Denmark
  47: 'DJ', // Djibouti
  48: 'DM', // Dominica
  49: 'DO', // Dominican Republic
  50: 'EC', // Ecuador
  51: 'EG', // Egypt
  52: 'SV', // El Salvador
  53: 'GQ', // Equatorial Guinea
  54: 'ER', // Eritrea
  55: 'EE', // Estonia
  56: 'SZ', // Eswatini (Swaziland)
  57: 'ET', // Ethiopia
  58: 'FJ', // Fiji
  59: 'FI', // Finland
  60: 'FR', // France
  61: 'GA', // Gabon
  62: 'GM', // Gambia
  63: 'GE', // Georgia
  64: 'DE', // Germany
  65: 'GH', // Ghana
  66: 'GR', // Greece
  67: 'GD', // Grenada
  68: 'GT', // Guatemala
  69: 'GN', // Guinea
  70: 'GW', // Guinea-Bissau
  71: 'GY', // Guyana
  72: 'HT', // Haiti
  73: 'HN', // Honduras
  74: 'HU', // Hungary
  75: 'IS', // Iceland
  76: 'IN', // India
  77: 'ID', // Indonesia
  78: 'IR', // Iran
  79: 'IQ', // Iraq
  80: 'IE', // Ireland
  81: 'IL', // Israel
  82: 'IT', // Italy
  83: 'JM', // Jamaica
  84: 'JP', // Japan
  85: 'JO', // Jordan
  86: 'KZ', // Kazakhstan
  87: 'KE', // Kenya
  88: 'KI', // Kiribati
  89: 'KP', // Korea North
  90: 'KR', // Korea South
  91: 'XK', // Kosovo
  92: 'KW', // Kuwait
  93: 'KG', // Kyrgyzstan
  94: 'LA', // Laos
  95: 'LV', // Latvia
  96: 'LB', // Lebanon
  97: 'LS', // Lesotho
  98: 'LR', // Liberia
  99: 'LY', // Libya
  100: 'LI', // Liechtenstein
  101: 'LT', // Lithuania
  102: 'LU', // Luxembourg
  103: 'MG', // Madagascar
  104: 'MW', // Malawi
  105: 'MY', // Malaysia
  106: 'MV', // Maldives
  107: 'ML', // Mali
  108: 'MT', // Malta
  109: 'MH', // Marshall Islands
  110: 'MR', // Mauritania
  111: 'MU', // Mauritius
  112: 'MX', // Mexico
  113: 'FM', // Micronesia
  114: 'MD', // Moldova
  115: 'MC', // Monaco
  116: 'MN', // Mongolia
  117: 'ME', // Montenegro
  118: 'MA', // Morocco
  119: 'MZ', // Mozambique
  120: 'MM', // Myanmar (Burma)
  121: 'NA', // Namibia
  122: 'NR', // Nauru
  123: 'NP', // Nepal
  124: 'NL', // Netherlands
  125: 'NZ', // New Zealand
  126: 'NI', // Nicaragua
  127: 'NE', // Niger
  128: 'NG', // Nigeria
  129: 'MK', // North Macedonia
  130: 'NO', // Norway
  131: 'OM', // Oman
  132: 'PK', // Pakistan
  133: 'PW', // Palau
  134: 'PS', // Palestine
  135: 'PA', // Panama
  136: 'PG', // Papua New Guinea
  137: 'PY', // Paraguay
  138: 'PE', // Peru
  139: 'PH', // Philippines
  140: 'PL', // Poland
  141: 'PT', // Portugal
  142: 'QA', // Qatar
  143: 'RO', // Romania
  144: 'RU', // Russia
  145: 'RW', // Rwanda
  146: 'KN', // Saint Kitts and Nevis
  147: 'LC', // Saint Lucia
  148: 'VC', // Saint Vincent and the Grenadines
  149: 'WS', // Samoa
  150: 'SM', // San Marino
  151: 'ST', // São Tomé and Príncipe
  152: 'SA', // Saudi Arabia
  153: 'SN', // Senegal
  154: 'RS', // Serbia
  155: 'SC', // Seychelles
  156: 'SL', // Sierra Leone
  157: 'SG', // Singapore
  158: 'SK', // Slovakia
  159: 'SI', // Slovenia
  160: 'SB', // Solomon Islands
  161: 'SO', // Somalia
  162: 'ZA', // South Africa
  163: 'SS', // South Sudan
  164: 'ES', // Spain
  165: 'LK', // Sri Lanka
  166: 'SD', // Sudan
  167: 'SR', // Suriname
  168: 'SE', // Sweden
  169: 'CH', // Switzerland
  170: 'SY', // Syria
  171: 'TW', // Taiwan
  172: 'TJ', // Tajikistan
  173: 'TZ', // Tanzania
  174: 'TH', // Thailand
  175: 'TL', // Timor-Leste (East Timor)
  176: 'TG', // Togo
  177: 'TO', // Tonga
  178: 'TT', // Trinidad and Tobago
  179: 'TN', // Tunisia
  180: 'TR', // Turkey
  181: 'TM', // Turkmenistan
  182: 'TV', // Tuvalu
  183: 'UG', // Uganda
  184: 'UA', // Ukraine
  185: 'AE', // United Arab Emirates
  186: 'GB', // United Kingdom
  187: 'US', // United States
  188: 'UY', // Uruguay
  189: 'UZ', // Uzbekistan
  190: 'VU', // Vanuatu
  191: 'VA', // Vatican City (Holy See)
  192: 'VE', // Venezuela
  193: 'VN', // Vietnam
  194: 'YE', // Yemen
  195: 'ZM', // Zambia
  196: 'ZW'  // Zimbabwe
};

const user = {
  id: 51,
  name: 'Mohamed Hazem',
  username: 'MohamedHazem',
  bio: `A passionate traveler and adventure seeker. 🌍
I've been to over 25 countries and counting, with a love for exploring hidden gems, meeting new people, and embracing diverse cultures.`,
  location: 'Alexandria, Egypt',
  joined: 'June 2024',
  job: 'Sporting scout',
  relationship: 'Single',
  preferences: ['Beaches', 'Hiking', 'Camping', 'Skiing', 'Shopping', 'Mountains', 'History'],
  photos: [
    postKhalid
  ]
};

const MOCK_FRIENDS = [
  {
    id: 1,
    name: "Sarah Johnson",
    username: "sarahj",
    profile_picture: "https://randomuser.me/api/portraits/women/44.jpg"
  },
  {
    id: 2,
    name: "Michael Chen",
    username: "michaelc",
    profile_picture: "https://randomuser.me/api/portraits/men/32.jpg"
  },
  {
    id: 3,
    name: "Emma Wilson",
    username: "emmaw",
    profile_picture: "https://randomuser.me/api/portraits/women/68.jpg"
  }
];

function Profile() {
  const { posts } = usePostContext();
  const { coverPhoto, updateCoverPhoto, updateProfilePhoto } = useUserContext();
  const theme = useTheme();
  const [activeTab, setActiveTab] = useState(0);
  const [visitedCountries, setVisitedCountries] = useState([]);
  const [userPosts, setUserPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userData, setUserData] = useState(null);
  const { id: urlId } = useParams();
  const [friends, setFriends] = useState(MOCK_FRIENDS);
  const [createPostOpen, setCreatePostOpen] = useState(false);

  useEffect(() => {
    fetchUser();
  }, [urlId]);

  useEffect(() => {
    fetchUserPosts();
  }, [urlId]);

  const fetchUser = async () => {
    try {
      setLoading(true);
      // Always use URL ID if available, only fall back to logged-in user if no URL ID
      const userId = urlId || localStorageService.getItem('id');

      if (!userId) {
        setError('No user ID found');
        return;
      }

      const response = await profileService.getProfile(userId);
      if (response.data) {
        setUserData(response.data);
        
        // Only update the global profile photo and cover photo if viewing own profile
        const isOwnProfile = userId === localStorageService.getItem('id');
        if (isOwnProfile) {
          if (response.data.profile_picture) {
            updateProfilePhoto(response.data.profile_picture);
          }
          if (response.data.wallpaper) {
            updateCoverPhoto(response.data.wallpaper);
          }
        }
        
        // Fetch visited countries for the profile we're viewing
        fetchVisitedCountries(userId);
      } else {
        setError('Failed to load user data');
      }
    } catch (err) {
      setError('Error loading user profile');
      console.error('Error fetching user:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchVisitedCountries = async (profileId) => {
    try {
      setLoading(true);
      // Use the profile ID we're viewing, not the logged-in user's ID
      const response = await visitedCountryService.getVisitedCountries(profileId);
      
      // If no data at all, set empty array and return early
      if (!response || !response.data) {
        setVisitedCountries([]);
        return;
      }

      // Handle different possible response structures
      let countriesData = [];
      if (Array.isArray(response.data)) {
        countriesData = response.data;
      } else if (response.data && Array.isArray(response.data.countries)) {
        countriesData = response.data.countries;
      } else if (response.data && typeof response.data === 'object') {
        // If single country object
        if (response.data.id || response.data.countryId) {
          countriesData = [response.data];
        }
      }

      // If no valid countries data, set empty array and return early
      if (!countriesData || countriesData.length === 0) {
        setVisitedCountries([]);
        return;
      }

      // Transform the API response to get country codes
      const countryCodes = countriesData.map(country => {
        if (!country) return null;
        
        const countryId = country.id || country.countryId;
        if (!countryId) return null;

        const alpha2Code = countryIdToAlpha2[countryId];
        if (!alpha2Code) {
          console.warn('No alpha2 code found for country ID:', countryId);
          return null;
        }

        return alpha2Code;
      }).filter(code => code !== null);

      setVisitedCountries(countryCodes);
      setError(null);
    } catch (err) {
      console.error('Error fetching visited countries:', err);
      // Don't show error to user, just set empty array
      setVisitedCountries([]);
    } finally {
      setLoading(false);
    }
  };

  const addVisitedCountry = async (countryCode) => {
    try {
      // Find the country ID from the alpha2 code
      const countryId = Object.entries(countryIdToAlpha2).find(([_, code]) => code === countryCode)?.[0];

      if (!countryId) {
        console.error('Invalid country code:', countryCode);
        setError('Invalid country code');
        return;
      }

      const visitData = {
        user_id: localStorageService.getItem('id'), // Convert to string as per API requirement
        country_id: parseInt(countryId), // Keep as number
        visitDate: new Date().toISOString().split('T')[0] // Format as YYYY-MM-DD
      };

      console.log('Adding visited country:', visitData);
      await visitedCountryService.addVisitedCountry(visitData);

      // Add the alpha2 code to the visited countries list
      setVisitedCountries(prev => [...prev, countryCode]);
      setError(null);
    } catch (err) {
      setError('Failed to add country');
      console.error('Error adding visited country:', err);
    }
  };

  const removeVisitedCountry = async (countryCode) => {
    try {
      // Find the country ID from the alpha2 code
      const countryId = Object.entries(countryIdToAlpha2).find(([_, code]) => code === countryCode)?.[0];

      if (!countryId) {
        console.error('Invalid country code:', countryCode);
        setError('Invalid country code');
        return;
      }

      await visitedCountryService.deleteVisitedCountry(localStorageService.getItem('id'), parseInt(countryId));
      setVisitedCountries(prev => prev.filter(code => code !== countryCode));
      setError(null);
    } catch (err) {
      setError('Failed to remove country');
      console.error('Error removing visited country:', err);
    }
  };

  const fetchUserPosts = async () => {
    try {
      setLoading(true);
      const userId = urlId || localStorageService.getItem('id');

      if (!userId) {
        console.error('No user ID found');
        setError('No user ID found');
        return;
      }

      const response = await postService.getUserPosts(userId);
      console.log('Raw API Response:', response);

      // Correctly extract posts array from API response
      const postsData = Array.isArray(response.data.data) ? response.data.data : [];
      console.log('Posts data:', postsData);

      // Create an array of transformed posts
      const postsArray = postsData.map(post => {
        console.log('Processing post:', post);
        return {
          id: post.id?.toString(),
          user: {
            id: post.user_id?.toString(),
            name: post.user?.name || post.User?.name || 'User ' + post.user_id,
            avatar: post.user?.profile_picture || post.User?.profile_picture || '/default-avatar.png'
          },
          time: new Date(post.created_at),
          contentType: post.images?.length > 0 ? 'image' : 'text',
          contentSrc: post.images?.[0]?.image_url || '',
          text: post.description || '',
          isFirstPost: false,
          likes: post.number_of_likes || 0,
          privacy: post.visibility === 'private' ? 'only_me' : (post.visibility || 'public'),
          images: post.images?.map(img => ({
            id: img.id,
            url: img.image_url,
            createdAt: new Date(img.created_at)
          })) || [],
          createdAt: new Date(post.created_at),
          updatedAt: new Date(post.updated_at),
          postSourceId: post.post_source_id
        };
      });

      console.log('Transformed posts array:', postsArray);

      // Sort posts by creation date (newest first)
      const sortedPosts = postsArray.sort((a, b) => b.createdAt - a.createdAt);
      console.log('Final sorted posts:', sortedPosts);
      
      setUserPosts(sortedPosts);
      setError(null);
    } catch (err) {
      console.error('Error fetching user posts:', err);
      setError('Failed to load user posts');
      setUserPosts([]);
    } finally {
      setLoading(false);
    }
  };

  const handlePostUpdate = (updatedPost, action) => {
    if (action === 'delete' && updatedPost.id) {
      // Implement the delete logic here
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 0:
        return (
          <Box sx={{ mt: 2 }}>
            {loading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                <CircularProgress />
              </Box>
            ) : error ? (
              <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>
            ) : userPosts.length === 0 ? (
              <Typography variant="body1" sx={{ textAlign: 'center', p: 3 }}>
                No posts yet
              </Typography>
            ) : (
              <Box sx={{ mt: 2 }}>
                {userPosts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                  />
                ))}
              </Box>
            )}
          </Box>
        );

      case 1: // Friends
        return (
          <FriendsList friends={friends} setFriends={setFriends} />
        );

      case 2: // Visited Countries
        console.log('Rendering VisitedCountries with data:', visitedCountries);
        return (
          <Box>
            {loading ? (
              <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
                <CircularProgress />
              </Box>
            ) : error ? (
              <Alert severity="error" sx={{ mb: 2 }}>
                {error}
              </Alert>
            ) : (
              <VisitedCountriesMap
                visitedCountries={visitedCountries}
                onAddCountry={addVisitedCountry}
                onRemoveCountry={removeVisitedCountry}
              />
            )}
          </Box>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <title>Profile</title>

      <Box display="flex" sx={{
        bgcolor: theme.palette.mode === 'dark' ? '#242526' : undefined,
        maxWidth: 1280,
        margin: '0 auto',
        padding: '2rem',
        textAlign: 'center',
      }}>
        {/* Left Sidebar */}
        <LeftSider>
          <Sidebar page="profile" />
        </LeftSider>

        {/* Main Content */}
        <Box
          sx={{
            ml: { md: '40px', xs: 0 },
            pt: { xs: 1, sm: 2 },
            px: { xs: 1, sm: 2, md: 3 },
            maxWidth: { xs: '100%', md: 'calc(100% - 200px)' },
            width: '100%',
            mx: 'auto',
            bgcolor: theme.palette.mode === 'dark' ? '#242526' : undefined
          }}
        >
          {/* Cover Photo */}
          <Box
            sx={{
              backgroundImage: `url(${coverPhoto})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              height: { xs: 280, sm: 320, md: 360 },
              borderRadius: 3,
              position: 'relative',
              mb: 6,
              '&:hover .cover-photo-edit': {
                opacity: 1,
              },
            }}
          >
            {/* Cover Photo Edit Button */}
            <Box
              className="cover-photo-edit"
              sx={{
                position: 'absolute',
                bottom: 16,
                right: 16,
                opacity: 0,
                transition: 'opacity 0.2s',
                backgroundColor: 'rgba(0, 0, 0, 0.6)',
                borderRadius: '50%',
                '&:hover': {
                  backgroundColor: 'rgba(0, 0, 0, 0.8)',
                },
              }}
            >
              <input
                type="file"
                accept="image/*"
                id="cover-photo-input"
                style={{ display: 'none' }}
                onChange={(e) => {
                  const file = e.target.files[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      updateCoverPhoto(reader.result);
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
              <IconButton
                onClick={() => document.getElementById('cover-photo-input').click()}
                sx={{ color: 'white' }}
              >
                <PhotoCameraIcon />
              </IconButton>
            </Box>

            {/* Profile Photo with white circular frame */}
            <Box
              className="cover-photo"
              sx={{
                position: 'absolute',
                bottom: -60,
                left: '16%',
                transform: 'translateX(-50%)',
                width: 115,
                height: 115,
                borderRadius: '50%',
                border: '5px solid #fff',
                background: '#fff',
                boxShadow: 3,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                zIndex: 2,
                '&:hover .profile-photo-edit': {
                  opacity: 1,
                },
              }}
            >
              <UserAvatar size={110} allowChange={true} />
            </Box>
          </Box>

          {/* Layout */}
          <Box display="flex" flexDirection={{ xs: 'column', md: 'row' }} gap={2} flexWrap="wrap">
            {/* Left: About Section */}
            <Box flex={1} width="100%" maxWidth={{ md: 340 }}>
              <Paper
                elevation={1}
                sx={{
                  borderRadius: 3,
                  overflow: 'hidden',
                  bgcolor: theme.palette.mode === 'dark' ? '#242526' : undefined
                }}
              >
                <AboutSection
                  userData={userData}
                  refetchUserData={fetchUser}
                />
              </Paper>
            </Box>

            {/* Right: Feed Section */}
            <Box flex={2} minWidth={0}>
              {/* Tabs */}
              <Paper
                elevation={1}
                sx={{
                  px: { xs: 1, sm: 1.5 },
                  py: 0.75,
                  mb: 2,
                  borderRadius: 2,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  background: '#fff',
                  bgcolor: theme.palette.mode === 'dark' ? '#242526' : undefined
                }}
              >
                <Box sx={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '100%',
                }}>
                  <Tabs
                    value={activeTab}
                    onChange={handleTabChange}
                    textColor="primary"
                    indicatorColor="primary"
                    sx={{
                      '& .MuiTab-root': {
                        textTransform: 'none',
                        fontWeight: 600,
                        fontSize: '16px',
                        mr: 1,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: 0.5
                      },
                      '& .MuiTabs-indicator': {
                        transition: 'all 0.2s ease-in-out'
                      }
                    }}
                  >
                    <Tab
                      label={
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                          <Typography>Posts</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {userPosts.length}
                          </Typography>
                        </Box>
                      }
                    />
                    <Tab
                      label={
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                          <Typography>Friends</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {friends.length}
                          </Typography>
                        </Box>
                      }
                    />
                    <Tab
                      label={
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                          <Typography>Visited Countries</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {visitedCountries.length}
                          </Typography>
                        </Box>
                      }
                    />
                  </Tabs>
                </Box>
              </Paper>

              {/* Content based on selected tab */}
              {renderTabContent()}
            </Box>
          </Box>
        </Box>
      </Box>

      {userData && (
        <CreatePost
          open={createPostOpen}
          onClose={() => setCreatePostOpen(false)}
          onPostCreated={() => {
            setCreatePostOpen(false);
            fetchUserPosts();
          }}
          userData={userData}
        />
      )}
    </>
  );
}

export default Profile;