import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Feed from './pages/Feed/Feed';
import Profile from './pages/Profile/Profile';
import SavedPosts from './pages/SavedPosts/SavedPosts';
import SearchPage from './pages/Search/SearchPage';
import { PostProvider } from './context/PostContext';
import { SavedPostProvider } from './context/SavedPostContext';
import UserProvider from './context/UserContext';
import { NotificationProvider } from './context/NotificationContext';
import { ThemeProvider } from './context/ThemeContext';
import CustomizeTrip from './pages/TripPlanner/CustomizeTrip.jsx'
import TripPlanner from './pages/TripPlanner/result/trip-planner.tsx'
import ResponsiveAppBar from './components/ResponsiveAppBar';
import Home from './pages/Home/Home.jsx';
import Discover from './components/Discover/Discover.jsx';
import CountryProfile from './components/Country/Country.jsx';
import ProtectedRoute from './components/ProtectedRoute';
import { BlockedUsersProvider } from './context/BlockedUsersContext';

function App() {
  return (
    <PostProvider>
      <BlockedUsersProvider>
        <ThemeProvider>
          <NotificationProvider>
            <UserProvider>
              <SavedPostProvider>
                <Router>
                  <ResponsiveAppBar />
                  <Routes>
                    <Route path="/" element={<Navigate to="/Home" replace />} />
                    <Route path="/Home" element={<Home />} />
                    <Route path="/Auth/" element={<Home />} />
                    <Route path="/trending-trips" element={<Home />} />
                    <Route path="/discover" element={<Discover />} />
                    <Route path="/country" element={<CountryProfile />} />

                    {/* Protected Routes */}
                    <Route path="/trip-planner" element={
                      <ProtectedRoute>
                        <CustomizeTrip />
                      </ProtectedRoute>
                    } />
                    <Route path="/trip-planner/result" element={
                      <ProtectedRoute>
                        <TripPlanner />
                      </ProtectedRoute>
                    } />
                    <Route path="/trip-planner/result/:id" element={
                      <ProtectedRoute>
                        <TripPlanner />
                      </ProtectedRoute>
                    } />
                    
                    <Route path="/feed" element={
                      <ProtectedRoute>
                        <Feed />
                      </ProtectedRoute>
                    } />
                    <Route path="/saved-posts" element={
                      <ProtectedRoute>
                        <SavedPosts />
                      </ProtectedRoute>
                    } />
                    <Route path="/profile" element={
                      <ProtectedRoute>
                        <Profile />
                      </ProtectedRoute>
                    } />
                    <Route path="/search" element={
                      <ProtectedRoute>
                        <SearchPage />
                      </ProtectedRoute>
                    } />
                  </Routes>
                </Router>
              </SavedPostProvider>
            </UserProvider>
          </NotificationProvider>
        </ThemeProvider>
      </BlockedUsersProvider>
    </PostProvider>
  );
}

export default App;